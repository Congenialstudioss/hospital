﻿namespace Sample
{
    partial class TreatmentMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.txttreatment = new System.Windows.Forms.TextBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.Gvtreatment = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.Gvtreatment)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(55, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Treatment Name";
            // 
            // txttreatment
            // 
            this.txttreatment.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txttreatment.Location = new System.Drawing.Point(177, 28);
            this.txttreatment.Name = "txttreatment";
            this.txttreatment.Size = new System.Drawing.Size(225, 20);
            this.txttreatment.TabIndex = 1;
            // 
            // btnsave
            // 
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnsave.Location = new System.Drawing.Point(246, 63);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 2;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // Gvtreatment
            // 
            this.Gvtreatment.AllowUserToAddRows = false;
            this.Gvtreatment.AllowUserToDeleteRows = false;
            this.Gvtreatment.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Gvtreatment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Gvtreatment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gvtreatment.Location = new System.Drawing.Point(58, 101);
            this.Gvtreatment.Name = "Gvtreatment";
            this.Gvtreatment.ReadOnly = true;
            this.Gvtreatment.Size = new System.Drawing.Size(404, 150);
            this.Gvtreatment.TabIndex = 4;
            this.Gvtreatment.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gvtreatment_CellDoubleClick);
            this.Gvtreatment.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Gvtreatment_CellMouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(134, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.deleteRowToolStripMenuItem.Text = "Delete Row";
            // 
            // TreatmentMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 271);
            this.Controls.Add(this.Gvtreatment);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.txttreatment);
            this.Controls.Add(this.label1);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TreatmentMaster";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Treatment Master";
            ((System.ComponentModel.ISupportInitialize)(this.Gvtreatment)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txttreatment;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.DataGridView Gvtreatment;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
    }
}