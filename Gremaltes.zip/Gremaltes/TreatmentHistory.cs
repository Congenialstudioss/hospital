﻿using Sample.DataAccess;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApplication3;

namespace Sample
{
    public partial class TreatmentHistory : Form
    {
        static Int32 Fees_ID = 0;
        static Int32 VictimID = 0;
        private string childMessage;

        int indexRow;

        public string ChildMessage
        {
            get { return childMessage; }
            set { childMessage = value; }
        }
        public string _valueVictimID = string.Empty;
        public TreatmentHistory()
        {
            InitializeComponent();
        }

        #region Form Events
        private void TreatmentHistory_Load(object sender, EventArgs e)
        {
            txtregid.Focus();
            txtregid.Select();
            combosex.SelectedIndex = 0;
            if (Global.UserSearchId != null)
            {
                txtregid.Text = Global.UserSearchId;
                Global.UserSearchId = null;
                Global.RegID = txtregid.Text;
                btnreviewshow.Enabled = true;
            }
            else
            {
                txtregid.Text = _valueVictimID;
            }
            cbosubtitle.SelectedIndex = 1;
            txtcontactno.MaxLength = 10;
            txtage.MaxLength = 2;
            txtregid.MaxLength = 10;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtregid.Text != String.Empty)
                {
                    DisplayRecord();
                }
                else
                {
                    MessageBox.Show("Please Enter Victim No", "Treatment - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnSearchLookup_Click(object sender, EventArgs e)
        {
            using (PatientSearch childform = new PatientSearch())
            {
                childform.ShowDialog(this);
            }
        }

        private void txtpatient_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsUpper(e.KeyChar) || char.IsLower(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar.ToString() == ".")
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void txtguardian_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsUpper(e.KeyChar) || char.IsLower(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar.ToString() == "." || e.KeyChar.ToString() == "/")
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void txtage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }


        private void txtpincode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void cbosubtitle_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ComboBox comboBox = (ComboBox)sender;

                // Save the selected employee's name, because we will remove 
                // the employee's name from the list. 
                string selectedValue = (string)cbosubtitle.SelectedItem;

                if (selectedValue == "MR" || selectedValue == "SR." || selectedValue == "MASTER.")
                {
                    combosex.SelectedIndex = 0;
                }
                else
                {
                    combosex.SelectedIndex = 1;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        #endregion

        #region User Defined Methods

        public void updatetext(string fromchildform)
        {
            txtregid.Text = fromchildform;
            btnSearch.PerformClick();
            //In this case, I passed a string back to Form1, you can pass any variables you want
            //use this method to process the variable, just like a normal method.
        }

        public void usersearchbind(string regid)
        {
            if (regid != string.Empty)
            {
                Global.UserSearchId = regid;
            }
            txtregid.Text = regid;
            DisplayRecord();
            BindGrid();
        }
        protected void DisplayRecord()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@pi_RegisterID", txtregid.Text.Trim());
                DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_ReviewForm_Fetch_Sp", hstbl);
                if (dtLoad != null && dtLoad.Rows.Count > 0)
                {
                    VictimID = Convert.ToInt32(dtLoad.Rows[0]["VictimId"].ToString());
                    dtptransdate.Text = dtLoad.Rows[0]["RegDate"].ToString();
                    cbosubtitle.SelectedIndex = Convert.ToInt32(dtLoad.Rows[0]["SubTitle"].ToString());
                    txtpatient.Text = dtLoad.Rows[0]["Name"].ToString();
                    txtpatient.Enabled = false;
                    txtage.Text = dtLoad.Rows[0]["Age"].ToString();
                    txtage.Enabled = false;
                    txtguardian.Text = dtLoad.Rows[0]["GuardianName"].ToString();
                    txtguardian.Enabled = false;
                    txtcontactno.Text = dtLoad.Rows[0]["ContactNo"].ToString();
                    txtcontactno.Enabled = false;
                    combosex.SelectedIndex = Convert.ToInt32(dtLoad.Rows[0]["Sex"]);
                    combosex.Enabled = false;

                    BindGrid();
                    btnreviewshow.Enabled = true;
                    Global.RegID = txtregid.Text;
                }
                else
                {
                    MessageBox.Show("Victim No does not exist");
                    btnreviewshow.Enabled = false;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void BindGrid()
        {
            try
            {
                Hashtable hst = new Hashtable();
                hst.Add("@RegNo", txtregid.Text.Trim());
                DataSet ds = DataAccessLayer.GetDataset("Hospital_TreatmentHistory_sp", hst);
                PatientDetails.DataSource = null;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    PatientDetails.DataSource = ds.Tables[0];
                    PatientDetails.Columns[7].Visible = false;
                    PatientDetails.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    DataGridViewCellStyle style = PatientDetails.ColumnHeadersDefaultCellStyle;
                    style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    style.Font = new Font(PatientDetails.Font, FontStyle.Bold);
                    PatientDetails.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
                    PatientDetails.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    PatientDetails.EnableHeadersVisualStyles = false;

                    this.PatientDetails.Columns["Treatment Fees"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.PatientDetails.Columns["Discount Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.PatientDetails.Columns["Paid Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.PatientDetails.Columns["Due Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        private void PatientDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                indexRow = e.RowIndex;
                DataGridViewRow row = PatientDetails.Rows[indexRow];
                Global.TreatmentHistoryID = row.Cells[7].Value.ToString();
                Global.TreatmentNo = row.Cells[0].Value.ToString();
                Global.TreatmentName = row.Cells[1].Value.ToString();
                Global.Discount = row.Cells[4].Value.ToString();

                //this.Close();
                Global.New = "Edit";

                ReviewForm r = new ReviewForm();
                r.ShowDialog(this);
                r.StartPosition = FormStartPosition.CenterScreen;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        #endregion

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected void Clear()
        {
            txtregid.Text = String.Empty;
            cbosubtitle.SelectedIndex = 0;
            txtpatient.Text = String.Empty;
            txtguardian.Text = String.Empty;
            cbosubtitle.SelectedIndex = 0;
            txtage.Text = string.Empty;
            combosex.SelectedIndex = 0;
            txtdod.Text = String.Empty;
        }

        private void btnreviewshow_Click(object sender, EventArgs e)
        {
            try
            {
                //this.Close();
                Global.New = "new";
                Global.Discount = "0.00";
                ReviewForm objreg = new ReviewForm();
                objreg.ShowDialog(this);
                objreg.StartPosition = FormStartPosition.CenterScreen;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnSearchLookup_Click_1(object sender, EventArgs e)
        {
            using (PatientSearch childform = new PatientSearch())
            {
                childform.ShowDialog(this);
            }
        }

        private void btnSearchLookup_Click_2(object sender, EventArgs e)
        {
            using (PatientSearch childform = new PatientSearch())
            {
                childform.ShowDialog(this);
            }
        }

        private void txtcontactno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtage_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '/'))
            {
                e.Handled = true;
            }

            if (e.KeyChar == '/' && txtregid.Text.IndexOf('/') > -1)
            {
                e.Handled = true;
            }
        }

        private void txtregid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch.PerformClick();
            }
        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            RegisterForm r = new RegisterForm();
            r.ShowDialog(this);
        }

        private void PatientDetails_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Right)
                {
                    this.PatientDetails.Rows[e.RowIndex].Selected = true;
                    indexRow = e.RowIndex;
                    this.PatientDetails.CurrentCell = this.PatientDetails.Rows[e.RowIndex].Cells[1];
                    this.contextMenuStrip1.Show(this.PatientDetails, e.Location);
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                contextMenuStrip1.Hide();
                if (MessageBox.Show("Do you want to Print ?", "Print - Treatment History", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    foreach (DataGridViewRow item in this.PatientDetails.SelectedRows)
                    {
                        DataGridViewRow row = PatientDetails.Rows[indexRow];
                        Global.PrintTreatmentHistoryID = row.Cells[7].Value.ToString();
                        Printers prt = new Printers();
                        prt.TreatmentHistoryRecepit(VictimID.ToString());
                        MessageBox.Show("Printed Successfully", "Print _ Success");
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

    }
}
