﻿namespace Sample
{
    partial class PaymentReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.gremaltes_PaymentReceiptSPBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gremaltesPaymentReceipt = new Sample.GremaltesPaymentReceipt();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.gremaltes_PaymentReceiptSPTableAdapter = new Sample.GremaltesPaymentReceiptTableAdapters.Gremaltes_PaymentReceiptSPTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.gremaltes_PaymentReceiptSPBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gremaltesPaymentReceipt)).BeginInit();
            this.SuspendLayout();
            // 
            // gremaltes_PaymentReceiptSPBindingSource
            // 
            this.gremaltes_PaymentReceiptSPBindingSource.DataMember = "Gremaltes_PaymentReceiptSP";
            this.gremaltes_PaymentReceiptSPBindingSource.DataSource = this.gremaltesPaymentReceipt;
            // 
            // gremaltesPaymentReceipt
            // 
            this.gremaltesPaymentReceipt.DataSetName = "GremaltesPaymentReceipt";
            this.gremaltesPaymentReceipt.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "dsPaymentReceipt";
            reportDataSource1.Value = this.gremaltes_PaymentReceiptSPBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Sample.PaymentReceipt.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(12, 12);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(581, 350);
            this.reportViewer1.TabIndex = 0;
            // 
            // gremaltes_PaymentReceiptSPTableAdapter
            // 
            this.gremaltes_PaymentReceiptSPTableAdapter.ClearBeforeFill = true;
            // 
            // PaymentReceipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 379);
            this.Controls.Add(this.reportViewer1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PaymentReceipt";
            this.Text = "Payment Receipt";
            this.Load += new System.EventHandler(this.PaymentReceipt_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gremaltes_PaymentReceiptSPBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gremaltesPaymentReceipt)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private GremaltesPaymentReceipt gremaltesPaymentReceipt;
        private System.Windows.Forms.BindingSource gremaltes_PaymentReceiptSPBindingSource;
        private GremaltesPaymentReceiptTableAdapters.Gremaltes_PaymentReceiptSPTableAdapter gremaltes_PaymentReceiptSPTableAdapter;
    }
}