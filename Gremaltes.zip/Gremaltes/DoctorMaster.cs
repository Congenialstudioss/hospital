﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class DoctorMaster : Form
    {
        int indexRow;
        public DoctorMaster()
        {
            InitializeComponent();
            LoadDoctor();
            ddlSurName.SelectedIndex = 1;
            txtcontactno.MaxLength = 10;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtdoctor.Text != String.Empty && txtcontactno.Text != String.Empty)
                {
                    if (btnsave.Text == "Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@Action", "Insert");
                        hstbl.Add("SubTitle", ddlSurName.SelectedIndex);
                        hstbl.Add("@ModifyBy", Global.UserID);
                        hstbl.Add("@DoctorName", txtdoctor.Text.Trim());
                        hstbl.Add("@ContactNo", txtcontactno.Text.Trim());
                        Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_SaveDoctorMaster_sp", hstbl);
                        if (intIdentity > 0)
                        {
                            MessageBox.Show("Doctor Details Saved Successfully.", "Doctor Master Alert");
                            txtdoctor.Text = String.Empty;
                            ddlSurName.SelectedIndex = 1;
                            txtcontactno.Text = String.Empty;
                            LoadDoctor();
                        }
                    }

                    else if (btnsave.Text == "Update")
                    {
                        Hashtable hstbl = new Hashtable();
                        DataGridViewRow row = GvDoctor.Rows[indexRow];

                        hstbl.Add("@Action", "Update");
                        hstbl.Add("SubTitle", ddlSurName.SelectedIndex);
                        hstbl.Add("@ModifyBy", Global.UserID);
                        hstbl.Add("@DoctorName", txtdoctor.Text.Trim());
                        hstbl.Add("@ContactNo", txtcontactno.Text.Trim());
                        hstbl.Add("@DoctorId", row.Cells[1].Value);
                        Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_SaveDoctorMaster_sp", hstbl);
                        if (intIdentity > 0)
                        {
                            MessageBox.Show("Doctor Details Updated Successfully.", "Doctor Master Alert");
                            txtdoctor.Text = String.Empty;
                            ddlSurName.SelectedIndex = 1;
                            txtcontactno.Text = String.Empty;
                            LoadDoctor();
                            btnsave.Text = "Save";
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the Doctor name and ContactNo", "Doctor Master Alert");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        protected void LoadDoctor()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("Action", "Get");
                DataSet ds = DataAccessLayer.GetDataset("Hospital_SaveDoctorMaster_sp", hstbl);
                GvDoctor.DataSource = null;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    GvDoctor.DataSource = ds.Tables[0];
                    GvDoctor.Columns[1].Visible = false;
                    GvDoctor.Columns[4].Visible = false;
                    GvDoctor.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    DataGridViewCellStyle style = GvDoctor.ColumnHeadersDefaultCellStyle;
                    style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    style.Font = new Font(GvDoctor.Font, FontStyle.Bold);
                    GvDoctor.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
                    GvDoctor.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    GvDoctor.EnableHeadersVisualStyles = false;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Gvtreatment_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                indexRow = e.RowIndex;
                DataGridViewRow row = GvDoctor.Rows[indexRow];
                txtdoctor.Text = row.Cells[2].Value.ToString();
                txtcontactno.Text = row.Cells[3].Value.ToString();
                ddlSurName.SelectedIndex = Convert.ToInt32(row.Cells[4].Value.ToString());
                btnsave.Text = "Update";
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                contextMenuStrip1.Hide();
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = GvDoctor.Rows[indexRow];

                    hstbl.Add("@Action", "Delete");
                    hstbl.Add("@ModifyBy", Global.UserID);
                    hstbl.Add("@DoctorId", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_SaveDoctorMaster_sp", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show("Doctor Details Deleted Successfully.", "Doctor Master Alert");
                        txtdoctor.Text = String.Empty;
                        LoadDoctor();
                        btnsave.Text = "Save";
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        private void Gvtreatment_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Right)
                {
                    this.GvDoctor.Rows[e.RowIndex].Selected = true;
                    indexRow = e.RowIndex;
                    this.GvDoctor.CurrentCell = this.GvDoctor.Rows[e.RowIndex].Cells[2];
                    this.contextMenuStrip1.Show(this.GvDoctor, e.Location);
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void txtcontactno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtcontactno_TextChanged(object sender, EventArgs e)
        {
            if (txtcontactno.TextLength == 10)
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@ContactNo", txtcontactno.Text.Trim());

                DataTable dt = DataAccessLayer.GetDataTable("Hospital_CheckMobileNo_sp", hstbl);

                if (dt != null && dt.Rows.Count > 0)
                {
                    MessageBox.Show("Mobile Number is Exists. Enter another mobile number", "Mobile Number - Error");
                    btnsave.Enabled = false;
                }
                else
                {
                    btnsave.Enabled = true;
                }
            }
        }

    }
}
