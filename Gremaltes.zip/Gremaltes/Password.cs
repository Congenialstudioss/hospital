﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace Hospital.Models
{
    public class Password
    {
        public class PwdCommon
        {

            public long AttributeId { get; set; }
            public string ControlId { get; set; }
            public string LabelName { get; set; }
            public long GroupId { get; set; }
            public string GroupName { get; set; }
            public string ValueType { get; set; }
            public long ValueId { get; set; }
            public string Min { get; set; }
            public string Max { get; set; }
            public string ValueAssign { get; set; }
            public string Monthly { get; set; }
            public string Yearly { get; set; }
            public string Amount { get; set; }

            public List<PwdCommon> ControlList { get; set; }


            #region Login Functions
            string passPhrase = "It6as6Pass";        // can be any string
            string saltValue = "s@1tValue";        // can be any string
            string hashAlgorithm = "SHA1";             // can be "MD5"
            int passwordIterations = 4;                  // can be any number
            string initVector = "@1B2c3D4e5F6g7H8"; // must be 16 bytes
            int keySize = 256;                // can be 192 or 128

            public static string Encrypt(string plainText)
            {

                PwdCommon objCommon = new PwdCommon();

                byte[] initVectorBytes = Encoding.ASCII.GetBytes(objCommon.initVector);
                byte[] saltValueBytes = Encoding.ASCII.GetBytes(objCommon.saltValue);

                byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);

                PasswordDeriveBytes password = new PasswordDeriveBytes(
                                                                objCommon.passPhrase,
                                                                saltValueBytes,
                                                                objCommon.hashAlgorithm,
                                                                objCommon.passwordIterations);

                byte[] keyBytes = password.GetBytes(objCommon.keySize / 8);

                RijndaelManaged symmetricKey = new RijndaelManaged();

                symmetricKey.Mode = CipherMode.CBC;

                ICryptoTransform encryptor = symmetricKey.CreateEncryptor(
                                                                 keyBytes,
                                                                 initVectorBytes);

                MemoryStream memoryStream = new MemoryStream();

                CryptoStream cryptoStream = new CryptoStream(memoryStream,
                                                             encryptor,
                                                             CryptoStreamMode.Write);

                cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);

                cryptoStream.FlushFinalBlock();

                byte[] cipherTextBytes = memoryStream.ToArray();
                memoryStream.Close();
                cryptoStream.Close();
                string cipherText = Convert.ToBase64String(cipherTextBytes);
                return cipherText;
            }

            public static string Decrypt(string cipherText)
            {

                PwdCommon objCommon = new PwdCommon();
                byte[] initVectorBytes = Encoding.ASCII.GetBytes(objCommon.initVector);
                byte[] saltValueBytes = Encoding.ASCII.GetBytes(objCommon.saltValue);

                // Convert our ciphertext into a byte array.
                byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
                PasswordDeriveBytes password = new PasswordDeriveBytes(
                                                                objCommon.passPhrase,
                                                                saltValueBytes,
                                                                objCommon.hashAlgorithm,
                                                                objCommon.passwordIterations);


                byte[] keyBytes = password.GetBytes(objCommon.keySize / 8);


                RijndaelManaged symmetricKey = new RijndaelManaged();

                symmetricKey.Mode = CipherMode.CBC;

                ICryptoTransform decryptor = symmetricKey.CreateDecryptor(
                                                                 keyBytes,
                                                                 initVectorBytes);

                MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
                CryptoStream cryptoStream = new CryptoStream(memoryStream,
                                                              decryptor,
                                                              CryptoStreamMode.Read);
                byte[] plainTextBytes = new byte[cipherTextBytes.Length];
                int decryptedByteCount = cryptoStream.Read(plainTextBytes,
                                                           0,
                                                           plainTextBytes.Length);

                memoryStream.Close();
                cryptoStream.Close();
                string plainText = Encoding.UTF8.GetString(plainTextBytes,
                                                           0,
                                                           decryptedByteCount);

                return plainText;
            }

            #endregion





        }
    }
}