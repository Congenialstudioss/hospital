﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using Sample;
using System.IO;
using System.Drawing.Printing;
using System.Diagnostics;
using System.Configuration;
using Sample.DataAccess;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication3
{
    public partial class ReviewForm : Form
    {
        static Int32 Fees_ID = 0;
        static Int32 VictimID = 0;
        private string childMessage;

        public string ChildMessage
        {
            get { return childMessage; }
            set { childMessage = value; }
        }
        public string _valueVictimID = string.Empty;



        public ReviewForm()
        {
            InitializeComponent();
        }

        #region Form Events
        private void ReviewForm_Load(object sender, EventArgs e)
        {
            txtregid.Focus();
            txtregid.Select();
            txtregid.Text = _valueVictimID;
            cbosubtitle.SelectedIndex = 1;
            LoadDropDown();
            dtreviewdate.Value = dtreviewdate.Value.AddDays(5);
            dtreviewdate.MinDate = dtreviewdate.Value.AddDays(5);

            ddltreatment.SelectedValue = 1;
            Txt_TreatmentFee.Enabled = false;

            txtregid.MaxLength = 15;

            txtregid.Text = Global.RegID;
            DisplayRecord();
            txtpaidedamount.Text = "0";
            var newform = Global.New;
            txtreatmentno.Visible = false;
            lbltreatmentno.Visible = false;
            ddltreatment.Enabled = true;
            ddlpayment.SelectedIndex = 0;

            if (Global.Discount != "0.00")
            {
                txtdiscount.Text = Global.Discount;
            }

            if (newform == "Edit")
            {
                BindGrid();
                ddltreatment.Text = Global.TreatmentName;
                ddltreatment.Enabled = false;
                txtreatmentno.Visible = true;
                lbltreatmentno.Visible = true;
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtregid.Text != String.Empty)
            {
                int i = SaveData();
                if (i == 1)
                {
                    Clear();
                    ReviewForm_Load(sender, e);
                }
            }
            else
            {
                MessageBox.Show("Enter Victim No", "Review - Error");
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Print ?", "Print - Victim Review", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
                PrintVictim();
            }
        }

        private void ReviewForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (Control.ModifierKeys == Keys.Control && e.KeyCode == Keys.S)
            {
                SaveData();
            }
            else if (Control.ModifierKeys == Keys.Control && e.KeyCode == Keys.P)
            {
                PrintVictim();
            }
        }

        private void btnSearchLookup_Click(object sender, EventArgs e)
        {

        }

        private void txtpatient_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsUpper(e.KeyChar) || char.IsLower(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar.ToString() == ".")
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void txtguardian_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsUpper(e.KeyChar) || char.IsLower(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar.ToString() == "." || e.KeyChar.ToString() == "/")
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void txtage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }


        private void txtpincode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void cbosubtitle_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ComboBox comboBox = (ComboBox)sender;

                // Save the selected employee's name, because we will remove 
                // the employee's name from the list. 
                string selectedValue = (string)cbosubtitle.SelectedItem;

                if (selectedValue == "MR" || selectedValue == "SR." || selectedValue == "MASTER.")
                {
                    combosex.SelectedIndex = 0;
                }
                else
                {
                    combosex.SelectedIndex = 1;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        #endregion

        #region User Defined Methods

        public int SaveData()
        {
            if (VictimID != 0)
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@VictimID", VictimID != 0 ? VictimID : (object)DBNull.Value);

                hstbl.Add("@ReviewDate", dtptransdate.Value);
                hstbl.Add("@NextVisitDate", dtreviewdate.Value);
                hstbl.Add("@ReviewBy", cmbdoctor.SelectedValue);
                hstbl.Add("@TreatmentId", ddltreatment.SelectedValue);
                hstbl.Add("@ModifyBy", Global.UserID);

                if (Global.TreatmentNo != null)
                {
                    hstbl.Add("@TreatmentNo", Global.TreatmentNo);
                }
                if (Global.TreatmentHistoryID != null)
                {
                    hstbl.Add("@TreatmentHistoryId", Global.TreatmentHistoryID);
                }
                if (txtdiscount.Text != "")
                {
                    hstbl.Add("@Discount", txtdiscount.Text);
                }
                if (txtpaidamount.Text != "")
                {
                    hstbl.Add("@PaidAmount", txtpaidamount.Text);
                }
                if (txtremarks.Text != "")
                {
                    hstbl.Add("@Remarks", txtremarks.Text);
                }

                if (ddlpayment.Text != "")
                {
                    hstbl.Add("@PaymentMode", ddlpayment.Text);
                }
                if (txtchequeno.Text != "")
                {
                    hstbl.Add("@Cheque_CardNo", txtchequeno.Text);
                }
                if (dtchequedate.Enabled == true)
                {
                    hstbl.Add("@ChequeDate", dtchequedate.Value);
                }
                if (txtbankname.Text != "")
                {
                    hstbl.Add("@BankName", txtbankname.Text);
                }

                Int64 Result = DataAccessLayer.ReturnInsertDataCommand("Hospital_ReviewVictim_InsertUpdate", hstbl);

                DialogResult result = MessageBox.Show("Victim Review Sucessfully, Do you Want Receipt", "Review - Success", MessageBoxButtons.YesNo);
                btnPrint.Visible = true;
                if (result == DialogResult.Yes)
                {
                    //Printers prt = new Printers();
                    //prt.ReviewRecepitData(VictimID);
                    //MessageBox.Show("Printed Successfully", "Print _ Success");

                    ReviewPrint rev = new ReviewPrint();                  
                    rev.ReviewRecepitData(VictimID);
                    rev.ShowDialog(this);

                    txtpaidamount.Text = String.Empty;
                    txtremarks.Text = String.Empty;
                    txtdiscount.Text = String.Empty;
                    return 0;
                }
                else
                {
                    txtpaidamount.Text = String.Empty;
                    txtremarks.Text = String.Empty;
                    txtdiscount.Text = String.Empty;
                    return 1;
                }
            }
            else
            {
                MessageBox.Show("Invalid Victim Information", "Review - Error");
                return 0;
            }
        }

        protected void DisplayRecord()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@pi_RegisterID", txtregid.Text.Trim());
                DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_ReviewForm_Fetch_Sp", hstbl);
                var newform = Global.New;
                if (newform == "new")
                {
                    PatientDetails.Visible = false;
                    this.Size = new System.Drawing.Size(765, 463);
                    btnSave.Location = new System.Drawing.Point(285, 379);
                    btnPrint.Location = new System.Drawing.Point(389, 379);
                }
                if (dtLoad != null && dtLoad.Rows.Count > 0)
                {
                    VictimID = Convert.ToInt32(dtLoad.Rows[0]["VictimId"].ToString());
                    //dtptransdate.Text = dtLoad.Rows[0]["RegDate"].ToString();
                    cbosubtitle.SelectedIndex = Convert.ToInt32(dtLoad.Rows[0]["SubTitle"].ToString());
                    txtpatient.Text = dtLoad.Rows[0]["Name"].ToString();
                    txtpatient.Enabled = false;
                    txtage.Text = dtLoad.Rows[0]["Age"].ToString();
                    txtage.Enabled = false;
                    txtguardian.Text = dtLoad.Rows[0]["GuardianName"].ToString();
                    txtguardian.Enabled = false;
                    combosex.SelectedIndex = Convert.ToInt32(dtLoad.Rows[0]["Sex"]);
                    combosex.Enabled = false;
                    txtreatmentno.Text = Global.TreatmentNo;
                }
                else
                {
                    MessageBox.Show("Victim No does not exist", "Review - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        public void PrintVictim()
        {
            try
            {
                if (txtregid.Text != string.Empty)
                {
                    //Printers obj = new Printers();
                    //obj.ReviewRecepitData(VictimID);
                    //MessageBox.Show("Printed Successfully", "Print _ Success");

                    ReviewPrint rev = new ReviewPrint();
                    //this.Visible = false;
                    rev.ReviewRecepitData(VictimID);
                    rev.ShowDialog(this);
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        #endregion

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected void Clear()
        {
            txtregid.Text = String.Empty;
            cbosubtitle.SelectedIndex = 0;
            txtpatient.Text = String.Empty;
            txtguardian.Text = String.Empty;
            cbosubtitle.SelectedIndex = 0;
            txtage.Text = string.Empty;
            combosex.SelectedIndex = 0;
            txtchequeno.Text = string.Empty;
            txtbankname.Text = string.Empty;
            ddlpayment.SelectedIndex = 0;
            dtchequedate.Value = DateTime.Now;
            txtdiscount.Enabled = false;
            chkdiscount.Checked = false;
        }

        public void LoadDropDown()
        {
            try
            {
                System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("Hospital_GetDoctorMaster_sp");

                if (dsLoad != null)
                {
                    if (dsLoad.Rows.Count > 0)
                    {
                        cmbdoctor.DataSource = new BindingSource(dsLoad, null);
                        cmbdoctor.DisplayMember = "DoctorName";
                        cmbdoctor.ValueMember = "DoctorId";
                        cmbdoctor.SelectedValue = 1;
                    }
                    System.Data.DataTable dsLoad1 = DataAccessLayer.GetDataTable("Hospital_TreatmentMaster_sp");

                    if (dsLoad1 != null)
                    {
                        if (dsLoad1.Rows.Count > 0)
                        {
                            ddltreatment.DataSource = new BindingSource(dsLoad1, null);
                            ddltreatment.DisplayMember = "TreatmentName";
                            ddltreatment.ValueMember = "TreatmentId";
                            ddltreatment.SelectedValue = 1;
                        }
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void BindGrid()
        {
            try
            {
                Hashtable hst = new Hashtable();
                hst.Add("@RegNo", txtregid.Text.Trim());
                hst.Add("@TreatmentHistoryId", Convert.ToInt32(Global.TreatmentHistoryID));
                DataSet ds = DataAccessLayer.GetDataset("Hospital_TreatmentReviewHistory_sp", hst);
                PatientDetails.DataSource = null;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    PatientDetails.DataSource = ds.Tables[0];
                    PatientDetails.Columns[5].Visible = false;
                    PatientDetails.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    DataGridViewCellStyle style = PatientDetails.ColumnHeadersDefaultCellStyle;
                    style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    style.Font = new Font(PatientDetails.Font, FontStyle.Bold);
                    PatientDetails.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
                    PatientDetails.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    PatientDetails.EnableHeadersVisualStyles = false;

                    this.PatientDetails.Columns["Paid Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                    int sum = 0;
                    for (int i = 0; i < PatientDetails.Rows.Count; ++i)
                    {
                        sum += Convert.ToInt32(PatientDetails.Rows[i].Cells[2].Value);
                    }
                    txtpaidedamount.Text = sum.ToString();
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void ddltreatment_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddltreatment.SelectedValue.ToString() == "System.Data.DataRowView")
                {
                    Hashtable htbl = new Hashtable();
                    htbl.Add("@TreatmentID", 1);
                    DataTable dt = DataAccessLayer.GetDataTable("Hospital_TreatmentFeeLoad_SP", htbl);
                    Txt_TreatmentFee.Text = dt.Rows[0]["Fee"].ToString();
                }
                else
                {
                    Hashtable htbl = new Hashtable();
                    htbl.Add("@TreatmentID", ddltreatment.SelectedValue);
                    DataTable dt = DataAccessLayer.GetDataTable("Hospital_TreatmentFeeLoad_SP", htbl);
                    Txt_TreatmentFee.Text = dt.Rows[0]["Fee"].ToString();
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void chkdiscount_CheckedChanged(object sender, EventArgs e)
        {
            if (chkdiscount.Checked == true)
            {
                if (Global.Discount == "0.00")
                {
                    txtdiscount.Enabled = true;
                }
            }
            else
            {
                txtdiscount.Enabled = false;
            }
        }

        private void txtdiscount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtdiscount.Text != String.Empty)
                {
                    string discountvalue = txtdiscount.Text;
                    decimal discountintvalue = decimal.Parse(discountvalue);

                    string treatmentfees = Txt_TreatmentFee.Text;
                    decimal treatmentfeesint = decimal.Parse(treatmentfees);

                    string paidedvalue = txtpaidedamount.Text;
                    decimal paidedintvalue = decimal.Parse(paidedvalue);

                    if (txtpaidamount.Text == "")
                    {
                        txtpaidamount.Text = "0";
                    }

                    string paidamountvalue = txtpaidamount.Text;
                    decimal paidamountintvalue = decimal.Parse(paidamountvalue);

                    decimal pendingamount = treatmentfeesint - paidedintvalue;

                    decimal amount = pendingamount - paidamountintvalue;

                    if (txtpaidamount.Text != String.Empty)
                    {
                        if (discountintvalue > amount)
                        {
                            MessageBox.Show("Please Enter less than or equal to the pending amount", "Review - Error");
                            btnSave.Enabled = false;
                            btnPrint.Enabled = false;
                        }
                        else
                        {
                            btnSave.Enabled = true;
                            btnPrint.Enabled = true;
                        }
                    }
                    else
                    {
                        if (discountintvalue > pendingamount)
                        {
                            MessageBox.Show("Please Enter less than or equal to the pending amount", "Review - Error");
                            btnSave.Enabled = false;
                            btnPrint.Enabled = false;
                        }
                        else
                        {
                            btnSave.Enabled = true;
                            btnPrint.Enabled = true;
                        }
                    }
                }
                else
                {
                    btnSave.Enabled = true;
                    btnPrint.Enabled = true;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnSearchLookup_Click_1(object sender, EventArgs e)
        {
            using (PatientSearch childform = new PatientSearch())
            {
                childform.ShowDialog(this);
            }
        }

        private void txtpaidamount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtpaidamount.Text != String.Empty)
                {
                    if (txtdiscount.Text != String.Empty)
                    {
                        string paidamountvalue = txtpaidamount.Text;
                        decimal paidamountintvalue = decimal.Parse(paidamountvalue);

                        string treatmentfees = Txt_TreatmentFee.Text;
                        decimal treatmentfeesint = decimal.Parse(treatmentfees);

                        string discountvalue = txtdiscount.Text;
                        decimal discountintvalue = decimal.Parse(discountvalue);

                        string paidedvalue = txtpaidedamount.Text;
                        decimal paidedintvalue = decimal.Parse(paidedvalue);

                        decimal pendingamount = (treatmentfeesint - (discountintvalue + paidedintvalue));

                        if (paidamountintvalue > pendingamount)
                        {
                            MessageBox.Show("Please Enter less than or equal to the pending amount", "Review - Error");
                            btnSave.Enabled = false;
                            btnPrint.Enabled = false;
                        }
                        else
                        {
                            btnSave.Enabled = true;
                            btnPrint.Enabled = true;
                        }
                    }
                    else
                    {
                        if (txtpaidedamount.Text != String.Empty)
                        {
                            string paidamountvalue = txtpaidamount.Text;
                            decimal paidamountintvalue = decimal.Parse(paidamountvalue);

                            string treatmentfees = Txt_TreatmentFee.Text;
                            decimal treatmentfeesint = decimal.Parse(treatmentfees);

                            string discountvalue = txtpaidedamount.Text;
                            decimal discountintvalue = decimal.Parse(discountvalue);

                            decimal pendingamount = treatmentfeesint - discountintvalue;

                            if (paidamountintvalue > pendingamount)
                            {
                                MessageBox.Show("Please Enter less than or equal to the pending amount", "Review - Error");
                                btnSave.Enabled = false;
                                btnPrint.Enabled = false;
                            }
                            else
                            {
                                btnSave.Enabled = true;
                                btnPrint.Enabled = true;
                            }
                        }
                        else
                        {
                            string paidamountvalue = txtpaidamount.Text;
                            decimal paidamountintvalue = decimal.Parse(paidamountvalue);

                            string treatmentfees = Txt_TreatmentFee.Text;
                            decimal treatmentfeesint = decimal.Parse(treatmentfees);

                            if (paidamountintvalue > treatmentfeesint)
                            {
                                MessageBox.Show("Please Enter less than or equal to the pending amount", "Review - Error");
                                btnSave.Enabled = false;
                                btnPrint.Enabled = false;
                            }
                            else
                            {
                                btnSave.Enabled = true;
                                btnPrint.Enabled = true;
                            }
                        }
                    }
                }
                else
                {
                    btnSave.Enabled = true;
                    btnPrint.Enabled = true;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void txtpaidamount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtdiscount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void ReviewForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Global.New = null;
            Global.TreatmentName = null;
            Global.TreatmentNo = null;
            Global.TreatmentHistoryID = null;
            Global.Discount = "0.00";
            txtdiscount.Text = String.Empty;
            txtpaidedamount.Text = String.Empty;

            string val = txtregid.Text.Trim();
            TreatmentHistory parent = (TreatmentHistory)this.Owner;
            parent.updatetext(val);
        }

        private void ddlpayment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlpayment.Text == "Cheque")
            {
                txtchequeno.Enabled = true;
                dtchequedate.Enabled = true;
                txtbankname.Enabled = true;
                lblchqno.Text = "Cheque No";
            }
            else if (ddlpayment.Text == "Credit/Debit Card")
            {
                txtchequeno.Enabled = true;
                dtchequedate.Enabled = false;
                txtbankname.Enabled = false;
                lblchqno.Text = "Card No";
            }
            else
            {
                txtchequeno.Enabled = false;
                dtchequedate.Enabled = false;
                txtbankname.Enabled = false;
                lblchqno.Text = "Cheque/Card No";
            }
        }

    }
}
