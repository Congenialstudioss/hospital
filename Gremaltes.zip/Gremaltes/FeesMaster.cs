﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Resources;
using System.Reflection;

namespace Sample
{
    public partial class FeesMaster : Form
    {
        DataAccessLayer objDataLayer = new DataAccessLayer();
        ResourceManager ResManager = new ResourceManager("Resources", Assembly.GetExecutingAssembly());

        public FeesMaster()
        {
            InitializeComponent();

            // Define the border style of the form to a dialog box.
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            // Set the MaximizeBox to false to remove the maximize box.
            this.MaximizeBox = false;
            // Set the MinimizeBox to false to remove the minimize box.
            this.MinimizeBox = false;
            // Set the start position of the form to the center of the screen.
            this.StartPosition = FormStartPosition.CenterScreen;
            //this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            // Display the form as a modal dialog box.
            // this.ShowDialog();
        }

        public void FeesMaster_Load(object sender, EventArgs e)
        {
            LoadFees();
            //LoadTreatmentDropDown();
            //ddlType.SelectedIndex = 0;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (is_validate())
                {
                    Hashtable hstbl = new Hashtable();
                    hstbl.Add("@ConsultingFees", txtConsultingFee.Text);
                    hstbl.Add("@RegisterFees", txtRegisterFee.Text);
                    //hstbl.Add("@Type", ddlType.SelectedItem.ToString());
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_FeesSave_Sp", hstbl);
                    //if (intIdentity > 0)
                    //{
                    MessageBox.Show("Fees Details Saved Successfully.", "Fees Master Alert");

                    LoadFees();
                    //this.Close();
                    //}
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        protected void LoadFees()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                //hstbl.Add("@Type", ddlType.SelectedItem != null ? ddlType.SelectedItem.ToString() : (object)DBNull.Value);
                DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_FeesDetails_Sp", hstbl);
                if (dtLoad != null && dtLoad.Rows.Count > 0)
                {
                    txtConsultingFee.Text = dtLoad.Rows[0]["Consulting"].ToString();
                    txtRegisterFee.Text = dtLoad.Rows[0]["Registration"].ToString();
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        //public void LoadTreatmentDropDown()
        //{
        //    //Dropdown list values is selected  from database without using <asp:list items>////
        //    System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("Hospital_TreatmentMaster_sp");

        //    if (dsLoad != null)
        //    {
        //        if (dsLoad.Rows.Count > 0)
        //        {
        //            ddlType.DataSource = new BindingSource(dsLoad, null);
        //            ddlType.DisplayMember = "TreatmentName";
        //            ddlType.ValueMember = "TreatmentId";
        //            ddlType.SelectedIndex = 0;
        //        }               
        //    }
        //}

        private void txtRegisterFee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private bool is_validate()
        {
            bool no_error = true;
            if (txtRegisterFee.Text == string.Empty)
            {
                ErrorMessage.SetError(txtRegisterFee, "Enter the Registration Fees");
                no_error = false;
            }
            else
            {
                ErrorMessage.SetError(this.txtRegisterFee, String.Empty);
            }

            if (txtConsultingFee.Text == String.Empty)
            {
                ErrorMessage.SetError(txtConsultingFee, "Enter the Consultation Fees");
                no_error = false;
            }
            else
            {
                ErrorMessage.SetError(this.txtConsultingFee, String.Empty);
            }
            return no_error;
        }

        private void txtConsultingFee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void ddlType_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadFees();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
