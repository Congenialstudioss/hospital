﻿namespace Sample
{
    partial class ReviewPrint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReviewPrint));
            this.ReviewPrintdoc = new System.Drawing.Printing.PrintDocument();
            this.ReviewPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.lbltransaction = new System.Windows.Forms.Label();
            this.txtdate = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.Label();
            this.txtno = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.lblAddress = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblno = new System.Windows.Forms.Label();
            this.lbltreatmentname = new System.Windows.Forms.Label();
            this.lblpaidamnt = new System.Windows.Forms.Label();
            this.lbltotal = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ReviewPrintdoc
            // 
            this.ReviewPrintdoc.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.ReviewPrintdoc_PrintPage);
            // 
            // ReviewPreviewDialog
            // 
            this.ReviewPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.ReviewPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.ReviewPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.ReviewPreviewDialog.Document = this.ReviewPrintdoc;
            this.ReviewPreviewDialog.Enabled = true;
            this.ReviewPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("ReviewPreviewDialog.Icon")));
            this.ReviewPreviewDialog.Name = "ReviewPreviewDialog";
            this.ReviewPreviewDialog.ShowIcon = false;
            this.ReviewPreviewDialog.Visible = false;
            // 
            // lbltransaction
            // 
            this.lbltransaction.AutoSize = true;
            this.lbltransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltransaction.Location = new System.Drawing.Point(556, 117);
            this.lbltransaction.Name = "lbltransaction";
            this.lbltransaction.Size = new System.Drawing.Size(0, 16);
            this.lbltransaction.TabIndex = 34;
            // 
            // txtdate
            // 
            this.txtdate.AutoSize = true;
            this.txtdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdate.Location = new System.Drawing.Point(556, 152);
            this.txtdate.Name = "txtdate";
            this.txtdate.Size = new System.Drawing.Size(0, 16);
            this.txtdate.TabIndex = 32;
            // 
            // txtname
            // 
            this.txtname.AutoSize = true;
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(198, 152);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(0, 16);
            this.txtname.TabIndex = 31;
            // 
            // txtno
            // 
            this.txtno.AutoSize = true;
            this.txtno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtno.Location = new System.Drawing.Point(198, 117);
            this.txtno.Name = "txtno";
            this.txtno.Size = new System.Drawing.Size(0, 16);
            this.txtno.TabIndex = 30;
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(363, 372);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 28;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(294, 19);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(224, 64);
            this.lblAddress.TabIndex = 35;
            this.lblAddress.Text = "Vignesh Dental Hospital\r\nNo.Z-279, 5th Avenue,\r\nAnna Nagar West, Chennai - 600 04" +
    "0\r\nPhone : 2620 9181";
            this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(144, 117);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 16);
            this.label1.TabIndex = 25;
            this.label1.Text = "No       :  ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(144, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 16);
            this.label2.TabIndex = 26;
            this.label2.Text = "Name : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(450, 117);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 16);
            this.label8.TabIndex = 33;
            this.label8.Text = "TransactionNo : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(510, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 27;
            this.label3.Text = "Date : ";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(246, 102);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Total";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(78, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Treatment Name";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(411, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Paid Amount";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.49669F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.50331F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 207F));
            this.tableLayoutPanel1.Controls.Add(this.label6, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblno, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbltreatmentname, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblpaidamnt, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbltotal, 3, 2);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(147, 202);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.15385F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.84615F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(499, 132);
            this.tableLayoutPanel1.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "S.NO";
            // 
            // lblno
            // 
            this.lblno.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblno.AutoSize = true;
            this.lblno.Location = new System.Drawing.Point(37, 57);
            this.lblno.Name = "lblno";
            this.lblno.Size = new System.Drawing.Size(0, 16);
            this.lblno.TabIndex = 7;
            this.lblno.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbltreatmentname
            // 
            this.lbltreatmentname.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbltreatmentname.AutoSize = true;
            this.lbltreatmentname.Location = new System.Drawing.Point(78, 57);
            this.lbltreatmentname.Name = "lbltreatmentname";
            this.lbltreatmentname.Size = new System.Drawing.Size(0, 16);
            this.lbltreatmentname.TabIndex = 8;
            this.lbltreatmentname.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblpaidamnt
            // 
            this.lblpaidamnt.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblpaidamnt.AutoSize = true;
            this.lblpaidamnt.Location = new System.Drawing.Point(495, 57);
            this.lblpaidamnt.Name = "lblpaidamnt";
            this.lblpaidamnt.Size = new System.Drawing.Size(0, 16);
            this.lblpaidamnt.TabIndex = 9;
            this.lblpaidamnt.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbltotal
            // 
            this.lbltotal.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lbltotal.AutoSize = true;
            this.lbltotal.Location = new System.Drawing.Point(495, 102);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(0, 16);
            this.lbltotal.TabIndex = 10;
            this.lbltotal.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // ReviewPrint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(791, 415);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lbltransaction);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtdate);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtno);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ReviewPrint";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReviewPrint";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Drawing.Printing.PrintDocument ReviewPrintdoc;
        private System.Windows.Forms.PrintPreviewDialog ReviewPreviewDialog;
        private System.Windows.Forms.Label lbltransaction;
        private System.Windows.Forms.Label txtdate;
        private System.Windows.Forms.Label txtname;
        private System.Windows.Forms.Label txtno;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblno;
        private System.Windows.Forms.Label lbltreatmentname;
        private System.Windows.Forms.Label lblpaidamnt;
        private System.Windows.Forms.Label lbltotal;
    }
}