﻿using System.Windows.Forms;
namespace Sample
{
    partial class FeesMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtConsultingFee = new System.Windows.Forms.TextBox();
            this.txtRegisterFee = new System.Windows.Forms.TextBox();
            this.lblConsultingFee = new System.Windows.Forms.Label();
            this.lblRegistration = new System.Windows.Forms.Label();
            this.ErrorMessage = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.ErrorMessage)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSave.Location = new System.Drawing.Point(259, 106);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtConsultingFee
            // 
            this.txtConsultingFee.Location = new System.Drawing.Point(190, 67);
            this.txtConsultingFee.MaxLength = 3;
            this.txtConsultingFee.Name = "txtConsultingFee";
            this.txtConsultingFee.Size = new System.Drawing.Size(225, 20);
            this.txtConsultingFee.TabIndex = 2;
            this.txtConsultingFee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtConsultingFee_KeyPress);
            // 
            // txtRegisterFee
            // 
            this.txtRegisterFee.Location = new System.Drawing.Point(190, 32);
            this.txtRegisterFee.MaxLength = 3;
            this.txtRegisterFee.Name = "txtRegisterFee";
            this.txtRegisterFee.Size = new System.Drawing.Size(225, 20);
            this.txtRegisterFee.TabIndex = 1;
            this.txtRegisterFee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRegisterFee_KeyPress);
            // 
            // lblConsultingFee
            // 
            this.lblConsultingFee.AutoSize = true;
            this.lblConsultingFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConsultingFee.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblConsultingFee.Location = new System.Drawing.Point(47, 67);
            this.lblConsultingFee.Name = "lblConsultingFee";
            this.lblConsultingFee.Size = new System.Drawing.Size(91, 13);
            this.lblConsultingFee.TabIndex = 1;
            this.lblConsultingFee.Text = "Consulting Fee";
            // 
            // lblRegistration
            // 
            this.lblRegistration.AutoSize = true;
            this.lblRegistration.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegistration.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblRegistration.Location = new System.Drawing.Point(47, 32);
            this.lblRegistration.Name = "lblRegistration";
            this.lblRegistration.Size = new System.Drawing.Size(100, 13);
            this.lblRegistration.TabIndex = 0;
            this.lblRegistration.Text = "Registration Fee";
            // 
            // ErrorMessage
            // 
            this.ErrorMessage.ContainerControl = this;
            // 
            // FeesMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 155);
            this.Controls.Add(this.txtConsultingFee);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtRegisterFee);
            this.Controls.Add(this.lblRegistration);
            this.Controls.Add(this.lblConsultingFee);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FeesMaster";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fees Master";
            this.Load += new System.EventHandler(this.FeesMaster_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ErrorMessage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtConsultingFee;
        private System.Windows.Forms.TextBox txtRegisterFee;
        private System.Windows.Forms.Label lblConsultingFee;
        private System.Windows.Forms.Label lblRegistration;
        private ErrorProvider ErrorMessage;
    }
}