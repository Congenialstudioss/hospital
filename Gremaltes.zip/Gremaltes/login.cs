﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace Sample
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
            txtpassword.Text = string.Empty;
            // The password character is an asterisk.
            txtpassword.PasswordChar = '*';
            // The control will allow no more than 14 characters.
            txtpassword.MaxLength = 14;
        }
        private void index_Load(object sender, EventArgs e)
        {

        }

        private void signin_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtusername.Text != String.Empty && txtpassword.Text != String.Empty)
                {
                    LoginMethod();
                }
                else
                {
                    MessageBox.Show("Please Enter Username and Password", "Login - Error");
                }

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.S)
            {
                LoginMethod();
            }
            if (e.Control && e.KeyCode == Keys.C)
            {
                this.Close();
            }
        }

        public void LoginMethod()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@UserName", txtusername.Text.Trim());

                var Encryptpwd = Hospital.Models.Password.PwdCommon.Encrypt(txtpassword.Text.Trim());

                hstbl.Add("@Password", Encryptpwd);
                DataTable dt = DataAccessLayer.GetDataTable("Hospital_User_Sp", hstbl);

                if (dt != null && dt.Rows.Count > 0)
                {
                    Global.UserID = dt.Rows[0].ItemArray[0].ToString();
                    Global.UserName = dt.Rows[0].ItemArray[1].ToString();

                    this.Visible = false;
                    MainMaster f = new MainMaster();

                    f.Show();

                    System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("Hospital_NotificationData_sp");

                    if (dsLoad.Rows.Count > 0)
                    {
                        Notification t = new Notification();
                        t.ShowDialog();
                    }
                    else
                    {
                        TreatmentHistory t = new TreatmentHistory();
                        t.ShowDialog();
                    }
                }
                else
                {
                    this.Visible = true;
                    MessageBox.Show("Invalid UserName/Password", "Login - Error");
                    txtusername.Text = String.Empty;
                    txtpassword.Text = String.Empty;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void newuser_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sign_Up user = new Sign_Up();
            this.Visible = false;
            user.Show();
        }

    }
}
