﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class HospitalRegisterReport : Form
    {
        public HospitalRegisterReport()
        {
            InitializeComponent();
            Txt_regno.MaxLength = 10;
        }

        private void HospitalRegisterReport_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'GremaltesRegisterDataSet.Gremlates_RegistrationReport_Sp' table. You can move, or remove it, as needed.
            //this.Gremlates_RegistrationReport_SpTableAdapter.Fill(this.GremaltesRegisterDataSet.Gremlates_RegistrationReport_Sp);
            // TODO: This line of code loads data into the 'GremaltesRegisterDataSet.Gremlates_RegistrationReport_Sp' table. You can move, or remove it, as needed.
            //this.Gremlates_RegistrationReport_SpTableAdapter.Fill(this.GremaltesRegisterDataSet.Gremlates_RegistrationReport_Sp);

            //this.reportViewer1.RefreshReport();          
        }
        public object getdata()
        {
            DataTable dt = new DataTable();
            string strcon = ConfigurationManager.ConnectionStrings["HospitalConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Hospital_RegistrationReport_Sp";
            if (Txt_regno.Text != "")
            {
                cmd.Parameters.AddWithValue("@RegNo", Txt_regno.Text);
            }
            cmd.Parameters.AddWithValue("@RegFromDate", RegisterFrom.Value);
            cmd.Parameters.AddWithValue("@RegToDate", RegisterTo.Value);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            // con.Close();
            return dt;
        }
        protected void showReport()
        {
            try
            {
                reportViewer1.Reset();
                DataTable dt = getdata() as DataTable;
                ReportDataSource rds = new ReportDataSource("DataSet1", dt);
                rds.Value = dt;
                if (dt.Rows.Count > 0)
                {
                    this.reportViewer1.ProcessingMode = ProcessingMode.Local;
                    reportViewer1.LocalReport.DataSources.Add(rds);
                    reportViewer1.LocalReport.ReportPath = @"../../RegReport.rdlc";
                 
                    //reportViewer1.LocalReport.DataSources.Add(rds);

                    //reportViewer1.LocalReport.ReportEmbeddedResource = "[Gremaltes].[Reports if Exist].[RegReport].rdlc";
                }
                else
                {
                    MessageBox.Show("No Record Found based on your search criteria !!!", "Register Report - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Btn_Search_Click(object sender, EventArgs e)
        {
            showReport();
            this.reportViewer1.RefreshReport();
        }

        private void txtcontactno_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            //    e.Handled = true;

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '/'))
            {
                e.Handled = true;
            }

            if (e.KeyChar == '/' && Txt_regno.Text.IndexOf('/') > -1)
            {
                e.Handled = true;
            }
        }
    }
}
