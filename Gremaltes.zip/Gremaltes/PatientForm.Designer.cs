﻿using System.Windows.Forms;
namespace Sample
{
    partial class PatientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtlandline = new System.Windows.Forms.TextBox();
            this.lbllandline = new System.Windows.Forms.Label();
            this.txtcontactno = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtcountry = new System.Windows.Forms.ComboBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtpincode = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtstate = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtlocation = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtbuildname = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtstreet = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtflat = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbmartial = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.btnSearchLookup = new System.Windows.Forms.Button();
            this.combosex = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtfather = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtpatient = new System.Windows.Forms.TextBox();
            this.cbosubtitle = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtuserid = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpreg = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txtregid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.diseaselist = new System.Windows.Forms.DataGridView();
            this.ddlDiseaseType = new System.Windows.Forms.ComboBox();
            this.txtdisease = new System.Windows.Forms.TextBox();
            this.diseaseadd = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.diseaselist)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtlandline);
            this.groupBox3.Controls.Add(this.lbllandline);
            this.groupBox3.Controls.Add(this.txtcontactno);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.txtcountry);
            this.groupBox3.Controls.Add(this.txtcity);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.txtpincode);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.txtstate);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.txtlocation);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.txtbuildname);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txtstreet);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txtflat);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(12, 154);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(725, 166);
            this.groupBox3.TabIndex = 72;
            this.groupBox3.TabStop = false;
            // 
            // txtlandline
            // 
            this.txtlandline.Location = new System.Drawing.Point(468, 128);
            this.txtlandline.MaxLength = 10;
            this.txtlandline.Name = "txtlandline";
            this.txtlandline.Size = new System.Drawing.Size(229, 20);
            this.txtlandline.TabIndex = 19;
            this.txtlandline.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontactno_KeyPress);
            // 
            // lbllandline
            // 
            this.lbllandline.AutoSize = true;
            this.lbllandline.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllandline.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbllandline.Location = new System.Drawing.Point(392, 128);
            this.lbllandline.Name = "lbllandline";
            this.lbllandline.Size = new System.Drawing.Size(55, 13);
            this.lbllandline.TabIndex = 64;
            this.lbllandline.Text = "Landline";
            // 
            // txtcontactno
            // 
            this.txtcontactno.Location = new System.Drawing.Point(124, 128);
            this.txtcontactno.MaxLength = 10;
            this.txtcontactno.Name = "txtcontactno";
            this.txtcontactno.Size = new System.Drawing.Size(229, 20);
            this.txtcontactno.TabIndex = 18;
            this.txtcontactno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontactno_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label18.Location = new System.Drawing.Point(19, 128);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(44, 13);
            this.label18.TabIndex = 62;
            this.label18.Text = "Mobile";
            // 
            // txtcountry
            // 
            this.txtcountry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtcountry.FormattingEnabled = true;
            this.txtcountry.Location = new System.Drawing.Point(124, 15);
            this.txtcountry.Name = "txtcountry";
            this.txtcountry.Size = new System.Drawing.Size(229, 21);
            this.txtcountry.TabIndex = 10;
            // 
            // txtcity
            // 
            this.txtcity.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtcity.Location = new System.Drawing.Point(124, 48);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(229, 20);
            this.txtcity.TabIndex = 12;
            this.txtcity.Text = "CHENNAI";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label17.Location = new System.Drawing.Point(19, 48);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 13);
            this.label17.TabIndex = 55;
            this.label17.Text = "Town/City";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label13.Location = new System.Drawing.Point(391, 78);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 53;
            this.label13.Text = "PinCode";
            // 
            // txtpincode
            // 
            this.txtpincode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtpincode.Location = new System.Drawing.Point(468, 75);
            this.txtpincode.MaxLength = 6;
            this.txtpincode.Name = "txtpincode";
            this.txtpincode.Size = new System.Drawing.Size(229, 20);
            this.txtpincode.TabIndex = 15;
            this.txtpincode.Text = "600";
            this.txtpincode.TextChanged += new System.EventHandler(this.txtpincode_TextChanged);
            this.txtpincode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpincode_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label14.Location = new System.Drawing.Point(19, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 13);
            this.label14.TabIndex = 51;
            this.label14.Text = "Country";
            // 
            // txtstate
            // 
            this.txtstate.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtstate.Location = new System.Drawing.Point(468, 19);
            this.txtstate.Name = "txtstate";
            this.txtstate.Size = new System.Drawing.Size(229, 20);
            this.txtstate.TabIndex = 11;
            this.txtstate.Text = "TAMIL NADU";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label12.Location = new System.Drawing.Point(391, 18);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 13);
            this.label12.TabIndex = 47;
            this.label12.Text = "State";
            // 
            // txtlocation
            // 
            this.txtlocation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtlocation.Location = new System.Drawing.Point(468, 101);
            this.txtlocation.Name = "txtlocation";
            this.txtlocation.Size = new System.Drawing.Size(229, 20);
            this.txtlocation.TabIndex = 17;
            this.txtlocation.TextChanged += new System.EventHandler(this.txtlocation_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label11.Location = new System.Drawing.Point(19, 74);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 13);
            this.label11.TabIndex = 45;
            this.label11.Text = "Building Name";
            // 
            // txtbuildname
            // 
            this.txtbuildname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbuildname.Location = new System.Drawing.Point(124, 75);
            this.txtbuildname.Name = "txtbuildname";
            this.txtbuildname.Size = new System.Drawing.Size(229, 20);
            this.txtbuildname.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label10.Location = new System.Drawing.Point(19, 101);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 43;
            this.label10.Text = "Street";
            // 
            // txtstreet
            // 
            this.txtstreet.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtstreet.Location = new System.Drawing.Point(124, 101);
            this.txtstreet.Name = "txtstreet";
            this.txtstreet.Size = new System.Drawing.Size(229, 20);
            this.txtstreet.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label9.Location = new System.Drawing.Point(391, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 41;
            this.label9.Text = "Location";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // txtflat
            // 
            this.txtflat.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtflat.Location = new System.Drawing.Point(468, 48);
            this.txtflat.Name = "txtflat";
            this.txtflat.Size = new System.Drawing.Size(229, 20);
            this.txtflat.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(391, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 39;
            this.label8.Text = "Flat No.";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbmartial);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.btnSearchLookup);
            this.groupBox2.Controls.Add(this.combosex);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtfather);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtage);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtpatient);
            this.groupBox2.Controls.Add(this.cbosubtitle);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(12, 69);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(725, 79);
            this.groupBox2.TabIndex = 71;
            this.groupBox2.TabStop = false;
            // 
            // cmbmartial
            // 
            this.cmbmartial.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbmartial.FormattingEnabled = true;
            this.cmbmartial.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.cmbmartial.Location = new System.Drawing.Point(562, 45);
            this.cmbmartial.Name = "cmbmartial";
            this.cmbmartial.Size = new System.Drawing.Size(154, 21);
            this.cmbmartial.TabIndex = 9;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label20.Location = new System.Drawing.Point(511, 48);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 13);
            this.label20.TabIndex = 92;
            this.label20.Text = "Martial";
            // 
            // btnSearchLookup
            // 
            this.btnSearchLookup.Image = global::Sample.Properties.Resources._1375225193_users_male;
            this.btnSearchLookup.Location = new System.Drawing.Point(468, 15);
            this.btnSearchLookup.Name = "btnSearchLookup";
            this.btnSearchLookup.Size = new System.Drawing.Size(37, 46);
            this.btnSearchLookup.TabIndex = 91;
            this.btnSearchLookup.UseVisualStyleBackColor = true;
            this.btnSearchLookup.Click += new System.EventHandler(this.btnSearchLookup_Click);
            // 
            // combosex
            // 
            this.combosex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combosex.FormattingEnabled = true;
            this.combosex.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.combosex.Location = new System.Drawing.Point(636, 14);
            this.combosex.Name = "combosex";
            this.combosex.Size = new System.Drawing.Size(80, 21);
            this.combosex.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(602, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Sex";
            // 
            // txtfather
            // 
            this.txtfather.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtfather.Location = new System.Drawing.Point(180, 45);
            this.txtfather.Name = "txtfather";
            this.txtfather.Size = new System.Drawing.Size(276, 20);
            this.txtfather.TabIndex = 8;
            this.txtfather.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfather_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(19, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Father / Guardian Name";
            // 
            // txtage
            // 
            this.txtage.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtage.Location = new System.Drawing.Point(546, 15);
            this.txtage.MaxLength = 2;
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(48, 20);
            this.txtage.TabIndex = 6;
            this.txtage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtage_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(511, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Age";
            // 
            // txtpatient
            // 
            this.txtpatient.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtpatient.Location = new System.Drawing.Point(255, 15);
            this.txtpatient.Name = "txtpatient";
            this.txtpatient.Size = new System.Drawing.Size(201, 20);
            this.txtpatient.TabIndex = 5;
            this.txtpatient.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpatient_KeyPress);
            // 
            // cbosubtitle
            // 
            this.cbosubtitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbosubtitle.FormattingEnabled = true;
            this.cbosubtitle.Items.AddRange(new object[] {
            "--Select--",
            "MR",
            "MRS",
            "MISS",
            "BABY",
            "DR"});
            this.cbosubtitle.Location = new System.Drawing.Point(180, 15);
            this.cbosubtitle.Name = "cbosubtitle";
            this.cbosubtitle.Size = new System.Drawing.Size(60, 21);
            this.cbosubtitle.TabIndex = 4;
            this.cbosubtitle.SelectedIndexChanged += new System.EventHandler(this.cbosubtitle_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(19, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Victim Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.txtuserid);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.dtpreg);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtregid);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(725, 51);
            this.groupBox1.TabIndex = 70;
            this.groupBox1.TabStop = false;
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSearch.Location = new System.Drawing.Point(229, 16);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.Search_Click);
            // 
            // txtuserid
            // 
            this.txtuserid.Enabled = false;
            this.txtuserid.Location = new System.Drawing.Point(584, 20);
            this.txtuserid.Name = "txtuserid";
            this.txtuserid.ReadOnly = true;
            this.txtuserid.Size = new System.Drawing.Size(113, 20);
            this.txtuserid.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(531, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "User Id";
            // 
            // dtpreg
            // 
            this.dtpreg.Location = new System.Drawing.Point(382, 20);
            this.dtpreg.Name = "dtpreg";
            this.dtpreg.Size = new System.Drawing.Size(134, 20);
            this.dtpreg.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(19, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Victim No";
            // 
            // txtregid
            // 
            this.txtregid.Location = new System.Drawing.Point(86, 18);
            this.txtregid.Name = "txtregid";
            this.txtregid.Size = new System.Drawing.Size(135, 20);
            this.txtregid.TabIndex = 1;
            this.txtregid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtregid_KeyDown);
            this.txtregid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtregid_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(310, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Reg Date";
            // 
            // btnPrint
            // 
            this.btnPrint.Enabled = false;
            this.btnPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnPrint.Location = new System.Drawing.Point(513, 532);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 25;
            this.btnPrint.Text = "&Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Visible = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Enabled = false;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnDelete.Location = new System.Drawing.Point(420, 532);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 24;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSave.Location = new System.Drawing.Point(325, 532);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 23;
            this.btnSave.Text = "&Update";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // diseaselist
            // 
            this.diseaselist.AllowUserToAddRows = false;
            this.diseaselist.BackgroundColor = System.Drawing.SystemColors.Window;
            this.diseaselist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.diseaselist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.diseaselist.Location = new System.Drawing.Point(12, 366);
            this.diseaselist.Name = "diseaselist";
            this.diseaselist.Size = new System.Drawing.Size(725, 150);
            this.diseaselist.TabIndex = 75;
            this.diseaselist.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.diseaselist_CellDoubleClick);
            this.diseaselist.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.diseaselist_CellMouseUp);
            // 
            // ddlDiseaseType
            // 
            this.ddlDiseaseType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlDiseaseType.FormattingEnabled = true;
            this.ddlDiseaseType.Location = new System.Drawing.Point(84, 329);
            this.ddlDiseaseType.Name = "ddlDiseaseType";
            this.ddlDiseaseType.Size = new System.Drawing.Size(158, 21);
            this.ddlDiseaseType.TabIndex = 20;
            // 
            // txtdisease
            // 
            this.txtdisease.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdisease.Location = new System.Drawing.Point(325, 329);
            this.txtdisease.Multiline = true;
            this.txtdisease.Name = "txtdisease";
            this.txtdisease.Size = new System.Drawing.Size(317, 21);
            this.txtdisease.TabIndex = 21;
            // 
            // diseaseadd
            // 
            this.diseaseadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diseaseadd.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.diseaseadd.Location = new System.Drawing.Point(648, 329);
            this.diseaseadd.Name = "diseaseadd";
            this.diseaseadd.Size = new System.Drawing.Size(75, 23);
            this.diseaseadd.TabIndex = 22;
            this.diseaseadd.Text = "Add";
            this.diseaseadd.UseVisualStyleBackColor = true;
            this.diseaseadd.Click += new System.EventHandler(this.diseaseadd_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label15.Location = new System.Drawing.Point(18, 332);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(58, 13);
            this.label15.TabIndex = 79;
            this.label15.Text = "Diseases";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(134, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.deleteRowToolStripMenuItem.Text = "Delete Row";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label16.Location = new System.Drawing.Point(248, 332);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 13);
            this.label16.TabIndex = 80;
            this.label16.Text = "Description";
            // 
            // PatientForm
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 570);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.diseaseadd);
            this.Controls.Add(this.txtdisease);
            this.Controls.Add(this.ddlDiseaseType);
            this.Controls.Add(this.diseaselist);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Location = new System.Drawing.Point(300, 0);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PatientForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Victim Form";
            this.Load += new System.EventHandler(this.PatientForm_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.diseaselist)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtpincode;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtstate;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtlocation;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtbuildname;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtstreet;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtflat;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox combosex;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtfather;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtpatient;
        private System.Windows.Forms.ComboBox cbosubtitle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dtpreg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtregid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtuserid;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private ComboBox txtcountry;
        private Label label18;
        private TextBox txtcontactno;
        private DataGridView diseaselist;
        private ComboBox ddlDiseaseType;
        private TextBox txtdisease;
        private Button diseaseadd;
        private Label label15;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem deleteRowToolStripMenuItem;
        private Button btnSearchLookup;
        private Label label16;
        private Label lbllandline;
        private TextBox txtlandline;
        private Label label20;
        private ComboBox cmbmartial;
    }
}