﻿namespace Sample
{
    partial class Notification
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GvNotificationData = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.GvNotificationData)).BeginInit();
            this.SuspendLayout();
            // 
            // GvNotificationData
            // 
            this.GvNotificationData.AllowUserToAddRows = false;
            this.GvNotificationData.AllowUserToDeleteRows = false;
            this.GvNotificationData.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.GvNotificationData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvNotificationData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GvNotificationData.Location = new System.Drawing.Point(0, 0);
            this.GvNotificationData.Name = "GvNotificationData";
            this.GvNotificationData.ReadOnly = true;
            this.GvNotificationData.Size = new System.Drawing.Size(533, 261);
            this.GvNotificationData.TabIndex = 0;
            // 
            // Notification
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 261);
            this.Controls.Add(this.GvNotificationData);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Notification";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Victim Notification";
            this.Load += new System.EventHandler(this.Notification_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GvNotificationData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView GvNotificationData;
    }
}