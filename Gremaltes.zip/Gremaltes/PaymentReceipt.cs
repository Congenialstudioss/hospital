﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class PaymentReceipt : Form
    {
        public Int32 SequenceNo;

        public PaymentReceipt(Int32 SeqNo)
        {
            this.SequenceNo = SeqNo;
            InitializeComponent();
        }

        private void PaymentReceipt_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gremaltesPaymentReceipt.Gremaltes_PaymentReceiptSP' table. You can move, or remove it, as needed.
            this.gremaltes_PaymentReceiptSPTableAdapter.Fill(this.gremaltesPaymentReceipt.Gremaltes_PaymentReceiptSP, Convert.ToInt32(SequenceNo));
            this.reportViewer1.RefreshReport();
        }               
    }
}
