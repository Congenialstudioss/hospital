﻿namespace Sample
{
    partial class TreatmentHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnreviewshow = new System.Windows.Forms.Button();
            this.dtptransdate = new System.Windows.Forms.DateTimePicker();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtregid = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSearchLookup = new System.Windows.Forms.Button();
            this.txtcontactno = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.combosex = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtguardian = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtdod = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtpatient = new System.Windows.Forms.TextBox();
            this.cbosubtitle = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.PatientDetails = new System.Windows.Forms.DataGridView();
            this.btnregister = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PatientDetails)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnreviewshow);
            this.groupBox1.Controls.Add(this.dtptransdate);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtregid);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(632, 57);
            this.groupBox1.TabIndex = 67;
            this.groupBox1.TabStop = false;
            // 
            // btnreviewshow
            // 
            this.btnreviewshow.Enabled = false;
            this.btnreviewshow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreviewshow.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnreviewshow.Location = new System.Drawing.Point(322, 20);
            this.btnreviewshow.Name = "btnreviewshow";
            this.btnreviewshow.Size = new System.Drawing.Size(75, 23);
            this.btnreviewshow.TabIndex = 3;
            this.btnreviewshow.Text = "New";
            this.btnreviewshow.UseVisualStyleBackColor = true;
            this.btnreviewshow.Click += new System.EventHandler(this.btnreviewshow_Click);
            // 
            // dtptransdate
            // 
            this.dtptransdate.Enabled = false;
            this.dtptransdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtptransdate.Location = new System.Drawing.Point(514, 22);
            this.dtptransdate.Name = "dtptransdate";
            this.dtptransdate.Size = new System.Drawing.Size(107, 20);
            this.dtptransdate.TabIndex = 4;
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSearch.Location = new System.Drawing.Point(241, 20);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(438, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "Reg Date";
            // 
            // txtregid
            // 
            this.txtregid.Location = new System.Drawing.Point(77, 22);
            this.txtregid.Name = "txtregid";
            this.txtregid.Size = new System.Drawing.Size(149, 20);
            this.txtregid.TabIndex = 1;
            this.txtregid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtregid_KeyDown);
            this.txtregid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtage_KeyPress_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(10, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "Victim No";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSearchLookup);
            this.groupBox2.Controls.Add(this.txtcontactno);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.combosex);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txtguardian);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtdod);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.txtage);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtpatient);
            this.groupBox2.Controls.Add(this.cbosubtitle);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(12, 75);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(722, 107);
            this.groupBox2.TabIndex = 68;
            this.groupBox2.TabStop = false;
            // 
            // btnSearchLookup
            // 
            this.btnSearchLookup.Image = global::Sample.Properties.Resources._1375225193_users_male;
            this.btnSearchLookup.Location = new System.Drawing.Point(481, 14);
            this.btnSearchLookup.Name = "btnSearchLookup";
            this.btnSearchLookup.Size = new System.Drawing.Size(37, 46);
            this.btnSearchLookup.TabIndex = 90;
            this.btnSearchLookup.UseVisualStyleBackColor = true;
            this.btnSearchLookup.Click += new System.EventHandler(this.btnSearchLookup_Click_2);
            // 
            // txtcontactno
            // 
            this.txtcontactno.Location = new System.Drawing.Point(168, 69);
            this.txtcontactno.Name = "txtcontactno";
            this.txtcontactno.Size = new System.Drawing.Size(288, 20);
            this.txtcontactno.TabIndex = 11;
            this.txtcontactno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontactno_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(12, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 13);
            this.label7.TabIndex = 88;
            this.label7.Text = "Contact No";
            // 
            // combosex
            // 
            this.combosex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combosex.FormattingEnabled = true;
            this.combosex.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.combosex.Location = new System.Drawing.Point(596, 42);
            this.combosex.Name = "combosex";
            this.combosex.Size = new System.Drawing.Size(100, 21);
            this.combosex.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(538, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 38;
            this.label1.Text = "Sex";
            // 
            // txtguardian
            // 
            this.txtguardian.Location = new System.Drawing.Point(168, 39);
            this.txtguardian.Name = "txtguardian";
            this.txtguardian.Size = new System.Drawing.Size(288, 20);
            this.txtguardian.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(12, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 13);
            this.label2.TabIndex = 36;
            this.label2.Text = "Father / Guardian Name";
            // 
            // txtdod
            // 
            this.txtdod.Enabled = false;
            this.txtdod.Location = new System.Drawing.Point(596, 69);
            this.txtdod.Name = "txtdod";
            this.txtdod.Size = new System.Drawing.Size(100, 20);
            this.txtdod.TabIndex = 12;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label18.Location = new System.Drawing.Point(478, 72);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 13);
            this.label18.TabIndex = 87;
            this.label18.Text = "Date of Deletion";
            // 
            // txtage
            // 
            this.txtage.Location = new System.Drawing.Point(596, 14);
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(100, 20);
            this.txtage.TabIndex = 8;
            this.txtage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtage_KeyPress_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(538, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 34;
            this.label4.Text = "Age";
            // 
            // txtpatient
            // 
            this.txtpatient.Location = new System.Drawing.Point(241, 10);
            this.txtpatient.Name = "txtpatient";
            this.txtpatient.Size = new System.Drawing.Size(215, 20);
            this.txtpatient.TabIndex = 7;
            // 
            // cbosubtitle
            // 
            this.cbosubtitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbosubtitle.Enabled = false;
            this.cbosubtitle.FormattingEnabled = true;
            this.cbosubtitle.Items.AddRange(new object[] {
            "--Select--",
            "MR",
            "MRS",
            "MISS",
            "BABY",
            "DR"});
            this.cbosubtitle.Location = new System.Drawing.Point(168, 9);
            this.cbosubtitle.Name = "cbosubtitle";
            this.cbosubtitle.Size = new System.Drawing.Size(58, 21);
            this.cbosubtitle.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(12, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 31;
            this.label3.Text = "Victim Name";
            // 
            // PatientDetails
            // 
            this.PatientDetails.AllowUserToAddRows = false;
            this.PatientDetails.AllowUserToDeleteRows = false;
            this.PatientDetails.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PatientDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PatientDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PatientDetails.Location = new System.Drawing.Point(12, 198);
            this.PatientDetails.Name = "PatientDetails";
            this.PatientDetails.ReadOnly = true;
            this.PatientDetails.Size = new System.Drawing.Size(722, 150);
            this.PatientDetails.TabIndex = 75;
            this.PatientDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PatientDetails_CellDoubleClick);
            this.PatientDetails.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.PatientDetails_CellMouseUp);
            // 
            // btnregister
            // 
            this.btnregister.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregister.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnregister.Location = new System.Drawing.Point(650, 31);
            this.btnregister.Name = "btnregister";
            this.btnregister.Size = new System.Drawing.Size(75, 23);
            this.btnregister.TabIndex = 5;
            this.btnregister.Text = "Register";
            this.btnregister.UseVisualStyleBackColor = true;
            this.btnregister.Click += new System.EventHandler(this.btnregister_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(100, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.printToolStripMenuItem.Text = "Print";
            // 
            // TreatmentHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 365);
            this.Controls.Add(this.btnregister);
            this.Controls.Add(this.PatientDetails);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TreatmentHistory";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Victim Treatment History";
            this.Load += new System.EventHandler(this.TreatmentHistory_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PatientDetails)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dtptransdate;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtregid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox combosex;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtguardian;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtpatient;
        private System.Windows.Forms.ComboBox cbosubtitle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtdod;
        private System.Windows.Forms.DataGridView PatientDetails;
        private System.Windows.Forms.TextBox txtcontactno;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnreviewshow;
        private System.Windows.Forms.Button btnSearchLookup;
        private System.Windows.Forms.Button btnregister;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;

    }
}