﻿namespace Sample
{
    partial class DiseaseMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtdisease = new System.Windows.Forms.TextBox();
            this.lbldisease = new System.Windows.Forms.Label();
            this.btnsave = new System.Windows.Forms.Button();
            this.gvdiseaselist = new System.Windows.Forms.DataGridView();
            this.diseaseMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.gvdiseaselist)).BeginInit();
            this.diseaseMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtdisease
            // 
            this.txtdisease.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdisease.Location = new System.Drawing.Point(194, 32);
            this.txtdisease.Name = "txtdisease";
            this.txtdisease.Size = new System.Drawing.Size(225, 20);
            this.txtdisease.TabIndex = 1;
            // 
            // lbldisease
            // 
            this.lbldisease.AutoSize = true;
            this.lbldisease.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldisease.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbldisease.Location = new System.Drawing.Point(59, 32);
            this.lbldisease.Name = "lbldisease";
            this.lbldisease.Size = new System.Drawing.Size(88, 13);
            this.lbldisease.TabIndex = 1;
            this.lbldisease.Text = "Disease Name";
            // 
            // btnsave
            // 
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnsave.Location = new System.Drawing.Point(270, 73);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 2;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // gvdiseaselist
            // 
            this.gvdiseaselist.AllowUserToAddRows = false;
            this.gvdiseaselist.AllowUserToDeleteRows = false;
            this.gvdiseaselist.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gvdiseaselist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvdiseaselist.Location = new System.Drawing.Point(12, 122);
            this.gvdiseaselist.Name = "gvdiseaselist";
            this.gvdiseaselist.ReadOnly = true;
            this.gvdiseaselist.Size = new System.Drawing.Size(499, 167);
            this.gvdiseaselist.TabIndex = 3;
            this.gvdiseaselist.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvdiseaselist_CellDoubleClick);
            this.gvdiseaselist.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gvdiseaselist_CellMouseUp);
            // 
            // diseaseMenuStrip
            // 
            this.diseaseMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.diseaseMenuStrip.Name = "diseaseMenuStrip";
            this.diseaseMenuStrip.Size = new System.Drawing.Size(134, 26);
            this.diseaseMenuStrip.Click += new System.EventHandler(this.diseaseMenuStrip_Click);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.deleteRowToolStripMenuItem.Text = "Delete Row";
            // 
            // DiseaseMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 301);
            this.Controls.Add(this.gvdiseaselist);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.lbldisease);
            this.Controls.Add(this.txtdisease);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DiseaseMaster";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Disease Master";
            ((System.ComponentModel.ISupportInitialize)(this.gvdiseaselist)).EndInit();
            this.diseaseMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtdisease;
        private System.Windows.Forms.Label lbldisease;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.DataGridView gvdiseaselist;
        private System.Windows.Forms.ContextMenuStrip diseaseMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
    }
}