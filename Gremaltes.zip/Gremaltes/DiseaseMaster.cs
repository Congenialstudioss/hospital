﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class DiseaseMaster : Form
    {
        int indexRow;
        public DiseaseMaster()
        {
            InitializeComponent();
            LoadDisease();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtdisease.Text != String.Empty)
                {
                    if (btnsave.Text == "Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@Action", "Insert");
                        hstbl.Add("@ModifyBy", Global.UserID);
                        hstbl.Add("@DiseaseName", txtdisease.Text.Trim());
                        Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_SaveDiseaseMaster_sp", hstbl);
                        if (intIdentity > 0)
                        {
                            MessageBox.Show("Disease Details Saved Successfully.", "Disease Master Alert");
                            txtdisease.Text = String.Empty;
                            LoadDisease();
                        }
                    }

                    else if (btnsave.Text == "Update")
                    {
                        Hashtable hstbl = new Hashtable();
                        DataGridViewRow row = gvdiseaselist.Rows[indexRow];

                        hstbl.Add("@Action", "Update");
                        hstbl.Add("@ModifyBy", Global.UserID);
                        hstbl.Add("@DiseaseName", txtdisease.Text.Trim());
                        hstbl.Add("@DiseaseId", row.Cells[1].Value);
                        Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_SaveDiseaseMaster_sp", hstbl);
                        if (intIdentity > 0)
                        {
                            MessageBox.Show("Disease Details Updated Successfully.", "Disease Master Alert");
                            txtdisease.Text = String.Empty;
                            LoadDisease();
                            btnsave.Text = "Save";
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the Disease name", "Disease Master Alert");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        protected void LoadDisease()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("Action", "Get");
                DataSet ds = DataAccessLayer.GetDataset("Hospital_SaveDiseaseMaster_sp", hstbl);
                gvdiseaselist.DataSource = null;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    gvdiseaselist.DataSource = ds.Tables[0];
                    gvdiseaselist.Columns[1].Visible = false;
                    gvdiseaselist.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    DataGridViewCellStyle style = gvdiseaselist.ColumnHeadersDefaultCellStyle;
                    style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    style.Font = new Font(gvdiseaselist.Font, FontStyle.Bold);
                    gvdiseaselist.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
                    gvdiseaselist.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    gvdiseaselist.EnableHeadersVisualStyles = false;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void gvdiseaselist_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                indexRow = e.RowIndex;
                DataGridViewRow row = gvdiseaselist.Rows[indexRow];
                txtdisease.Text = row.Cells[2].Value.ToString();
                btnsave.Text = "Update";
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        private void diseaseMenuStrip_Click(object sender, EventArgs e)
        {
            try
            {
                diseaseMenuStrip.Hide();
                if (MessageBox.Show("Do want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = gvdiseaselist.Rows[indexRow];

                    hstbl.Add("@Action", "Delete");
                    hstbl.Add("@ModifyBy", Global.UserID);
                    hstbl.Add("@DiseaseId", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_SaveDiseaseMaster_sp", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show("Disease Details Deleted Successfully.", "Disease Master Alert");
                        txtdisease.Text = String.Empty;
                        LoadDisease();
                        btnsave.Text = "Save";
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        private void gvdiseaselist_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Right)
                {
                    this.gvdiseaselist.Rows[e.RowIndex].Selected = true;
                    indexRow = e.RowIndex;
                    this.gvdiseaselist.CurrentCell = this.gvdiseaselist.Rows[e.RowIndex].Cells[2];
                    this.diseaseMenuStrip.Show(this.gvdiseaselist, e.Location);
                    diseaseMenuStrip.Show(Cursor.Position);
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
    }
}
