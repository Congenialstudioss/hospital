﻿using System.Drawing;
using System.Windows.Forms;
namespace WindowsFormsApplication3
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.txtseqno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Save = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dtTodayDate = new System.Windows.Forms.DateTimePicker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbmartial = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.ddlSex = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtfather = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtpatient = new System.Windows.Forms.TextBox();
            this.ddlSurName = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtlandline = new System.Windows.Forms.TextBox();
            this.lbllandline = new System.Windows.Forms.Label();
            this.txtcontactno = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtcountry = new System.Windows.Forms.ComboBox();
            this.chkFree = new System.Windows.Forms.CheckBox();
            this.txtconfees = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtregfees = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtpincode = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtstate = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtlocation = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtbuildname = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtstreet = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtflat = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ErrorMessage = new System.Windows.Forms.ErrorProvider(this.components);
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.label1 = new System.Windows.Forms.Label();
            this.ddlDiseaseType = new System.Windows.Forms.ComboBox();
            this.txtdisease = new System.Windows.Forms.TextBox();
            this.diseaseadd = new System.Windows.Forms.Button();
            this.diseaselist = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorMessage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.diseaselist)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtYear
            // 
            this.txtYear.Enabled = false;
            this.txtYear.ForeColor = System.Drawing.Color.Red;
            this.txtYear.Location = new System.Drawing.Point(108, 19);
            this.txtYear.Name = "txtYear";
            this.txtYear.ReadOnly = true;
            this.txtYear.Size = new System.Drawing.Size(64, 20);
            this.txtYear.TabIndex = 3;
            // 
            // txtseqno
            // 
            this.txtseqno.Enabled = false;
            this.txtseqno.ForeColor = System.Drawing.Color.Red;
            this.txtseqno.Location = new System.Drawing.Point(201, 19);
            this.txtseqno.Name = "txtseqno";
            this.txtseqno.ReadOnly = true;
            this.txtseqno.Size = new System.Drawing.Size(106, 20);
            this.txtseqno.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(506, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Reg Date";
            // 
            // Save
            // 
            this.Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Save.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Save.Location = new System.Drawing.Point(325, 590);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 21;
            this.Save.Text = "&Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnPrint.Location = new System.Drawing.Point(421, 590);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 22;
            this.btnPrint.Text = "&Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Visible = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.dtTodayDate);
            this.groupBox1.Controls.Add(this.txtYear);
            this.groupBox1.Controls.Add(this.txtseqno);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(725, 51);
            this.groupBox1.TabIndex = 67;
            this.groupBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(19, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Victim No";
            // 
            // dtTodayDate
            // 
            this.dtTodayDate.Enabled = false;
            this.dtTodayDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtTodayDate.Location = new System.Drawing.Point(580, 19);
            this.dtTodayDate.Name = "dtTodayDate";
            this.dtTodayDate.Size = new System.Drawing.Size(113, 20);
            this.dtTodayDate.TabIndex = 5;
            this.dtTodayDate.ValueChanged += new System.EventHandler(this.dtTodayDate_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbmartial);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.ddlSex);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtfather);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtage);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtpatient);
            this.groupBox2.Controls.Add(this.ddlSurName);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(12, 69);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(725, 79);
            this.groupBox2.TabIndex = 68;
            this.groupBox2.TabStop = false;
            // 
            // cmbmartial
            // 
            this.cmbmartial.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbmartial.FormattingEnabled = true;
            this.cmbmartial.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.cmbmartial.Location = new System.Drawing.Point(517, 47);
            this.cmbmartial.Name = "cmbmartial";
            this.cmbmartial.Size = new System.Drawing.Size(176, 21);
            this.cmbmartial.TabIndex = 6;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label20.Location = new System.Drawing.Point(471, 51);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 13);
            this.label20.TabIndex = 24;
            this.label20.Text = "Martial";
            // 
            // ddlSex
            // 
            this.ddlSex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlSex.FormattingEnabled = true;
            this.ddlSex.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.ddlSex.Location = new System.Drawing.Point(607, 15);
            this.ddlSex.Name = "ddlSex";
            this.ddlSex.Size = new System.Drawing.Size(86, 21);
            this.ddlSex.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(573, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Sex";
            // 
            // txtfather
            // 
            this.txtfather.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtfather.Location = new System.Drawing.Point(201, 48);
            this.txtfather.MaxLength = 200;
            this.txtfather.Name = "txtfather";
            this.txtfather.Size = new System.Drawing.Size(258, 20);
            this.txtfather.TabIndex = 5;
            this.txtfather.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Alphabets_Only);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(19, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Father / Guardian Name";
            // 
            // txtage
            // 
            this.txtage.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtage.Location = new System.Drawing.Point(517, 16);
            this.txtage.MaxLength = 2;
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(50, 20);
            this.txtage.TabIndex = 3;
            this.txtage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtage_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(471, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Age";
            // 
            // txtpatient
            // 
            this.txtpatient.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtpatient.Location = new System.Drawing.Point(276, 12);
            this.txtpatient.MaxLength = 100;
            this.txtpatient.Name = "txtpatient";
            this.txtpatient.Size = new System.Drawing.Size(183, 20);
            this.txtpatient.TabIndex = 2;
            this.txtpatient.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpatient_KeyPress);
            // 
            // ddlSurName
            // 
            this.ddlSurName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlSurName.FormattingEnabled = true;
            this.ddlSurName.Items.AddRange(new object[] {
            "--Select--",
            "MR",
            "MRS",
            "MISS",
            "BABY",
            "DR"});
            this.ddlSurName.Location = new System.Drawing.Point(201, 12);
            this.ddlSurName.Name = "ddlSurName";
            this.ddlSurName.Size = new System.Drawing.Size(60, 21);
            this.ddlSurName.TabIndex = 1;
            this.ddlSurName.SelectedIndexChanged += new System.EventHandler(this.ddlSurName_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(19, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Victim Name";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtlandline);
            this.groupBox3.Controls.Add(this.lbllandline);
            this.groupBox3.Controls.Add(this.txtcontactno);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.txtcountry);
            this.groupBox3.Controls.Add(this.chkFree);
            this.groupBox3.Controls.Add(this.txtconfees);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txtcity);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.txtregfees);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.txtpincode);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.txtstate);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.txtlocation);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.txtbuildname);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txtstreet);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txtflat);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.groupBox3.Location = new System.Drawing.Point(12, 154);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(725, 200);
            this.groupBox3.TabIndex = 69;
            this.groupBox3.TabStop = false;
            // 
            // txtlandline
            // 
            this.txtlandline.Location = new System.Drawing.Point(448, 161);
            this.txtlandline.MaxLength = 10;
            this.txtlandline.Name = "txtlandline";
            this.txtlandline.Size = new System.Drawing.Size(229, 20);
            this.txtlandline.TabIndex = 17;
            this.txtlandline.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontactno_KeyPress);
            // 
            // lbllandline
            // 
            this.lbllandline.AutoSize = true;
            this.lbllandline.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllandline.Location = new System.Drawing.Point(382, 164);
            this.lbllandline.Name = "lbllandline";
            this.lbllandline.Size = new System.Drawing.Size(55, 13);
            this.lbllandline.TabIndex = 62;
            this.lbllandline.Text = "Landline";
            // 
            // txtcontactno
            // 
            this.txtcontactno.Location = new System.Drawing.Point(448, 134);
            this.txtcontactno.Name = "txtcontactno";
            this.txtcontactno.Size = new System.Drawing.Size(229, 20);
            this.txtcontactno.TabIndex = 15;
            this.txtcontactno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontactno_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label18.Location = new System.Drawing.Point(382, 137);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(44, 13);
            this.label18.TabIndex = 61;
            this.label18.Text = "Mobile";
            // 
            // txtcountry
            // 
            this.txtcountry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtcountry.FormattingEnabled = true;
            this.txtcountry.Items.AddRange(new object[] {
            "INDIA"});
            this.txtcountry.Location = new System.Drawing.Point(107, 17);
            this.txtcountry.Name = "txtcountry";
            this.txtcountry.Size = new System.Drawing.Size(215, 21);
            this.txtcountry.TabIndex = 7;
            // 
            // chkFree
            // 
            this.chkFree.AutoSize = true;
            this.chkFree.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkFree.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.chkFree.Location = new System.Drawing.Point(275, 166);
            this.chkFree.Name = "chkFree";
            this.chkFree.Size = new System.Drawing.Size(51, 17);
            this.chkFree.TabIndex = 16;
            this.chkFree.Text = "Free";
            this.chkFree.UseVisualStyleBackColor = true;
            this.chkFree.Click += new System.EventHandler(this.chkFree_Click);
            // 
            // txtconfees
            // 
            this.txtconfees.Enabled = false;
            this.txtconfees.Location = new System.Drawing.Point(108, 167);
            this.txtconfees.Name = "txtconfees";
            this.txtconfees.ReadOnly = true;
            this.txtconfees.Size = new System.Drawing.Size(145, 20);
            this.txtconfees.TabIndex = 20;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label16.Location = new System.Drawing.Point(20, 170);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 13);
            this.label16.TabIndex = 57;
            this.label16.Text = "Con. Fees";
            // 
            // txtcity
            // 
            this.txtcity.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtcity.Location = new System.Drawing.Point(107, 49);
            this.txtcity.MaxLength = 200;
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(215, 20);
            this.txtcity.TabIndex = 9;
            this.txtcity.Text = "CHENNAI";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label17.Location = new System.Drawing.Point(19, 49);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 13);
            this.label17.TabIndex = 55;
            this.label17.Text = "Town/City";
            // 
            // txtregfees
            // 
            this.txtregfees.Enabled = false;
            this.txtregfees.Location = new System.Drawing.Point(107, 137);
            this.txtregfees.Name = "txtregfees";
            this.txtregfees.ReadOnly = true;
            this.txtregfees.Size = new System.Drawing.Size(215, 20);
            this.txtregfees.TabIndex = 19;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label13.Location = new System.Drawing.Point(382, 81);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 53;
            this.label13.Text = "PinCode";
            // 
            // txtpincode
            // 
            this.txtpincode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtpincode.Location = new System.Drawing.Point(448, 78);
            this.txtpincode.MaxLength = 6;
            this.txtpincode.Name = "txtpincode";
            this.txtpincode.Size = new System.Drawing.Size(229, 20);
            this.txtpincode.TabIndex = 12;
            this.txtpincode.Text = "600";
            this.txtpincode.TabIndexChanged += new System.EventHandler(this.txtpincode_TabIndexChanged);
            this.txtpincode.TextChanged += new System.EventHandler(this.txtpincode_TextChanged_1);
            this.txtpincode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPincode_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label14.Location = new System.Drawing.Point(20, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 13);
            this.label14.TabIndex = 51;
            this.label14.Text = "Country";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label15.Location = new System.Drawing.Point(20, 137);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 13);
            this.label15.TabIndex = 49;
            this.label15.Text = "Reg. Fees";
            // 
            // txtstate
            // 
            this.txtstate.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtstate.Location = new System.Drawing.Point(448, 19);
            this.txtstate.MaxLength = 200;
            this.txtstate.Name = "txtstate";
            this.txtstate.Size = new System.Drawing.Size(229, 20);
            this.txtstate.TabIndex = 8;
            this.txtstate.Text = "TAMIL NADU";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label12.Location = new System.Drawing.Point(382, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 13);
            this.label12.TabIndex = 47;
            this.label12.Text = "State";
            // 
            // txtlocation
            // 
            this.txtlocation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtlocation.Location = new System.Drawing.Point(448, 105);
            this.txtlocation.MaxLength = 200;
            this.txtlocation.Name = "txtlocation";
            this.txtlocation.Size = new System.Drawing.Size(229, 20);
            this.txtlocation.TabIndex = 14;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label11.Location = new System.Drawing.Point(19, 78);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 13);
            this.label11.TabIndex = 45;
            this.label11.Text = "Building Name";
            // 
            // txtbuildname
            // 
            this.txtbuildname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbuildname.Location = new System.Drawing.Point(107, 78);
            this.txtbuildname.MaxLength = 200;
            this.txtbuildname.Name = "txtbuildname";
            this.txtbuildname.Size = new System.Drawing.Size(215, 20);
            this.txtbuildname.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label10.Location = new System.Drawing.Point(20, 108);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 43;
            this.label10.Text = "Street";
            // 
            // txtstreet
            // 
            this.txtstreet.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtstreet.Location = new System.Drawing.Point(107, 105);
            this.txtstreet.MaxLength = 200;
            this.txtstreet.Name = "txtstreet";
            this.txtstreet.Size = new System.Drawing.Size(215, 20);
            this.txtstreet.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label9.Location = new System.Drawing.Point(382, 108);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 41;
            this.label9.Text = "Location";
            // 
            // txtflat
            // 
            this.txtflat.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtflat.Location = new System.Drawing.Point(448, 49);
            this.txtflat.MaxLength = 200;
            this.txtflat.Name = "txtflat";
            this.txtflat.Size = new System.Drawing.Size(229, 20);
            this.txtflat.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(382, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 39;
            this.label8.Text = "Flat No.";
            // 
            // ErrorMessage
            // 
            this.ErrorMessage.ContainerControl = this;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(20, 382);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 61;
            this.label1.Text = "Diseases";
            // 
            // ddlDiseaseType
            // 
            this.ddlDiseaseType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlDiseaseType.FormattingEnabled = true;
            this.ddlDiseaseType.Location = new System.Drawing.Point(84, 380);
            this.ddlDiseaseType.Name = "ddlDiseaseType";
            this.ddlDiseaseType.Size = new System.Drawing.Size(158, 21);
            this.ddlDiseaseType.TabIndex = 18;
            // 
            // txtdisease
            // 
            this.txtdisease.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdisease.Location = new System.Drawing.Point(325, 382);
            this.txtdisease.Multiline = true;
            this.txtdisease.Name = "txtdisease";
            this.txtdisease.Size = new System.Drawing.Size(317, 21);
            this.txtdisease.TabIndex = 19;
            // 
            // diseaseadd
            // 
            this.diseaseadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diseaseadd.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.diseaseadd.Location = new System.Drawing.Point(648, 380);
            this.diseaseadd.Name = "diseaseadd";
            this.diseaseadd.Size = new System.Drawing.Size(75, 23);
            this.diseaseadd.TabIndex = 20;
            this.diseaseadd.Text = "Add";
            this.diseaseadd.UseVisualStyleBackColor = true;
            this.diseaseadd.Click += new System.EventHandler(this.diseaseadd_Click);
            // 
            // diseaselist
            // 
            this.diseaselist.AllowUserToAddRows = false;
            this.diseaselist.AllowUserToDeleteRows = false;
            this.diseaselist.BackgroundColor = System.Drawing.SystemColors.Window;
            this.diseaselist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.diseaselist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.diseaselist.Location = new System.Drawing.Point(12, 425);
            this.diseaselist.Name = "diseaselist";
            this.diseaselist.ReadOnly = true;
            this.diseaselist.Size = new System.Drawing.Size(725, 150);
            this.diseaselist.TabIndex = 70;
            this.diseaselist.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.diseaselist_CellDoubleClick);
            this.diseaselist.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.diseaselist_CellMouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(134, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.deleteRowToolStripMenuItem.Text = "Delete Row";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label19.Location = new System.Drawing.Point(248, 383);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 13);
            this.label19.TabIndex = 71;
            this.label19.Text = "Description";
            // 
            // RegisterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(749, 625);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.diseaselist);
            this.Controls.Add(this.diseaseadd);
            this.Controls.Add(this.txtdisease);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.ddlDiseaseType);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.Save);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.KeyPreview = true;
            this.Location = new System.Drawing.Point(100, 0);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RegisterForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Victim Registration";
            this.Load += new System.EventHandler(this.RegisterForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.RegisterForm_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorMessage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.diseaselist)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.TextBox txtseqno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtfather;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtpatient;
        private System.Windows.Forms.ComboBox ddlSurName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtconfees;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtregfees;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtpincode;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtstate;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtlocation;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtbuildname;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtstreet;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtflat;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtTodayDate;
        private System.Windows.Forms.ComboBox ddlSex;
        private System.Windows.Forms.ErrorProvider ErrorMessage;
        private System.Windows.Forms.CheckBox chkFree;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private ComboBox txtcountry;
        private ComboBox ddlDiseaseType;
        private Label label1;
        private TextBox txtdisease;
        private Button diseaseadd;
        private DataGridView diseaselist;
        private Label label7;
        private TextBox txtcontactno;
        private Label label18;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem deleteRowToolStripMenuItem;
        private Label label19;
        private TextBox txtlandline;
        private Label lbllandline;
        private ComboBox cmbmartial;
        private Label label20;
    }
}

