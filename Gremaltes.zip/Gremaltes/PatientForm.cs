﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;
using System.Drawing.Printing;
using Sample.DataAccess;

namespace Sample
{
    public partial class PatientForm : Form
    {
        DataTable table;
        int indexRow;

        public PatientForm()
        {
            InitializeComponent();
            txtuserid.Text = Global.UserName;
            cmbmartial.SelectedIndex = 0;

            //add columns to datatable  
            table = new DataTable();
            table.Columns.Add("S.NO", typeof(string));
            table.Columns.Add("Diseases Name", typeof(string));
            table.Columns.Add("DiseaseId", typeof(string));
            table.Columns.Add("Description", typeof(string));

            table.Columns["DiseaseId"].ColumnMapping = MappingType.Hidden;

            diseaselist.DataSource = table;
            diseaselist.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            DataGridViewCellStyle style = diseaselist.ColumnHeadersDefaultCellStyle;
            style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            style.Font = new Font(diseaselist.Font, FontStyle.Bold);
            diseaselist.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
            diseaselist.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            diseaselist.EnableHeadersVisualStyles = false;
        }

        private void PatientForm_Load(object sender, EventArgs e)
        {
            cbosubtitle.SelectedIndex = 1;
            txtregid.Select();
            LoadDropDown();
            txtregid.MaxLength = 10;
        }

        private void Search_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtregid.Text != String.Empty)
                {
                    DisplayRecord();
                    BindGrid();
                    btnSave.Enabled = true;
                    btnDelete.Enabled = true;
                    btnPrint.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Please Enter Victim No", "Victim Form - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void DisplayRecord()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@pi_RegisterID", txtregid.Text.Trim());
                DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_ReviewForm_Fetch_Sp", hstbl);
                if (dtLoad.Rows.Count > 0)
                {
                    cbosubtitle.SelectedIndex = Convert.ToInt32(dtLoad.Rows[0]["SubTitle"].ToString());
                    txtpatient.Text = dtLoad.Rows[0]["Name"].ToString();
                    txtage.Text = dtLoad.Rows[0]["Age"].ToString();
                    txtfather.Text = dtLoad.Rows[0]["GuardianName"].ToString();
                    combosex.SelectedIndex = Convert.ToInt32(dtLoad.Rows[0]["Sex"]);
                    txtflat.Text = dtLoad.Rows[0]["FlatNo"].ToString();
                    txtbuildname.Text = dtLoad.Rows[0]["BuildingName"].ToString();
                    txtstreet.Text = dtLoad.Rows[0]["Street"].ToString();
                    txtlocation.Text = dtLoad.Rows[0]["Location"].ToString();
                    txtcity.Text = dtLoad.Rows[0]["City"].ToString();
                    txtcountry.SelectedValue = dtLoad.Rows[0]["CountryId"];
                    txtstate.Text = dtLoad.Rows[0]["StateId"].ToString();
                    txtpincode.Text = dtLoad.Rows[0]["PinCode"].ToString();
                    //txtprevhistory.Text = dtLoad.Rows[0]["History"].ToString();
                    dtpreg.Text = dtLoad.Rows[0]["RegDate"].ToString();
                    txtcontactno.Text = dtLoad.Rows[0]["ContactNo"].ToString();

                    txtlandline.Text = dtLoad.Rows[0]["Landline"].ToString();
                    cmbmartial.SelectedIndex = Convert.ToInt32(dtLoad.Rows[0]["Martial"]);
                    if (dtLoad.Rows[0]["Free"].ToString() == "1" || dtLoad.Rows[0]["Free"].ToString().ToLower() == "true")
                    {
                        //txtconfees.Text = "0";
                        //txtregfees.Text = "0";
                    }
                    else
                    {
                        ConsultationFees(Convert.ToInt32(dtLoad.Rows[0]["FeesId"].ToString() != string.Empty ? dtLoad.Rows[0]["FeesId"].ToString() : "0"));
                    }
                }
                else
                {
                    MessageBox.Show("Victim No does not exist", "Victim Form - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void ConsultationFees(Int32 Fees_ID)
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@FeesID", Fees_ID);
                DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_FeesDetails_Sp", hstbl);
                if (dtLoad.Rows.Count > 0)
                {
                    Fees_ID = Convert.ToInt32(dtLoad.Rows[0]["FeesId"].ToString());
                    //txtconfees.Text = dtLoad.Rows[0]["Consulting"].ToString();
                    //txtregfees.Text = dtLoad.Rows[0]["Registration"].ToString();
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtregid.Text != String.Empty)
                {
                    AddPinCode();
                    Hashtable hstbl1 = new Hashtable();
                    hstbl1.Add("@RegisterID", txtregid.Text.Trim());
                    hstbl1.Add("@SubTitle", Convert.ToInt32(cbosubtitle.SelectedIndex));
                    hstbl1.Add("@Name", txtpatient.Text.Trim());
                    hstbl1.Add("@Age", Convert.ToInt32(txtage.Text));
                    hstbl1.Add("@GuardianName", txtfather.Text.Trim());
                    hstbl1.Add("@Sex", Convert.ToBoolean(combosex.SelectedIndex));
                    hstbl1.Add("@FlatNo", txtflat.Text.Trim());
                    hstbl1.Add("@BuildingName", txtbuildname.Text.Trim());
                    hstbl1.Add("@Street", txtstreet.Text.Trim());
                    hstbl1.Add("@Location", txtlocation.Text.Trim());
                    hstbl1.Add("@City", txtcity.Text.Trim());
                    hstbl1.Add("@StateId", txtstate.Text.Trim());
                    hstbl1.Add("@PinCode", txtpincode.Text.Trim());
                    hstbl1.Add("@CountryId", txtcountry.SelectedValue);
                    //hstbl1.Add("@History", txtprevhistory.Text.Trim());
                    //hstbl1.Add("@RegDate", dtpreg.Value.ToString("dd-MMM-yyyy HH:mm:ss"));
                    hstbl1.Add("@RegDate", Convert.ToDateTime(dtpreg.Value));
                    hstbl1.Add("@ModifyDate", DateTime.Today);
                    hstbl1.Add("@ModifyBy", Global.UserID);
                    hstbl1.Add("@Landline", txtlandline.Text.Trim());
                    hstbl1.Add("@Martial", cmbmartial.SelectedIndex);
                    if (txtcontactno.Text != "")
                    {
                        hstbl1.Add("@ContactNo", txtcontactno.Text.Trim());
                    }

                    string Diseasexml = CreatedegreeXML();
                    if (Diseasexml.Length > 0)
                    {
                        hstbl1.Add("@DiseaseXml", Diseasexml);
                    }

                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_PatientForm_Update_Sp", hstbl1);
                    //if (intIdentity > 0)
                    //{


                    //DialogResult result = MessageBox.Show("Patient Information Updated Sucessfully, Do You Want to Print?", "Victim Form - Success", MessageBoxButtons.YesNo);
                    //if (result == DialogResult.Yes)
                    //{
                    //    if (txtregid.Text.Trim() != string.Empty)
                    //    {
                    //        Printers obj = new Printers();
                    //        obj.SingleLabelReadData(txtregid.Text.Trim().ToString());
                    //    }
                    //}
                    MessageBox.Show("Victim Information Updated Sucessfully", "Victim Form - Success");
                    Clear();

                    //}
                    //this.Close();
                }
                else
                {
                    MessageBox.Show("Please Enter Victim No", "Victim Form - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtregid.Text != string.Empty)
                {
                    Hashtable hstbl = new Hashtable();
                    hstbl.Add("@RegisterNo", txtregid.Text);
                    Int32 Result = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_PatientForm_Delete_Sp", hstbl);
                    if (Result > 0)
                    {
                        MessageBox.Show("Deleted Successfully", "Victim Form- Sucess");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Deleted Failure", "Victim Form- Error");
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter Victim No", "Victim Form - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtregid.Text != string.Empty)
                {

                    Printers obj = new Printers();
                    //obj.ReadFile(txtregid.Text.Trim().ToString());
                    obj.SingleLabelReadData(txtregid.Text.ToString());
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void cbosubtitle_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ComboBox comboBox = (ComboBox)sender;

                // Save the selected employee's name, because we will remove 
                // the employee's name from the list. 
                string selectedValue = (string)cbosubtitle.SelectedItem;

                if (selectedValue == "MR" || selectedValue == "SR." || selectedValue == "MASTER.")
                {
                    combosex.SelectedIndex = 0;
                }
                else
                {
                    combosex.SelectedIndex = 1;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void txtpatient_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsUpper(e.KeyChar) || char.IsLower(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar.ToString() == ".")
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void txtage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void txtfather_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsUpper(e.KeyChar) || char.IsLower(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar.ToString() == "." || e.KeyChar.ToString() == "/")
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void txtpincode_TextChanged(object sender, EventArgs e)
        {
            try
            {
                TextBox txtPins = (TextBox)sender;
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@Pincode", txtPins.Text.Trim());
                System.Data.DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_FetchPincodeSP", hstbl);
                if (dtLoad != null && dtLoad.Rows.Count > 0)
                {
                    txtlocation.Text = dtLoad.Rows[0]["Location"].ToString().ToUpper();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtpincode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void txtregid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '/'))
            {
                e.Handled = true;
            }

            if (e.KeyChar == '/' && txtregid.Text.IndexOf('/') > -1)
            {
                e.Handled = true;
            }
            //if (char.IsNumber(e.KeyChar))
            //{

            //}
            //else
            //{
            //    e.Handled = e.KeyChar != (char)Keys.Back;
            //}
        }

        private void AddPinCode()
        {
            try
            {
                if ((txtpincode.Text != String.Empty || txtpincode.Text != "") && (txtpincode.Text.Length >= 6) && (txtlocation.Text != String.Empty || txtlocation.Text != ""))
                {
                    Hashtable hstbl = new Hashtable();
                    hstbl.Add("@PinCode", txtpincode.Text);
                    DataSet ds = DataAccessLayer.GetDataset("Hospital_AddPinCode", hstbl);
                    if (ds.Tables.Count == 0)
                    {
                        Hashtable hstbl1 = new Hashtable();
                        hstbl1.Add("@PinCode", txtpincode.Text != String.Empty ? txtpincode.Text.Trim() : "0");
                        hstbl1.Add("@Location", txtlocation.Text != String.Empty ? txtlocation.Text.Trim() : null);
                        Int64 Result = DataAccessLayer.ReturnInsertDataCommand("Hospital_InsertPinCode", hstbl1);
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Clear()
        {
            txtregid.Text = String.Empty;
            dtpreg.Value = DateTime.Now;
            cbosubtitle.SelectedIndex = 1;
            txtpatient.Text = String.Empty;
            txtfather.Text = String.Empty;
            txtage.Text = String.Empty;
            combosex.SelectedIndex = 0;
            txtflat.Text = String.Empty;
            txtbuildname.Text = String.Empty;
            txtstreet.Text = String.Empty;
            txtpincode.Text = String.Empty;
            txtlocation.Text = String.Empty;
            txtcity.Text = String.Empty;
            txtstate.Text = String.Empty;
            txtcountry.Text = String.Empty;
            txtcontactno.Text = String.Empty;
            DiseasesClear();
            table.Rows.Clear();
            txtlandline.Text = String.Empty;
            cmbmartial.SelectedIndex = 0;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Clear();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void txtlocation_TextChanged(object sender, EventArgs e)
        {

        }

        public void LoadDropDown()
        {
            try
            {
                //Dropdown list values is selected  from database without using <asp:list items>////
                System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("Hospital_CountryMaster_Sp");

                if (dsLoad != null)
                {
                    if (dsLoad.Rows.Count > 0)
                    {
                        txtcountry.DataSource = new BindingSource(dsLoad, null);
                        txtcountry.DisplayMember = "Name";
                        txtcountry.ValueMember = "CountryId";
                        txtcountry.SelectedValue = 100;
                    }

                    System.Data.DataTable dsLoad1 = DataAccessLayer.GetDataTable("Hospital_DiseaseType_Sp");

                    if (dsLoad1.Rows.Count > 0)
                    {
                        ddlDiseaseType.DataSource = new BindingSource(dsLoad1, null);
                        ddlDiseaseType.DisplayMember = "DiseaseName";
                        ddlDiseaseType.ValueMember = "DiseaseId";
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void diseaseadd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtdisease.Text != String.Empty)
                {
                    if (diseaseadd.Text == "Add")
                    {
                        // add rows to datatable                 
                        table.Rows.Add(table.Rows.Count + 1, ddlDiseaseType.Text, ddlDiseaseType.SelectedValue, txtdisease.Text);

                        diseaselist.DataSource = table;
                        diseaselist.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                        DataGridViewCellStyle style = diseaselist.ColumnHeadersDefaultCellStyle;
                        style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        style.Font = new Font(diseaselist.Font, FontStyle.Bold);
                        diseaselist.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
                        diseaselist.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                        diseaselist.EnableHeadersVisualStyles = false;

                        DiseasesClear();
                    }
                    else if (diseaseadd.Text == "Update")
                    {
                        if (table != null && indexRow >= 0)
                        {
                            DataRow[] rows = table.Select("S.NO=" + indexRow);
                            if (rows.Length > 0)
                            {
                                foreach (DataRow row in rows)
                                {
                                    row["Diseases Name"] = ddlDiseaseType.Text;
                                    row["DiseaseId"] = ddlDiseaseType.SelectedValue;
                                    row["Description"] = txtdisease.Text;
                                    table.AcceptChanges();
                                    row.SetModified();
                                }
                            }
                            indexRow = 0;

                            diseaselist.DataSource = null;
                            diseaselist.DataSource = table;
                            //diseaselist.Columns[2].Visible = false;
                            diseaselist.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                        }
                        DiseasesClear();
                        diseaseadd.Text = "Add";
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter Disease description", "Add Disease - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        // Get Selected Row Values From DataGridView Into TextBox
        private void diseaselist_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (table != null)
                {
                    indexRow = e.RowIndex; // get the selected Row Index
                    DataRow row = table.Rows[indexRow];
                    indexRow = Convert.ToInt32(row[0].ToString());
                    ddlDiseaseType.Text = row[1].ToString();
                    txtdisease.Text = row[3].ToString();
                    diseaseadd.Text = "Update";
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void diseaselist_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Right)
                {
                    this.diseaselist.Rows[e.RowIndex].Selected = true;
                    indexRow = e.RowIndex;
                    this.diseaselist.CurrentCell = this.diseaselist.Rows[e.RowIndex].Cells[1];
                    this.contextMenuStrip1.Show(this.diseaselist, e.Location);
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                contextMenuStrip1.Hide();
                if (MessageBox.Show("Do You Want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    foreach (DataGridViewRow item in this.diseaselist.SelectedRows)
                    {
                        table.Rows.RemoveAt(indexRow);
                        DiseasesClear();
                        diseaseadd.Text = "Add";
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        private void DiseasesClear()
        {
            ddlDiseaseType.SelectedValue = 1;
            txtdisease.Text = "";
        }

        public string CreatedegreeXML()
        {
            StringBuilder sb = new StringBuilder();

            foreach (DataRow dr in table.Rows)
            {
                sb.Append(String.Format("<Disease DiseaseId='{0}' Description='{1}' />", dr["DiseaseId"].ToString(), dr["Description"].ToString()));
            }
            return String.Format("<ROOT>{0}</ROOT>", sb.ToString());
        }

        protected void BindGrid()
        {
            try
            {
                Hashtable hst = new Hashtable();
                hst.Add("@RegNo", txtregid.Text.Trim());
                DataSet ds = DataAccessLayer.GetDataset("Hospital_FetchDiseaseGrid_sp", hst);
                //diseaselist.DataSource = null;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    table = ds.Tables[0] as DataTable;
                    table.Columns["DiseaseId"].ColumnMapping = MappingType.Hidden;
                    diseaselist.DataSource = table;
                    diseaselist.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnSearchLookup_Click(object sender, EventArgs e)
        {
            using (PatientFormSearch childform = new PatientFormSearch())
            {
                childform.ShowDialog(this);
            }
        }

        private void txtcontactno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        public void updatetext(string fromchildform)
        {
            txtregid.Text = fromchildform;
            btnSearch.PerformClick();
        }

        private void txtregid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch.PerformClick();
            }
        }

    }
}

