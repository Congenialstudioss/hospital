﻿namespace Sample
{
    partial class MainMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.masterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feesMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.treatmentMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.patientMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.diseaseMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hospitalReviewFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notificationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reviewReportCtrlRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.treatmentReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.lbluser = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.lblDate = new System.Windows.Forms.ToolStripLabel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(177)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterToolStripMenuItem,
            this.transactionToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.quitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(794, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // masterToolStripMenuItem
            // 
            this.masterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.feesMasterToolStripMenuItem,
            this.treatmentMasterToolStripMenuItem,
            this.toolStripMenuItem2,
            this.patientMasterToolStripMenuItem,
            this.toolStripMenuItem1,
            this.diseaseMasterToolStripMenuItem});
            this.masterToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.masterToolStripMenuItem.Name = "masterToolStripMenuItem";
            this.masterToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.masterToolStripMenuItem.Text = "Master";
            // 
            // feesMasterToolStripMenuItem
            // 
            this.feesMasterToolStripMenuItem.Name = "feesMasterToolStripMenuItem";
            this.feesMasterToolStripMenuItem.ShortcutKeyDisplayString = "";
            this.feesMasterToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.feesMasterToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.feesMasterToolStripMenuItem.Text = "&Fees Master";
            this.feesMasterToolStripMenuItem.Click += new System.EventHandler(this.feesMasterToolStripMenuItem_Click);
            // 
            // treatmentMasterToolStripMenuItem
            // 
            this.treatmentMasterToolStripMenuItem.Name = "treatmentMasterToolStripMenuItem";
            this.treatmentMasterToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.treatmentMasterToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.treatmentMasterToolStripMenuItem.Text = "&Treatment Master";
            this.treatmentMasterToolStripMenuItem.Click += new System.EventHandler(this.treatmentMasterToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.toolStripMenuItem2.Size = new System.Drawing.Size(209, 22);
            this.toolStripMenuItem2.Text = "Treatment Fees";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // patientMasterToolStripMenuItem
            // 
            this.patientMasterToolStripMenuItem.Name = "patientMasterToolStripMenuItem";
            this.patientMasterToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.patientMasterToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.patientMasterToolStripMenuItem.Text = "&Patient Master";
            this.patientMasterToolStripMenuItem.Click += new System.EventHandler(this.patientMasterToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.toolStripMenuItem1.Size = new System.Drawing.Size(209, 22);
            this.toolStripMenuItem1.Text = "&Doctor Master";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // diseaseMasterToolStripMenuItem
            // 
            this.diseaseMasterToolStripMenuItem.Name = "diseaseMasterToolStripMenuItem";
            this.diseaseMasterToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.diseaseMasterToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.diseaseMasterToolStripMenuItem.Text = "Disease Master";
            this.diseaseMasterToolStripMenuItem.Click += new System.EventHandler(this.diseaseMasterToolStripMenuItem_Click);
            // 
            // transactionToolStripMenuItem
            // 
            this.transactionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registrationToolStripMenuItem,
            this.hospitalReviewFormToolStripMenuItem,
            this.notificationToolStripMenuItem});
            this.transactionToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.transactionToolStripMenuItem.Name = "transactionToolStripMenuItem";
            this.transactionToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.transactionToolStripMenuItem.Text = "Transaction";
            // 
            // registrationToolStripMenuItem
            // 
            this.registrationToolStripMenuItem.Name = "registrationToolStripMenuItem";
            this.registrationToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.registrationToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.registrationToolStripMenuItem.Text = "&New Registration";
            this.registrationToolStripMenuItem.Click += new System.EventHandler(this.registrationToolStripMenuItem_Click);
            // 
            // hospitalReviewFormToolStripMenuItem
            // 
            this.hospitalReviewFormToolStripMenuItem.Name = "hospitalReviewFormToolStripMenuItem";
            this.hospitalReviewFormToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4;
            this.hospitalReviewFormToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.hospitalReviewFormToolStripMenuItem.Text = "Treatment History";
            this.hospitalReviewFormToolStripMenuItem.Click += new System.EventHandler(this.hospitalReviewFormToolStripMenuItem_Click);
            // 
            // notificationToolStripMenuItem
            // 
            this.notificationToolStripMenuItem.Name = "notificationToolStripMenuItem";
            this.notificationToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.notificationToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.notificationToolStripMenuItem.Text = "Notification";
            this.notificationToolStripMenuItem.Click += new System.EventHandler(this.notificationToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportToolStripMenuItem1,
            this.reviewReportCtrlRToolStripMenuItem,
            this.treatmentReportToolStripMenuItem});
            this.reportToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // reportToolStripMenuItem1
            // 
            this.reportToolStripMenuItem1.Name = "reportToolStripMenuItem1";
            this.reportToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F6;
            this.reportToolStripMenuItem1.Size = new System.Drawing.Size(190, 22);
            this.reportToolStripMenuItem1.Text = "Register Report";
            this.reportToolStripMenuItem1.Click += new System.EventHandler(this.RegisterReportToolStripMenuItem_Click);
            // 
            // reviewReportCtrlRToolStripMenuItem
            // 
            this.reviewReportCtrlRToolStripMenuItem.Name = "reviewReportCtrlRToolStripMenuItem";
            this.reviewReportCtrlRToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.reviewReportCtrlRToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.reviewReportCtrlRToolStripMenuItem.Text = "Review Report";
            this.reviewReportCtrlRToolStripMenuItem.Click += new System.EventHandler(this.reviewReportCtrlRToolStripMenuItem_Click);
            // 
            // treatmentReportToolStripMenuItem
            // 
            this.treatmentReportToolStripMenuItem.Name = "treatmentReportToolStripMenuItem";
            this.treatmentReportToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7;
            this.treatmentReportToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.treatmentReportToolStripMenuItem.Text = "Treatment Report";
            this.treatmentReportToolStripMenuItem.Click += new System.EventHandler(this.treatmentReportToolStripMenuItem_Click);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.quitToolStripMenuItem.Text = "&Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(500, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Sample.Properties.Resources.slider4;
            this.pictureBox1.Location = new System.Drawing.Point(0, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(794, 544);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.lbluser,
            this.toolStripSeparator1,
            this.toolStripLabel3,
            this.lblDate});
            this.toolStrip1.Location = new System.Drawing.Point(0, 543);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(794, 25);
            this.toolStrip1.TabIndex = 6;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(72, 22);
            this.toolStripLabel1.Text = "Login User :";
            // 
            // lbluser
            // 
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(0, 22);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(74, 22);
            this.toolStripLabel3.Text = "Login Time :";
            // 
            // lblDate
            // 
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(0, 22);
            // 
            // MainMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(794, 568);
            this.ControlBox = false;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainMaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vignesh Dental Hospital";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainMaster_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem masterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feesMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem patientMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem reviewReportCtrlRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hospitalReviewFormToolStripMenuItem;
        //private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem treatmentMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem treatmentReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diseaseMasterToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripLabel lbluser;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripLabel lblDate;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem notificationToolStripMenuItem;

    }
}

