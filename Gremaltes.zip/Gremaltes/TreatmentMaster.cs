﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class TreatmentMaster : Form
    {
        int indexRow;
        public TreatmentMaster()
        {
            InitializeComponent();
            LoadTreatment();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txttreatment.Text != String.Empty)
                {
                    if (btnsave.Text == "Save")
                    {
                        Hashtable hstbl = new Hashtable();
                        hstbl.Add("@Action", "Insert");
                        hstbl.Add("@ModifyBy", Global.UserID);
                        hstbl.Add("@TreatmentName", txttreatment.Text.Trim());
                        Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_SaveTreatmentMaster_sp", hstbl);
                        if (intIdentity > 0)
                        {
                            MessageBox.Show("Treatment Details Saved Successfully.", "Treatment Alert");
                            txttreatment.Text = String.Empty;
                            LoadTreatment();
                        }
                    }

                    else if (btnsave.Text == "Update")
                    {
                        Hashtable hstbl = new Hashtable();
                        DataGridViewRow row = Gvtreatment.Rows[indexRow];

                        hstbl.Add("@Action", "Update");
                        hstbl.Add("@ModifyBy", Global.UserID);
                        hstbl.Add("@TreatmentName", txttreatment.Text.Trim());
                        hstbl.Add("@TreatmentId", row.Cells[1].Value);
                        Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_SaveTreatmentMaster_sp", hstbl);
                        if (intIdentity > 0)
                        {
                            MessageBox.Show("Treatment Details Updated Successfully.", "Treatment Alert");
                            txttreatment.Text = String.Empty;
                            LoadTreatment();
                            btnsave.Text = "Save";
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the Treatment name", "Treatment Alert");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        protected void LoadTreatment()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("Action", "Get");
                DataSet ds = DataAccessLayer.GetDataset("Hospital_SaveTreatmentMaster_sp", hstbl);
                Gvtreatment.DataSource = null;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Gvtreatment.DataSource = ds.Tables[0];
                    Gvtreatment.Columns[1].Visible = false;
                    Gvtreatment.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    DataGridViewCellStyle style = Gvtreatment.ColumnHeadersDefaultCellStyle;
                    style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    style.Font = new Font(Gvtreatment.Font, FontStyle.Bold);
                    Gvtreatment.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
                    Gvtreatment.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    Gvtreatment.EnableHeadersVisualStyles = false;
                }               
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Gvtreatment_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                indexRow = e.RowIndex;
                DataGridViewRow row = Gvtreatment.Rows[indexRow];
                txttreatment.Text = row.Cells[2].Value.ToString();
                btnsave.Text = "Update";
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                contextMenuStrip1.Hide();
                if (MessageBox.Show("Do you want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    DataGridViewRow row = Gvtreatment.Rows[indexRow];

                    hstbl.Add("@Action", "Delete");
                    hstbl.Add("@ModifyBy", Global.UserID);
                    hstbl.Add("@TreatmentId", row.Cells[1].Value);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_SaveTreatmentMaster_sp", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show("Treatment Details Deleted Successfully.", "Treatment Alert");
                        txttreatment.Text = String.Empty;
                        LoadTreatment();
                        btnsave.Text = "Save";
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        private void Gvtreatment_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Right)
                {
                    this.Gvtreatment.Rows[e.RowIndex].Selected = true;
                    indexRow = e.RowIndex;
                    this.Gvtreatment.CurrentCell = this.Gvtreatment.Rows[e.RowIndex].Cells[2];
                    this.contextMenuStrip1.Show(this.Gvtreatment, e.Location);
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
    }
}
