﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using Sample;
using System.IO;
using System.Drawing.Printing;
using System.Diagnostics;
using Sample.DataAccess;
using System.Configuration;

namespace WindowsFormsApplication3
{

    public partial class RegisterForm : Form
    {
        static Int32 Fees_ID = 0;
        static string RegisterNo = "0";
        static Int32 VictimID = 0;
        DataTable table;
        static int indexRow;

        public RegisterForm()
        {
            InitializeComponent();
        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {
            ddlDiseaseType.Select();
            LoadDropDown();
            txtYear.Text = DateTime.Today.Year.ToString();
            LoadFees();
            ddlSex.SelectedIndex = 0;
            ddlSurName.SelectedIndex = 1;
            //txtregfees.Text = "0";
            //txtconfees.Text = "0";
            txtcontactno.MaxLength = 10;
            cmbmartial.SelectedIndex = 0;

            //add columns to datatable  
            table = new DataTable();
            table.Columns.Add("S.NO", typeof(string));
            table.Columns.Add("Diseases Name", typeof(string));
            table.Columns.Add("DiseaseId", typeof(string));
            table.Columns.Add("Description", typeof(string));

            table.Columns["DiseaseId"].ColumnMapping = MappingType.Hidden;

            diseaselist.DataSource = table;
            diseaselist.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            DataGridViewCellStyle style = diseaselist.ColumnHeadersDefaultCellStyle;
            style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            style.Font = new Font(diseaselist.Font, FontStyle.Bold);
            diseaselist.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
            diseaselist.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            diseaselist.EnableHeadersVisualStyles = false;
        }

        #region Events
        private void Save_Click(object sender, EventArgs e)
        {
            AddPinCode();
            SaveMethod();
            Clear();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do you want to Print ?", "Print - Victim Register", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    if (RegisterNo != "0")
                    {
                        //Printers obj = new Printers();
                        //obj.NewRecepitData(VictimID);
                        //PrintWin32Spooler.RawPrinterHelper.SendFileToPrinter(ConfigurationManager.AppSettings["PrinterName"].ToString(), ConfigurationManager.AppSettings["ReceiptFilePath"].ToString());
                        //MessageBox.Show("Printed Successfully", "Print _ Success");

                        RegisterPrint reg = new RegisterPrint();
                        this.Visible = false;
                        reg.RegisterRecepitData(VictimID);
                        reg.ShowDialog(this);
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void validateTextInteger(object sender, EventArgs e)
        {
            Exception X = new Exception();

            TextBox T = (TextBox)sender;

            try
            {
                if (T.Text != "-")
                {
                    int x = int.Parse(T.Text);
                }
            }
            catch (Exception)
            {
                try
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
                catch (Exception) { }
            }
        }

        private void txtage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void RegisterForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Alt && e.KeyCode == Keys.S)
            {
                SaveMethod();
            }
            if (e.Alt && e.KeyCode == Keys.P)
            {
                btnPrint_Click(sender, e);
            }
        }

        private void txtpincode_TextChanged(object sender, EventArgs e)
        {

        }

        private void ddlDiseaseType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ComboBox comboBox = (ComboBox)sender;

                // Save the selected employee's name, because we will remove 
                // the employee's name from the list. 
                string selectedValue = (string)ddlDiseaseType.Text;

                if (selectedValue.ToLower().Contains("leprosy"))
                {
                    chkFree.Checked = true;
                    txtregfees.Enabled = false;
                    txtconfees.Enabled = false;
                    txtconfees.Text = "0";
                    txtregfees.Text = "0";
                    chkFree.Enabled = false;

                }
                else
                {
                    chkFree.Checked = false;
                    chkFree.Enabled = true;
                    txtregfees.Enabled = true;
                    txtconfees.Enabled = true;
                    LoadFees();
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void txtpincode_TabIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@Pincode", txtpincode.Text.Trim());
                System.Data.DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_FetchPincodeSP", hstbl);
                if (dtLoad != null && dtLoad.Rows.Count > 0)
                {
                    txtlocation.Text = dtLoad.Rows[0]["Location"].ToString().ToUpper();
                }
                else
                {
                    MessageBox.Show("Location Not Available", "Pincode - Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtpincode_TextChanged_1(object sender, EventArgs e)
        {
            try
            {
                if (txtpincode.TextLength == 6)
                {
                    TextBox txtPins = (TextBox)sender;
                    Hashtable hstbl = new Hashtable();
                    hstbl.Add("@Pincode", txtPins.Text.Trim());
                    System.Data.DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_FetchPincodeSP", hstbl);
                    if (dtLoad != null && dtLoad.Rows.Count > 0)
                    {
                        txtlocation.Text = dtLoad.Rows[0]["Location"].ToString().ToUpper();
                    }
                    else
                    {
                        MessageBox.Show("Location Not Available", "Pincode - Error");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtPincode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        void Alphabets_Only(object sender, KeyPressEventArgs e)
        {
            if (char.IsUpper(e.KeyChar) || char.IsLower(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar.ToString() == "." || e.KeyChar.ToString() == "/")
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }
        #endregion

        #region Methods and User Defined Functions
        public void LoadDropDown()
        {
            try
            {
                //Dropdown list values is selected  from database without using <asp:list items>////
                System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("Hospital_CountryMaster_Sp");

                if (dsLoad != null)
                {
                    if (dsLoad.Rows.Count > 0)
                    {
                        txtcountry.DataSource = new BindingSource(dsLoad, null);
                        txtcountry.DisplayMember = "Name";
                        txtcountry.ValueMember = "CountryId";
                        txtcountry.SelectedValue = 100;
                    }

                    System.Data.DataTable dsLoad1 = DataAccessLayer.GetDataTable("Hospital_DiseaseType_Sp");

                    if (dsLoad1.Rows.Count > 0)
                    {
                        ddlDiseaseType.DataSource = new BindingSource(dsLoad1, null);
                        ddlDiseaseType.DisplayMember = "DiseaseName";
                        ddlDiseaseType.ValueMember = "DiseaseId";
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void LoadFees()
        {
            try
            {
                //Hashtable hstbl = new Hashtable();
                //hstbl.Add("@Type", ddlDiseaseType.SelectedItem != null ? ddlDiseaseType.Text.ToLower().Contains("eye") ? "EYE" : "GENERAL" : (object)DBNull.Value);
                DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_FeesDetails_Sp");
                //System.Data.DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_GetCurrentFeesDetails_Sp");
                if (dtLoad != null && dtLoad.Rows.Count > 0)
                {
                    Fees_ID = Convert.ToInt32(dtLoad.Rows[0]["FeesId"].ToString());
                    txtconfees.Text = dtLoad.Rows[0]["Consulting"].ToString();
                    txtregfees.Text = dtLoad.Rows[0]["Registration"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void SaveMethod()
        {
            try
            {
                if (is_validate())
                {

                    ErrorMessage.Clear();

                    // Write Coding to add into database              

                    Hashtable hstbl1 = new Hashtable();
                    hstbl1.Add("SubTitle", ddlSurName.SelectedIndex);
                    hstbl1.Add("Name", txtpatient.Text.Trim());
                    hstbl1.Add("Age", txtage.Text != String.Empty ? Convert.ToInt16(txtage.Text) : 0);
                    hstbl1.Add("GuardianName", txtfather.Text.Trim());
                    hstbl1.Add("Sex", ddlSex.SelectedIndex);
                    hstbl1.Add("FlatNo", txtflat.Text.Trim());
                    hstbl1.Add("BuildingName", txtbuildname.Text.Trim());
                    hstbl1.Add("Street", txtstreet.Text.Trim());
                    hstbl1.Add("Location", txtlocation.Text.Trim());
                    hstbl1.Add("City", txtcity.Text.Trim());
                    hstbl1.Add("StateId", txtstate.Text.Trim());
                    hstbl1.Add("CountryId", txtcountry.SelectedValue);
                    hstbl1.Add("PinCode", txtpincode.Text.Trim());
                    hstbl1.Add("FeesId", Fees_ID);
                    hstbl1.Add("Free", Convert.ToBoolean(chkFree.Checked ? true : false));
                    hstbl1.Add("Year", txtYear.Text.Trim());
                    hstbl1.Add("SequenceNo", txtseqno.Text.Trim());
                    hstbl1.Add("RegDate", Convert.ToDateTime(dtTodayDate.Value));
                    hstbl1.Add("RegFee", Convert.ToInt32(txtregfees.Text != string.Empty ? txtregfees.Text.Trim() : "0"));
                    hstbl1.Add("ConsFee", Convert.ToInt32(txtconfees.Text != string.Empty ? txtconfees.Text.Trim() : "0"));
                    hstbl1.Add("CreatedDate", DateTime.Now);
                    hstbl1.Add("@ModifyBy", Global.UserID);

                    hstbl1.Add("@Landline", txtlandline.Text.Trim());
                    hstbl1.Add("@Martial", cmbmartial.SelectedIndex);
                    if (txtcontactno.Text != "")
                    {
                        hstbl1.Add("ContactNo", txtcontactno.Text.Trim());
                    }

                    string Diseasexml = CreatedegreeXML();
                    if (Diseasexml.Length > 0)
                    {
                        hstbl1.Add("@DiseaseXml", Diseasexml);
                    }

                    string ReturnValue = DataAccessLayer.ReturnInsertsDataCommand("Hospital_RegForm_insert_Sp", hstbl1);

                    if (ReturnValue != string.Empty)
                    {
                        string[] Sequence = ReturnValue.Split('~');
                        if (Sequence.Length == 3)
                        {
                            txtseqno.Text = Sequence[1].ToString();

                            RegisterNo = Sequence[0].ToString();
                            VictimID = Convert.ToInt32(Sequence[2].ToString());
                            //btnReceipt.Visible = true;
                            btnPrint.Visible = true;
                        }
                        DialogResult result = MessageBox.Show("Victim Information Saved Sucessfully :-" + RegisterNo + ", Do You Want to Print?", "Registration - Success", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            if (RegisterNo != "0")
                            {
                                //Printers obj = new Printers();
                                //obj.PrintMethod(RegisterNo.ToString(),ddlDiseaseType.Text);
                                //Printers prt = new Printers();
                                //prt.NewRecepitData(VictimID);
                                //PrintWin32Spooler.RawPrinterHelper.SendFileToPrinter(ConfigurationManager.AppSettings["PrinterName"].ToString(), ConfigurationManager.AppSettings["ReceiptFilePath"].ToString());
                                //MessageBox.Show("Printed Successfully", "Print _ Success");

                                RegisterPrint reg = new RegisterPrint();
                                this.Visible = false;
                                reg.RegisterRecepitData(VictimID);
                                reg.ShowDialog(this);
                            }
                        }
                        else
                        {
                            Clear();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Victim Information Not Saved", "Registration - Error");
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        /* Validation */

        private bool is_validate()
        {
            bool no_error = true;
            if (txtpatient.Text == string.Empty)
            {
                ErrorMessage.SetError(txtpatient, "Enter the Victim Name");
                no_error = false;
            }
            else if (txtcontactno.Text == string.Empty)
            {
                ErrorMessage.SetError(txtcontactno, "Enter the Contact No");
                no_error = false;
            }
            else
            {
                // Clear all Error Messages
                ErrorMessage.SetError(this.txtpatient, String.Empty);
            }
            return no_error;
        }

        public String pad(String value, int length, String with)
        {
            StringBuilder result = new StringBuilder(length);
            // Pre-fill a String value
            result.Append(fill(Math.Max(0, length - value.Length), with));
            result.Append(value);

            return result.ToString();
        }

        public String fill(int length, String with)
        {
            StringBuilder sb = new StringBuilder(length);
            while (sb.Length < length)
            {
                sb.Append(with);
            }
            return sb.ToString();
        }
        #endregion

        private void ddlSurName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ComboBox comboBox = (ComboBox)sender;

                // Save the selected employee's name, because we will remove 
                // the employee's name from the list. 
                string selectedValue = (string)ddlSurName.SelectedItem;

                if (selectedValue == "MR" || selectedValue == "SR." || selectedValue == "MASTER.")
                {
                    ddlSex.SelectedIndex = 0;
                }
                else
                {
                    ddlSex.SelectedIndex = 1;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Clear()
        {
            ddlSurName.SelectedIndex = 1;
            ddlSex.SelectedIndex = 0;
            txtpatient.Text = String.Empty;
            txtage.Text = String.Empty;
            txtfather.Text = String.Empty;
            txtflat.Text = String.Empty;
            txtbuildname.Text = String.Empty;
            txtstreet.Text = String.Empty;
            txtlocation.Text = String.Empty;
            txtseqno.Text = string.Empty;
            txtcity.Text = "CHENNAI";
            txtstate.Text = "TAMIL NADU";
            txtcountry.SelectedValue = 100;
            txtpincode.Text = "600";
            txtcontactno.Text = String.Empty;
            table.Rows.Clear();
            txtlandline.Text = String.Empty;
            cmbmartial.SelectedIndex = 0;
        }

        private void chkFree_Click(object sender, EventArgs e)
        {
            try
            {
                if (chkFree.Checked)
                {
                    txtregfees.Text = "0";
                    txtconfees.Text = "0";
                }
                else
                {
                    LoadFees();
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void AddPinCode()
        {
            try
            {
                if ((txtpincode.Text != String.Empty || txtpincode.Text != "") && (txtpincode.Text.Length >= 6) && (txtlocation.Text != String.Empty || txtlocation.Text != ""))
                {
                    Hashtable hstbl = new Hashtable();
                    hstbl.Add("@PinCode", txtpincode.Text);
                    DataSet ds = DataAccessLayer.GetDataset("Hospital_AddPinCode", hstbl);
                    if (ds.Tables.Count == 0)
                    {
                        Hashtable hstbl1 = new Hashtable();
                        hstbl1.Add("@PinCode", txtpincode.Text != String.Empty ? txtpincode.Text.Trim() : "0");
                        hstbl1.Add("@Location", txtlocation.Text != String.Empty ? txtlocation.Text.Trim() : null);
                        Int64 Result = DataAccessLayer.ReturnInsertDataCommand("Hospital_InsertPinCode", hstbl1);
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void txtpatient_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsUpper(e.KeyChar) || char.IsLower(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar.ToString() == ".")
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void dtTodayDate_ValueChanged(object sender, EventArgs e)
        {
            txtYear.Text = dtTodayDate.Value.ToString("yyyy");
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void diseaseadd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtdisease.Text != String.Empty)
                {
                    if (diseaseadd.Text == "Add")
                    {
                        // add rows to datatable      
                        //diseaselist.DataSource = null;
                        table.Rows.Add(table.Rows.Count + 1, ddlDiseaseType.Text, ddlDiseaseType.SelectedValue, txtdisease.Text.Trim());

                        diseaselist.DataSource = table;
                        diseaselist.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                        DataGridViewCellStyle style = diseaselist.ColumnHeadersDefaultCellStyle;
                        style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        style.Font = new Font(diseaselist.Font, FontStyle.Bold);
                        diseaselist.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
                        diseaselist.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                        diseaselist.EnableHeadersVisualStyles = false;

                        DiseasesClear();
                    }
                    else if (diseaseadd.Text == "Update")
                    {
                        if (table != null && indexRow >= 0)
                        {
                            DataRow[] rows = table.Select("S.NO=" + indexRow);
                            if (rows.Length > 0)
                            {
                                foreach (DataRow row in rows)
                                {
                                    row["Diseases Name"] = ddlDiseaseType.Text;
                                    row["DiseaseId"] = ddlDiseaseType.SelectedValue;
                                    row["Description"] = txtdisease.Text.Trim();
                                    table.AcceptChanges();
                                    row.SetModified();
                                }
                            }
                            indexRow = 0;

                            diseaselist.DataSource = null;
                            diseaselist.DataSource = table;
                            diseaselist.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                        }
                        DiseasesClear();
                        diseaseadd.Text = "Add";
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter Disease description", "Add Disease - Error");
                }

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        // Get Selected Row Values From DataGridView Into TextBox
        private void diseaselist_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (table != null)
                {
                    indexRow = e.RowIndex; // get the selected Row Index
                    DataRow row = table.Rows[indexRow];
                    indexRow = Convert.ToInt32(row[0].ToString());
                    ddlDiseaseType.Text = row[1].ToString();
                    txtdisease.Text = row[3].ToString();
                    diseaseadd.Text = "Update";
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void diseaselist_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Right)
                {
                    this.diseaselist.Rows[e.RowIndex].Selected = true;
                    indexRow = e.RowIndex;
                    this.diseaselist.CurrentCell = this.diseaselist.Rows[e.RowIndex].Cells[1];
                    this.contextMenuStrip1.Show(this.diseaselist, e.Location);
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                contextMenuStrip1.Hide();
                if (MessageBox.Show("Do you want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    foreach (DataGridViewRow item in this.diseaselist.SelectedRows)
                    {
                        table.Rows.RemoveAt(indexRow);
                        DiseasesClear();
                        diseaseadd.Text = "Add";
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        private void DiseasesClear()
        {
            ddlDiseaseType.SelectedValue = 1;
            txtdisease.Text = "";
        }

        public string CreatedegreeXML()
        {
            StringBuilder sb = new StringBuilder();

            foreach (DataRow dr in table.Rows)
            {
                sb.Append(String.Format("<Disease DiseaseId='{0}' Description='{1}' />", dr["DiseaseId"].ToString(), dr["Description"].ToString()));
            }
            return String.Format("<ROOT>{0}</ROOT>", sb.ToString());
        }

        private void txtcontactno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

    }
}
