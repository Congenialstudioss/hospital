﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApplication3;

namespace Sample
{
    public partial class MainMaster : Form
    {
        public MainMaster()
        {
            InitializeComponent();
        }

        private void feesMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FeesMaster objFees = new FeesMaster();
            objFees.ShowDialog(this);
        }

        private void registrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegisterForm objreg = new RegisterForm();
            objreg.ShowDialog(this);
        }

        private void patientMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PatientForm objreg = new PatientForm();
            objreg.ShowDialog(this);
        }

        private void RegisterReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HospitalRegisterReport objreg = new HospitalRegisterReport();
            objreg.ShowDialog(this);
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure want to Quit ?", "Exit", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void MainMaster_Load(object sender, EventArgs e)
        {
            //this.label1.Location = new System.Drawing.Point(151, 120);
            //this.label1.Name = "label2";
            //this.label1.Size = new System.Drawing.Size(35, 13);
            //this.label1.TabIndex = 1;
            //this.label1.Text = System.DateTime.Now.ToShortTimeString();
            Timer tmr = new Timer();
            tmr.Interval = 1000;//ticks every 1 second
            tmr.Tick += new EventHandler(tmr_Tick);
            tmr.Start();

            lbluser.Text = Global.UserName;
            //lbltime.Text = DateTime.Now.ToString();
        }

        //change the label text inside the tick event
        private void tmr_Tick(object sender, EventArgs e)
        {
            lblDate.Text = DateTime.Now.ToString("MMM/dd/yyyy HH:mm:ss");
            //LblUTCTime.Text   = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss");          
        }

        private void reviewReportCtrlRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Hospital_ReviewReports objrev = new Hospital_ReviewReports();
            objrev.ShowDialog(this);
        }

        private void hospitalReviewFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreatmentHistory hsptl = new TreatmentHistory();
            hsptl.ShowDialog(this);
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DoctorMaster dm = new DoctorMaster();
            dm.ShowDialog(this);
        }

        private void treatmentMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreatmentMaster tm = new TreatmentMaster();
            tm.ShowDialog(this);
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Treatment_Fees_Master dm = new Treatment_Fees_Master();
            dm.ShowDialog(this);
        }

        private void treatmentReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Hospital_TreatmentReports objrev = new Hospital_TreatmentReports();
            objrev.ShowDialog(this);
        }

        private void diseaseMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DiseaseMaster dis = new DiseaseMaster();
            dis.ShowDialog(this);
        }

        private void notificationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("Hospital_NotificationData_sp");
            if (dsLoad.Rows.Count > 0)
            {
                Notification n = new Notification();
                n.ShowDialog(this);
            }
            else
            {
                MessageBox.Show("Currently we dont have any notifications !!!", "Notification - Warning");
            }
        }

    }
}
