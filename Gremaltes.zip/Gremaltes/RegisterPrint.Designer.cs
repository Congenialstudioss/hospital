﻿namespace Sample
{
    partial class RegisterPrint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegisterPrint));
            this.RegPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.RegPrintdoc = new System.Drawing.Printing.PrintDocument();
            this.txtno = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.Label();
            this.txtdate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.txttotal = new System.Windows.Forms.Label();
            this.txtfees = new System.Windows.Forms.Label();
            this.txtdescription = new System.Windows.Forms.Label();
            this.txtsno = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // RegPreviewDialog
            // 
            this.RegPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.RegPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.RegPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.RegPreviewDialog.Document = this.RegPrintdoc;
            this.RegPreviewDialog.Enabled = true;
            this.RegPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("RegPreviewDialog.Icon")));
            this.RegPreviewDialog.Name = "RegPreviewDialog";
            this.RegPreviewDialog.ShowIcon = false;
            this.RegPreviewDialog.Visible = false;
            // 
            // RegPrintdoc
            // 
            this.RegPrintdoc.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.RegPrintdoc_PrintPage);
            // 
            // txtno
            // 
            this.txtno.AutoSize = true;
            this.txtno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtno.Location = new System.Drawing.Point(225, 115);
            this.txtno.Name = "txtno";
            this.txtno.Size = new System.Drawing.Size(0, 16);
            this.txtno.TabIndex = 8;
            // 
            // txtname
            // 
            this.txtname.AutoSize = true;
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(225, 150);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(0, 16);
            this.txtname.TabIndex = 9;
            // 
            // txtdate
            // 
            this.txtdate.AutoSize = true;
            this.txtdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdate.Location = new System.Drawing.Point(564, 115);
            this.txtdate.Name = "txtdate";
            this.txtdate.Size = new System.Drawing.Size(0, 16);
            this.txtdate.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(165, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "No       : ";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(294, 17);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(224, 64);
            this.lblAddress.TabIndex = 25;
            this.lblAddress.Text = "Vignesh Dental Hospital\r\nNo.Z-279, 5th Avenue,\r\nAnna Nagar West, Chennai - 600 04" +
    "0\r\nPhone : 2620 9181";
            this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(165, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(512, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Date : ";
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(363, 371);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 11;
            this.btnPrint.Text = "Print Preview";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // txttotal
            // 
            this.txttotal.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.txttotal.AutoSize = true;
            this.txttotal.Location = new System.Drawing.Point(495, 102);
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(0, 16);
            this.txttotal.TabIndex = 10;
            this.txttotal.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtfees
            // 
            this.txtfees.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.txtfees.AutoSize = true;
            this.txtfees.Location = new System.Drawing.Point(495, 57);
            this.txtfees.Name = "txtfees";
            this.txtfees.Size = new System.Drawing.Size(0, 16);
            this.txtfees.TabIndex = 9;
            this.txtfees.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtdescription
            // 
            this.txtdescription.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtdescription.AutoSize = true;
            this.txtdescription.Location = new System.Drawing.Point(76, 57);
            this.txtdescription.Name = "txtdescription";
            this.txtdescription.Size = new System.Drawing.Size(0, 16);
            this.txtdescription.TabIndex = 8;
            this.txtdescription.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtsno
            // 
            this.txtsno.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtsno.AutoSize = true;
            this.txtsno.Location = new System.Drawing.Point(36, 57);
            this.txtsno.Name = "txtsno";
            this.txtsno.Size = new System.Drawing.Size(0, 16);
            this.txtsno.TabIndex = 7;
            this.txtsno.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(241, 102);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Total";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(76, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Charge\'s";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "S.NO";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(456, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Fees";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.49669F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.50331F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 212F));
            this.tableLayoutPanel1.Controls.Add(this.label6, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtsno, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtdescription, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtfees, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.txttotal, 3, 2);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(147, 200);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.15385F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.84615F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(499, 132);
            this.tableLayoutPanel1.TabIndex = 12;
            // 
            // RegisterPrint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(775, 421);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.txtdate);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtno);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RegisterPrint";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegisterPrint";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PrintPreviewDialog RegPreviewDialog;
        private System.Drawing.Printing.PrintDocument RegPrintdoc;
        private System.Windows.Forms.Label txtno;
        private System.Windows.Forms.Label txtname;
        private System.Windows.Forms.Label txtdate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label txttotal;
        private System.Windows.Forms.Label txtfees;
        private System.Windows.Forms.Label txtdescription;
        private System.Windows.Forms.Label txtsno;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;

    }
}