﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class RegisterFormReport : Form
    {
        public int SPatientType;
        public int SDiseaseType;
        public int Year;
        public long SequenceNo;

        public RegisterFormReport(long seqno)
        {
            this.SequenceNo = seqno;
            InitializeComponent();
        }

        private void RegisterFormReport_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'GremaltesRegisterDataSet.Gremlates_RegistrationReport_Sp' table. You can move, or remove it, as needed.
            this.Gremlates_RegistrationReport_SpTableAdapter.Fill(this.GremaltesRegisterDataSet.Gremlates_RegistrationReport_Sp, null, null, 
               // DateTime.Today.AddDays(-1).AddHours(00).AddMinutes(00).AddSeconds(00),
               //DateTime.Today.AddHours(23).AddMinutes(59).AddSeconds(59),
               null,null,
               string.Empty, string.Empty, this.SequenceNo.ToString());

            this.reportViewer1.RefreshReport();
        }
    }
}
