﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sample
{
    class PrintModel
    {
            // Printing commands are depends on the Dotmatrix printer that we are using

            System.IO.StreamWriter rdr;

            private string Bold_On = "_G";
            private string Bold_Off = "_H";
            private string Width_On = "_W1"; //Chr(27) + Chr(87) + Chr(49) 'W1
            private string Width_Off = "_W0";

            //Public Const Compress_On = "¤"       'Chr(15)    '¤"
            //Public Const Compress_Off = "_" 'Chr(18)   '_
            private string ELITE_PITCH = "_M";
            private string Compress_On = "_ð";      //Chr(15)    '¤"
            private string Compress_Off = "_";

            private int ColWidth = 60;
            public string BillType;
            public string BillNo;
            public string BillDt;
            public string Clerk;
            public string ClientName = "";
            public decimal Discount;
            public decimal TotalAmt;
            public decimal NetAmount;
            public decimal MRPTotal = 0, SavedTotal = 0;
            public System.Data.DataTable dt;

            public void clsPrintSettings()
            {
                rdr = new System.IO.StreamWriter("bill.txt");
                //rdr.AutoFlush();
            }
            public void Close()
            {
                rdr.Close();
            }
            public void PrintHeader()
            {
                //PrintLine();
                rdr.WriteLine(Bold_On + "ABC SUPER MARKET, KERALA" + Bold_Off);
                rdr.WriteLine("KGST : 23040117 DT 1/1/2001");
                rdr.WriteLine("CST  : 23040117 DT 1/1/2001");
                PrintLine();
                rdr.WriteLine(Bold_On + Width_On + BillType + Width_Off + Bold_Off);
                PrintLine();
                rdr.WriteLine("Customer : " + ClientName);
                PrintLine();
            }
            //------------------------------

            public void PrintDetails()
            {

                rdr.WriteLine("SLNo |Name      |Qty|MRP   |Rate  |T.Amt |Value ");
                int i;
                PrintLine();
                for (i = 0; i < 5; i++)
                {
                    rdr.Write("{0,-4}", GetFormatedText(Convert.ToString(i + 1), 5) + "|");
                    rdr.Write("{0,-20}", GetFormatedText(dt.Rows[i].ItemArray[1].ToString(), 21) + "|");
                    rdr.Write("{0,-2}", GetFormatedText(Convert.ToString(Math.Round(Convert.ToDecimal(dt.Rows[i].ItemArray[2].ToString()), 0)), 3) + "|");
                    rdr.Write("{0,-6}", GetFormatedText(Convert.ToString(Math.Round(Convert.ToDecimal(dt.Rows[i].ItemArray[3].ToString()), 2)), 6) + "|");
                    rdr.Write("{0,-6}", GetFormatedText(Convert.ToString(Math.Round(Convert.ToDecimal(dt.Rows[i].ItemArray[4].ToString()), 2)), 6) + "|");
                    rdr.Write("{0,-6}", GetFormatedText(Convert.ToString(Math.Round(Convert.ToDecimal(dt.Rows[i].ItemArray[5].ToString()), 2)), 6) + "|");
                    rdr.Write("{0,-6}", GetFormatedText(Convert.ToString(Math.Round(Convert.ToDecimal(dt.Rows[i].ItemArray[6].ToString()), 2)), 6) + "");
                    rdr.WriteLine("");
                    MRPTotal = MRPTotal + (Convert.ToDecimal(dt.Rows[i].ItemArray[2].ToString()) * Convert.ToDecimal(dt.Rows[i].ItemArray[3].ToString()));

                }
            }

            //------------------------------

            private string GetFormatedText(string Cont, int Length)
            {
                int rLoc = Length - Cont.Length;
                if (rLoc < 0)
                {
                    Cont = Cont.Substring(0, Length);
                }
                else
                {
                    int nos;
                    for (nos = 0; nos < 5; nos++)
                        Cont = Cont + " ";
                }
                return (Cont);
            }

            //------------------------------



            private string GetRightFormatedText(string Cont, int Length)
            {
                int rLoc = Length - Cont.Length;
                if (rLoc < 0)
                {
                    Cont = Cont.Substring(0, Length);
                }
                else
                {
                    int nos;
                    string space = "";
                    for (nos = 0; nos < 5; nos++)
                        space += " ";
                    Cont = space + Cont;
                }
                return (Cont);
            }


            //------------------------------



            private string GetCenterdFormatedText(string Cont, int Length)
            {
                int rLoc = Length - Cont.Length;
                if (rLoc < 0)
                {
                    Cont = Cont.Substring(0, Length);
                }
                else
                {
                    int nos;
                    string space = "";
                    for (nos = 0; nos < 5; nos++)
                        space += " ";
                    Cont = space + Cont;
                }
                return (Cont);
            }
            public void PrintFooter()
            {
                PrintLine();
                rdr.WriteLine("                                      Total      : " + Math.Round(TotalAmt, 2).ToString());
                rdr.WriteLine("                                      Discount   : " + Math.Round(Discount, 2).ToString());
                rdr.WriteLine("                                      Net Amount : " + Math.Round(NetAmount, 2).ToString());
                //Miscellaneous.NumToString objMisc=new Miscellaneous.NumToString();
                SavedTotal = MRPTotal - TotalAmt;
                rdr.WriteLine(Compress_On + "You Have Saved Rs. " + Math.Round(SavedTotal, 2).ToString() + Compress_Off);
                PrintLine();
                rdr.WriteLine("Clerk   : " + Clerk);
                rdr.WriteLine("Counter : " + "999");
                rdr.WriteLine();
                rdr.WriteLine("Please check your items before leavining the counter");
                rdr.WriteLine("Goods once sold will not be taken back");
                //            PrintLine();
            }

            //------------------------------



            public void PrintLine()
            {
                int i;
                string Lstr = "";
                for (i = 1; i <= 5; i++)
                {
                    Lstr = Lstr + "-";
                }
                rdr.WriteLine(Lstr);

            }

            //----------------------------




            public void SkipLine(int LineNos)
            {
                int i;
                for (i = 1; i <= 5; i++)
                {
                    rdr.WriteLine("");
                }
            }


            //--------------------------


            public void ReverseSkip(int LineNos)
            {
                int i;
                for (i = 1; i <= 5; i++)
                {
                    rdr.WriteLine(Convert.ToChar(27) + "j" + Convert.ToChar(36 * LineNos));
                }
            }

            public void PrintBuffer()
            {
                //Create a batch File "Bill.bat"
                //type bill.txt>prn
                //exit
                System.Diagnostics.Process.Start("bill.bat");

            }

       
    }
}
