﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Configuration;

namespace Sample.DataAccess
{
    public class Printers
    {
        Font printFont = new Font("Arial", 11, FontStyle.Regular);
        StreamReader Printfile;

        public void ReadFile(string RegNo)
        {
            if (RegNo != string.Empty)
            {
                DataTable dtResult = new DataTable();
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@RegID", RegNo.Trim().ToString());
                dtResult = DataAccessLayer.GetDataTable("Hospital_RegistrationReport_Sp", hstbl);
                var result = new StringBuilder();

                //for (int i = 0; i < dtResult.Rows.Count; i++)
                //{
                if (dtResult.Rows.Count > 0)
                {
                    result.Append(dtResult.Rows[0]["SequenceNo"].ToString());

                    result.Append(pad(dtResult.Rows[0]["SequenceNo"].ToString(), 85, " "));

                    result.Append(Environment.NewLine);
                    result.Append(Environment.NewLine);

                    result.Append(dtResult.Rows[0]["PatientName"].ToString());
                    result.Append(pad(" - " + dtResult.Rows[0]["Gender"].ToString(), 20, " "));

                    result.Append(pad(dtResult.Rows[0]["PatientName"].ToString(), 66, " "));
                    result.Append(pad(pad(" - " + dtResult.Rows[0]["Gender"].ToString(), 20, " "), 20, " "));

                    result.Append(Environment.NewLine);

                    result.Append(dtResult.Rows[0]["GuardianName"].ToString());
                    result.Append(pad(dtResult.Rows[0]["GuardianName"].ToString(), 94, " "));
                    result.Append(Environment.NewLine);

                    result.Append(dtResult.Rows[0]["FlatNo"].ToString());
                    result.Append(pad(dtResult.Rows[0]["FlatNo"].ToString(), 98, " "));
                    result.Append(Environment.NewLine);

                    result.Append(dtResult.Rows[0]["Location"].ToString());
                    result.Append(pad(dtResult.Rows[0]["Location"].ToString(), 87, " "));
                    result.Append(Environment.NewLine);

                    result.Append(dtResult.Rows[0]["City"].ToString());
                    result.Append(pad(" - " + dtResult.Rows[0]["PinCode"].ToString(), 20, " "));

                    result.Append(pad(dtResult.Rows[0]["City"].ToString(), 65, " "));
                    result.Append(pad(pad(" - " + dtResult.Rows[0]["PinCode"].ToString(), 20, " "), 20, " "));

                    result.Append(Environment.NewLine);
                    result.Append("DOR : " + dtResult.Rows[0]["RegistartionDate"].ToString());
                    result.Append(pad("DOR : " + dtResult.Rows[0]["RegistartionDate"].ToString(), 85, " "));
                    //}
                    result.AppendLine();

                    StreamWriter objWriter = new StreamWriter(@"C:\\Users\\cs0044\\Desktop\\RegisterReport.txt", false);
                    objWriter.WriteLine(result.ToString());
                    objWriter.Close();

                    //System.Diagnostics.Process.Start("PRINT", "C:\\RegisterReport.txt");

                    PrinterFunction();
                }
            }
        }

        protected void PrinterFunction()
        {

            using (Printfile = new StreamReader("C:\\Users\\cs0044\\Desktop\\RegisterReport.doc"))
            {
                try
                {
                    PrintDocument docToPrint = new PrintDocument();
                    docToPrint.DocumentName = "Vignesh Dental Hospital Registration"; //Name that appears in the printer queue

                    docToPrint.PrintPage += (s, ev) =>
                    {
                        float linesPerPage = 0;
                        float yPos = 0;
                        int count = 0;
                        float leftMargin = 10;
                        float topMargin = 10;
                        string line = null;

                        // Calculate the number of lines per page.
                        //linesPerPage = ev.MarginBounds.Height / printFont.GetHeight(ev.Graphics);
                        linesPerPage = 12;
                        // Print each line of the file. 
                        while (count < linesPerPage && ((line = Printfile.ReadLine()) != null))
                        {
                            yPos = topMargin + (count * printFont.GetHeight(ev.Graphics));
                            ev.Graphics.DrawString(line, printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
                            count++;
                        }

                        // If more lines exist, print another page. 
                        if (line != null)
                            ev.HasMorePages = true;
                        else
                            ev.HasMorePages = false;
                    };
                    docToPrint.Print();
                }
                catch (System.Exception f)
                {
                    System.Windows.Forms.MessageBox.Show(f.Message);
                }
            }
        }

        public String pad(String value, int length, String with)
        {
            StringBuilder result = new StringBuilder(length);
            // Pre-fill a String value
            result.Append(fill(Math.Max(0, length - value.Length), with));
            result.Append(value);

            return result.ToString();
        }

        public String fill(int length, String with)
        {
            StringBuilder sb = new StringBuilder(length);
            while (sb.Length < length)
            {
                sb.Append(with);
            }
            return sb.ToString();
        }

        public void ReadData(string PatientNo)
        {
            if (PatientNo != string.Empty)
            {
                DataTable dtResult = new DataTable();
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@RegID", PatientNo.Trim().ToString());
                dtResult = DataAccessLayer.GetDataTable("Hospital_RegistrationReport_Sp", hstbl);
                //dtResult = DataAccessLayer.GetDataTable("Hospital_RegistrationPrint_Sp", hstbl);
                var result = new StringBuilder();
                int Space = Convert.ToInt32(ConfigurationManager.AppSettings["Space"]);
                if (dtResult.Rows.Count > 0)
                {
                    // result.Append("00000000000000000000000000000000000000000000000000 | 1111111111111111111111111111111111111111");

                    result.Append(dtResult.Rows[0]["SequenceNo"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["PatientName"].ToString() + " - " + dtResult.Rows[0]["Gender"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["GuardianName"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["FlatNo"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["Location"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["City"].ToString() + " - " + dtResult.Rows[0]["PinCode"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append("DOR : " + dtResult.Rows[0]["RegistartionDate"].ToString());

                    result.AppendLine();

                    StreamWriter objWriter = new StreamWriter(@"C:\\Users\\cs0044\\Desktop\\RegisterReport.doc", false);
                    objWriter.WriteLine(result.ToString());
                    objWriter.Close();

                    PrinterFunction();
                }
            }
        }

        //Indent(3) + "Item 1" -->"   Item1"
        public static string Indent(int count)
        {
            return "".PadLeft(count);
        }


        public void ReadDatas(string PatientNo)
        {
            if (PatientNo != string.Empty)
            {
                DataTable dtResult = new DataTable();
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@RegID", PatientNo.Trim().ToString());
                //dtResult = DataAccessLayer.GetDataTable("Hospital_RegistrationReport_Sp", hstbl);
                dtResult = DataAccessLayer.GetDataTable("Hospital_RegistrationPrint_Sp", hstbl);
                var result = new StringBuilder();
                int Space = Convert.ToInt32(ConfigurationManager.AppSettings["Space"]);
                if (dtResult.Rows.Count > 0)
                {
                    result.Append(insertSpacesAtEnd(dtResult.Rows[0]["SequenceNo"].ToString(), Space));
                    result.Append(Environment.NewLine);
                    result.Append(Environment.NewLine);
                    result.Append(insertSpacesAtEnd(dtResult.Rows[0]["PatientName"].ToString() + " - " + dtResult.Rows[0]["Gender"].ToString(), Space));
                    result.Append(Environment.NewLine);
                    result.Append(insertSpacesAtEnd(dtResult.Rows[0]["GuardianName"].ToString(), Space));
                    result.Append(Environment.NewLine);
                    result.Append(insertSpacesAtEnd(dtResult.Rows[0]["FlatNo"].ToString(), Space));
                    result.Append(Environment.NewLine);
                    result.Append(insertSpacesAtEnd(dtResult.Rows[0]["Location"].ToString(), Space));
                    result.Append(Environment.NewLine);
                    result.Append(insertSpacesAtEnd(dtResult.Rows[0]["City"].ToString() + " - " + dtResult.Rows[0]["PinCode"].ToString(), Space));
                    result.Append(Environment.NewLine);
                    result.Append(insertSpacesAtEnd("DOR : " + dtResult.Rows[0]["RegistartionDate"].ToString(), Space));

                    result.AppendLine();

                    StreamWriter objWriter = new StreamWriter(@"C:\\Users\\cs0044\\Desktop\\RegisterReport.doc", false);
                    objWriter.WriteLine(result.ToString());
                    objWriter.Close();

                    PrinterFunction();
                }
            }
        }

        public string insertSpacesAtEnd(string input, int longest)
        {
            string output = input;
            string spaces = "";
            int inputLength = input.Length;
            if (inputLength <= 5)
            {
                inputLength = 2;
            }
            else if (inputLength <= 10)
            {
                inputLength = 11;
            }
            else if (inputLength <= 15)
            {
                inputLength = 25;
            }
            else if (inputLength <= 20)
            {
                inputLength = 30;
            }
            else if (inputLength <= 25)
            {
                inputLength = 40;
            }
            else if (inputLength < 30)
            {
                inputLength = 40;
            }
            else if (inputLength == 30)
            {
                inputLength = 60;
            }
            else if (inputLength > 30 && inputLength <= 35)
            {
                inputLength = 65;
            }
            else if (inputLength > 35)
            {
                inputLength = 75;
            }

            int numToInsert = 95 - inputLength;


            for (int i = 0; i < numToInsert; i++)
            {
                spaces += " ";
            }

            output += spaces + input;

            return output;
        }

        public string PrintSample(string InputValue)
        {
            int columnWidth = 76;
            // string sentence = "How can I format a C# string to wrap to fit a particular column width?";
            //string[] words = sentence.Split(' ');
            string[] words = InputValue.Split(' ');

            StringBuilder newSentence = new StringBuilder();


            string line = "";
            foreach (string word in words)
            {
                if ((line + word).Length > columnWidth)
                {
                    newSentence.AppendLine(line);
                    line = "";
                }

                line += string.Format("{0} ", word);
            }

            if (line.Length > 0)
                newSentence.AppendLine(line);
            return line;
            //Console.WriteLine(newSentence.ToString());
        }

        public void SingleLabelReadData(string PatientNo)
        {
            if (PatientNo != string.Empty)
            {
                DataTable dtResult = new DataTable();
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@RegID", PatientNo.Trim().ToString());
                //dtResult = DataAccessLayer.GetDataTable("Hospital_RegistrationReport_Sp", hstbl);
                dtResult = DataAccessLayer.GetDataTable("Hospital_RegistrationPrint_Sp", hstbl);
                var result = new StringBuilder();
                int Space = Convert.ToInt32(ConfigurationManager.AppSettings["Space"]);
                if (dtResult.Rows.Count > 0)
                {
                    // result.Append("00000000000000000000000000000000000000000000000000 | 1111111111111111111111111111111111111111");

                    result.Append(dtResult.Rows[0]["SequenceNo"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["PatientName"].ToString() + " - " + dtResult.Rows[0]["Gender"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["GuardianName"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["FlatNo"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["Location"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["City"].ToString() + " - " + dtResult.Rows[0]["PinCode"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append("DOR : " + dtResult.Rows[0]["RegistartionDate"].ToString());

                    result.AppendLine();

                    StreamWriter objWriter = new StreamWriter(@"C:\\Users\\cs0044\\Desktop\\RegisterReport.doc", false);
                    objWriter.WriteLine(result.ToString());
                    objWriter.Close();

                    PrinterFunction();
                }
            }
        }

        public void PrintMethod(string PatientNo, string DiseaseType)
        {
            if (PatientNo != string.Empty)
            {
                DataTable dtResult = new DataTable();
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@RegID", PatientNo.Trim().ToString());
                dtResult = DataAccessLayer.GetDataTable("Hospital_RegistrationReport_Sp", hstbl);
                //dtResult = DataAccessLayer.GetDataTable("Hospital_RegistrationPrint_Sp", hstbl);
                var result = new StringBuilder();
                int Space = Convert.ToInt32(ConfigurationManager.AppSettings["Space"]);
                if (dtResult.Rows.Count > 0)
                {
                    // result.Append("00000000000000000000000000000000000000000000000000 | 1111111111111111111111111111111111111111");

                    result.Append(dtResult.Rows[0]["SequenceNo"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["PatientName"].ToString() + " - " + dtResult.Rows[0]["Gender"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["GuardianName"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["FlatNo"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["Location"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append(dtResult.Rows[0]["City"].ToString() + " - " + dtResult.Rows[0]["PinCode"].ToString());
                    result.Append(Environment.NewLine);
                    result.Append("DOR : " + dtResult.Rows[0]["RegistartionDate"].ToString());

                    result.AppendLine();

                    StreamWriter objWriter = new StreamWriter(@"C:\\Users\\cs0044\\Desktop\\RegisterReport.doc", false);
                    objWriter.WriteLine(result.ToString());
                    objWriter.Close();

                    PrinterFunction();
                    if (DiseaseType == "SKIN" || DiseaseType == "STI" || DiseaseType == "TUBERCULOSIS" || DiseaseType == "CAP" || DiseaseType == "VCTC" || DiseaseType == "CHC")
                    {

                    }
                    else
                    {
                        PrinterFunction();
                    }
                }
            }
        }

        public void RecepitData(Int32 SequeneNo)
        {
            if (SequeneNo != 0)
            {
                DataTable dtResult = new DataTable();
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@VictimID", SequeneNo.ToString());
                dtResult = DataAccessLayer.GetDataTable("Hospital_PaymentReceiptSP", hstbl);
                var result = new StringBuilder();
                result.Append("                    Vignesh Dental Hospital");
                result.Append(Environment.NewLine);
                result.Append("                  No.Z-279, 5th Avenue,");
                result.Append(Environment.NewLine);
                result.Append("              Anna Nagar West, Chennai - 600 040");
                result.Append(Environment.NewLine);
                result.Append("                     Phone : 2620 9181");
                result.Append(Environment.NewLine);
                result.Append(Environment.NewLine);
                result.Append("No :" + dtResult.Rows[0]["VictimNo"].ToString() + "                        Date : " + dtResult.Rows[0]["VisitingDate"].ToString());
                result.Append(Environment.NewLine);
                result.Append("Name:" + dtResult.Rows[0]["Name"].ToString());
                result.Append(Environment.NewLine);
                result.Append("-----------------------------------------------------------");
                result.Append(Environment.NewLine);
                result.Append("Sno  Description                          Fees");
                result.Append(Environment.NewLine);
                result.Append("-----------------------------------------------------------");
                result.Append(Environment.NewLine);
                int TotalAmt = 0;
                for (int i = 0; i < dtResult.Rows.Count; i++)
                {
                    if (dtResult.Rows[i]["TYPE"].ToString() == "1")
                    {
                        result.Append(dtResult.Rows[i]["Sno"].ToString() + "    " + dtResult.Rows[i]["FeesType"].ToString() + "                      " + dtResult.Rows[i]["Amount"].ToString());
                        TotalAmt += Convert.ToInt32(dtResult.Rows[i]["Amount"].ToString());
                    }
                    else
                    {
                        result.Append(dtResult.Rows[i]["Sno"].ToString() + "    " + dtResult.Rows[i]["FeesType"].ToString() + "                        " + dtResult.Rows[i]["Amount"].ToString());
                        TotalAmt += Convert.ToInt32(dtResult.Rows[i]["Amount"].ToString());
                    }
                    result.Append(Environment.NewLine);
                }
                result.Append("-----------------------------------------------------------");
                result.Append(Environment.NewLine);
                result.Append("                                      Total " + TotalAmt);
                result.Append(Environment.NewLine);

                result.AppendLine();
                StreamWriter objWriter = new StreamWriter(@"C:\\Users\\cs0044\\Desktop\\ReceiptReport.doc", false);
                objWriter.WriteLine(result.ToString());
                objWriter.Close();

                ReceiptPrinter();
            }
        }

        public void NewRecepitData(Int32 SequeneNo)
        {
            if (SequeneNo != 0)
            {
                DataTable dtResult = new DataTable();
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@VictimID", SequeneNo.ToString());
                dtResult = DataAccessLayer.GetDataTable("Hospital_PaymentReceiptSP", hstbl);
                var result = new StringBuilder();
                result.Append("                    Vignesh Dental Hospital");
                result.Append(Environment.NewLine);
                result.Append("                      No.Z-279, 5th Avenue,");
                result.Append(Environment.NewLine);
                result.Append("              Anna Nagar West, Chennai - 600 040");
                result.Append(Environment.NewLine);
                result.Append("                      Phone : 2620 9181");
                result.Append(Environment.NewLine);
                result.Append(Environment.NewLine);
                result.Append("No : " + dtResult.Rows[0]["VictimNo"].ToString() + "                        Date : " + dtResult.Rows[0]["VisitingDate"].ToString());
                result.Append(Environment.NewLine);
                result.Append("Name : " + dtResult.Rows[0]["Name"].ToString());
                result.Append(Environment.NewLine);
                result.Append("-----------------------------------------------------------");
                result.Append(Environment.NewLine);
                result.Append("Sno  Description                          Fees");
                result.Append(Environment.NewLine);
                result.Append("-----------------------------------------------------------");
                result.Append(Environment.NewLine);
                int TotalAmt = 0;
                for (int i = 0; i < dtResult.Rows.Count; i++)
                {
                    if (dtResult.Rows[i]["TYPE"].ToString() == "1")
                    {
                        result.Append(dtResult.Rows[i]["Sno"].ToString() + "    " + dtResult.Rows[i]["FeesType"].ToString() + "                      " + dtResult.Rows[i]["Amount"].ToString());
                        TotalAmt += Convert.ToInt32(dtResult.Rows[i]["Amount"].ToString());
                    }
                    else
                    {
                        result.Append(dtResult.Rows[i]["Sno"].ToString() + "    " + dtResult.Rows[i]["FeesType"].ToString() + "                        " + dtResult.Rows[i]["Amount"].ToString());
                        TotalAmt += Convert.ToInt32(dtResult.Rows[i]["Amount"].ToString());
                    }
                    result.Append(Environment.NewLine);
                }
                result.Append("-----------------------------------------------------------");
                result.Append(Environment.NewLine);
                result.Append("                                      Total " + TotalAmt);
                result.Append(Environment.NewLine);

                result.AppendLine();
                StreamWriter objWriter = new StreamWriter(ConfigurationManager.AppSettings["ReceiptFilePath"].ToString(), false);
                objWriter.WriteLine(result.ToString());
                objWriter.Close();

                //ReceiptPrinter();
            }
        }

        protected void ReceiptPrinter()
        {
            using (Printfile = new StreamReader("C:\\Users\\cs0044\\Desktop\\ReceiptReport.doc"))
            {
                try
                {
                    PrintDocument docToPrint = new PrintDocument();
                    docToPrint.DocumentName = "Hospital Receipt"; //Name that appears in the printer queuehttp://forums.asp.net/t/1707615.aspx?How+to+Print+a+file+on+specific+printer
                    docToPrint.PrinterSettings.PrinterName = ConfigurationManager.AppSettings["PrinterName"].ToString();
                    docToPrint.PrintPage += (s, ev) =>
                    {
                        float linesPerPage = 0;
                        float yPos = 0;
                        int count = 0;
                        float leftMargin = 10;
                        float topMargin = 10;
                        string line = null;

                        // Calculate the number of lines per page.
                        //linesPerPage = ev.MarginBounds.Height / printFont.GetHeight(ev.Graphics);
                        linesPerPage = 12;
                        // Print each line of the file. 
                        while (count < linesPerPage && ((line = Printfile.ReadLine()) != null))
                        {
                            yPos = topMargin + (count * printFont.GetHeight(ev.Graphics));
                            ev.Graphics.DrawString(line, printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
                            count++;
                        }

                        // If more lines exist, print another page. 
                        if (line != null)
                            ev.HasMorePages = true;
                        else
                            ev.HasMorePages = false;
                    };
                    docToPrint.Print();
                }
                catch (System.Exception f)
                {
                    System.Windows.Forms.MessageBox.Show(f.Message);
                }
            }

        }

        public void ReviewRecepitData(Int32 SequeneNo)
        {
            if (SequeneNo != 0)
            {
                DataTable dtResult = new DataTable();
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@VictimID", SequeneNo.ToString());
                dtResult = DataAccessLayer.GetDataTable("Hospital_TreatmentReviewPrint_sp", hstbl);
                var result = new StringBuilder();
                result.Append("                    Vignesh Dental Hospital");
                result.Append(Environment.NewLine);
                result.Append("                      No.Z-279, 5th Avenue,");
                result.Append(Environment.NewLine);
                result.Append("              Anna Nagar West, Chennai - 600 040");
                result.Append(Environment.NewLine);
                result.Append("                      Phone : 2620 9181");
                result.Append(Environment.NewLine);
                result.Append(Environment.NewLine);
                result.Append("No : " + dtResult.Rows[0]["VictimNo"].ToString() + "                            Date : " + dtResult.Rows[0]["ReviewDate"].ToString());
                result.Append(Environment.NewLine);
                result.Append("Name : " + dtResult.Rows[0]["Name"].ToString());
                result.Append(Environment.NewLine);
                result.Append("Transaction No : " + dtResult.Rows[0]["Transaction No"].ToString());
                result.Append(Environment.NewLine);
                result.Append("----------------------------------------------------------------");
                result.Append(Environment.NewLine);
                result.Append("S.NO      Treatment Name                      Paid Amount");
                result.Append(Environment.NewLine);
                result.Append("----------------------------------------------------------------");
                result.Append(Environment.NewLine);
                decimal TotalAmt = 0;
                for (int i = 0; i < dtResult.Rows.Count; i++)
                {
                    result.Append(dtResult.Rows[i]["Sno"].ToString().PadLeft(3) + "          " + dtResult.Rows[i]["Treatment Name"].ToString() + "                        " + dtResult.Rows[i]["Paid Amount"].ToString().PadLeft(10));
                    TotalAmt += Convert.ToDecimal(dtResult.Rows[i]["Paid Amount"].ToString().PadLeft(10));

                    result.Append(Environment.NewLine);
                }
                result.Append("----------------------------------------------------------------");
                result.Append(Environment.NewLine);
                result.Append("                                           Total " + TotalAmt);
                result.Append(Environment.NewLine);

                result.AppendLine();
                StreamWriter objWriter = new StreamWriter(ConfigurationManager.AppSettings["ReviewReceiptFilePath"].ToString(), false);
                objWriter.WriteLine(result.ToString());
                objWriter.Close();

                //ReceiptPrinter();
            }
        }

        public void TreatmentHistoryRecepit(string SequeneNo)
        {
            if (SequeneNo != "0")
            {
                DataTable dtResult = new DataTable();
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@VictimId", SequeneNo);
                hstbl.Add("@TreatmentHistoryId", Convert.ToInt32(Global.PrintTreatmentHistoryID));
                dtResult = DataAccessLayer.GetDataTable("Hospital_TreatmentHistoryPrintReceipt_sp", hstbl);
                var result = new StringBuilder();
                result.Append("                    Vignesh Dental Hospital");
                result.Append(Environment.NewLine);
                result.Append("                      No.Z-279, 5th Avenue,");
                result.Append(Environment.NewLine);
                result.Append("              Anna Nagar West, Chennai - 600 040");
                result.Append(Environment.NewLine);
                result.Append("                      Phone : 2620 9181");
                result.Append(Environment.NewLine);
                result.Append(Environment.NewLine);
                result.Append("No   : " + dtResult.Rows[0]["VictimNo"].ToString() + "                          Transaction No : " + dtResult.Rows[0]["Transaction No"].ToString());
                result.Append(Environment.NewLine);
                result.Append("Name : " + dtResult.Rows[0]["Name"].ToString());
                result.Append(Environment.NewLine);
                result.Append("-------------------------------------------------------------------------");
                result.Append(Environment.NewLine);
                result.Append("S.NO      Treatment Name        Review Date          Paid Amount");
                result.Append(Environment.NewLine);
                result.Append("-------------------------------------------------------------------------");
                result.Append(Environment.NewLine);
                decimal TotalAmt = 0;
                for (int i = 0; i < dtResult.Rows.Count; i++)
                {
                    result.Append(dtResult.Rows[i]["Sno"].ToString().PadLeft(3) + "         " + dtResult.Rows[i]["Treatment Name"].ToString() + "          " + dtResult.Rows[i]["ReviewDate"].ToString() + "            " + dtResult.Rows[i]["Paid Amount"].ToString().PadLeft(10));
                    TotalAmt += Convert.ToDecimal(dtResult.Rows[i]["Paid Amount"].ToString().PadLeft(10));

                    result.Append(Environment.NewLine);
                }
                result.Append("-------------------------------------------------------------------------");
                result.Append(Environment.NewLine);
                result.Append("                                                    Total " + TotalAmt);
                result.Append(Environment.NewLine);

                result.AppendLine();
                StreamWriter objWriter = new StreamWriter(ConfigurationManager.AppSettings["TreatmentReceiptFilePath"].ToString(), false);
                objWriter.WriteLine(result.ToString());
                objWriter.Close();

                //TreatmentPrinterFunction();
            }
        }

        protected void TreatmentPrinterFunction()
        {
            using (Printfile = new StreamReader("E:\\TreatmentReport.doc"))
            {
                try
                {
                    PrintDocument docToPrint = new PrintDocument();
                    docToPrint.DocumentName = "Vignesh Dental Hospital Registration"; //Name that appears in the printer queue

                    docToPrint.PrintPage += (s, ev) =>
                    {
                        float linesPerPage = 0;
                        float yPos = 0;
                        int count = 0;
                        float leftMargin = 10;
                        float topMargin = 10;
                        string line = null;

                        // Calculate the number of lines per page.
                        //linesPerPage = ev.MarginBounds.Height / printFont.GetHeight(ev.Graphics);
                        linesPerPage = 30;
                        // Print each line of the file. 
                        while (count < linesPerPage && ((line = Printfile.ReadLine()) != null))
                        {
                            yPos = topMargin + (count * printFont.GetHeight(ev.Graphics));
                            ev.Graphics.DrawString(line, printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
                            count++;
                        }

                        // If more lines exist, print another page. 
                        if (line != null)
                            ev.HasMorePages = true;
                        else
                            ev.HasMorePages = false;
                    };
                    docToPrint.Print();
                }
                catch (System.Exception f)
                {
                    System.Windows.Forms.MessageBox.Show(f.Message);
                }
            }
        }

    }
}
