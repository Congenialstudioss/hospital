﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MSWord = Microsoft.Office.Interop.Word;
using Microsoft.Office.Interop.Word;
using Application = Microsoft.Office.Interop.Word.Application;
using DataTable = System.Data.DataTable;
using Document = Microsoft.Office.Interop.Word.Document;
using Microsoft.Office;

namespace Sample.DataAccess
{
    class WordPrinter
    {
object objMiss = System.Reflection.Missing.Value;
 public void CreateMsWord() 

        { 

            try 

            { 

                MSWord.Application msWord = new MSWord.Application(); 

                MSWord.Document doc;

 

                msWord.Visible = true; 

                doc = msWord.Documents.Add(ref objMiss, ref objMiss, ref objMiss, ref objMiss);
                doc.PageSetup.TextColumns.SetCount(2);
                AddContentToMSWord(doc); 

            } 

            catch (Exception ex) 

            { 

                throw ex; 

            } 

        }

public void AddContentToMSWord(MSWord.Document doc) 

        { 

            MSWord.Paragraph paragraph; 

            paragraph = doc.Content.Paragraphs.Add(ref objMiss); 

            //object styleHeading = "Heading 1"; 

            //paragraph.Range.set_Style(ref styleHeading); 

            paragraph.Range.Text = "This is the Microsoft Word documnet created in C# With the help of COM library Microsoft.Office.Interop.Word"; 

            paragraph.Range.Font.Size = 10; 

            paragraph.Range.Font.Bold = 1; 

        }

public void MethodNew()
{
var wordApp = new Application { Visible = false };
            object objMissing =System.Reflection.Missing.Value;
            Document wordDoc = wordApp.Documents.Add(ref objMissing, ref objMissing, ref objMissing, ref objMissing);

            wordApp.ActiveWindow.ActivePane.View.SeekView = WdSeekView.wdSeekCurrentPageFooter;
            wordApp.Selection.TypeParagraph();
            String docNumber = "1";
            String revisionNumber = "0";
            wordApp.Selection.Paragraphs.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
            wordApp.ActiveWindow.Selection.Font.Name = "Arial";
            wordApp.ActiveWindow.Selection.Font.Size = 8;
            wordApp.ActiveWindow.Selection.TypeText("Document #: " + docNumber + " - Revision #: " + revisionNumber);
            wordApp.ActiveWindow.Selection.TypeText("\t");
            wordApp.ActiveWindow.Selection.TypeText("\t");
            wordApp.ActiveWindow.Selection.TypeText("Page ");
            Object CurrentPage = WdFieldType.wdFieldPage;
            wordApp.ActiveWindow.Selection.Fields.Add(wordApp.Selection.Range, ref CurrentPage, ref objMissing, ref objMissing);
            wordApp.ActiveWindow.Selection.TypeText(" of ");
            Object TotalPages = WdFieldType.wdFieldNumPages;
            wordApp.ActiveWindow.Selection.Fields.Add(wordApp.Selection.Range, ref TotalPages, ref objMissing, ref objMissing);
            wordApp.ActiveWindow.ActivePane.View.SeekView = WdSeekView.wdSeekMainDocument;

            object c = "C:\\1.doc";
            wordDoc.Paragraphs.LineSpacing = 8;

            Paragraph wp = wordDoc.Paragraphs.Add(ref objMissing);
            //wp.Range.Text += richTextBox1.Text;

            wordDoc.SaveAs(ref c, ref objMissing, ref objMissing, ref objMissing, ref objMissing, ref objMissing,
               ref objMissing
               , ref objMissing, ref objMissing, ref objMissing, ref objMissing, ref objMissing,
               ref objMissing, ref objMissing
               , ref objMissing, ref objMissing);
            (wordDoc).Close(ref objMissing, ref objMissing, ref objMissing);
            (wordApp).Quit(ref objMissing, ref objMissing, ref objMissing);
}
    }


}
