﻿namespace Sample
{
    partial class HospitalRegisterReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.Gremlates_RegistrationReport_SpBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.GremaltesRegisterDataSet = new Sample.GremaltesRegisterDataSet();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btn_Search = new System.Windows.Forms.Button();
            this.RegisterTo = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.RegisterFrom = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.Txt_regno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.Gremlates_RegistrationReport_SpTableAdapter = new Sample.GremaltesRegisterDataSetTableAdapters.Gremlates_RegistrationReport_SpTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.Gremlates_RegistrationReport_SpBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GremaltesRegisterDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Gremlates_RegistrationReport_SpBindingSource
            // 
            this.Gremlates_RegistrationReport_SpBindingSource.DataMember = "Gremlates_RegistrationReport_Sp";
            this.Gremlates_RegistrationReport_SpBindingSource.DataSource = this.GremaltesRegisterDataSet;
            // 
            // GremaltesRegisterDataSet
            // 
            this.GremaltesRegisterDataSet.DataSetName = "GremaltesRegisterDataSet";
            this.GremaltesRegisterDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Btn_Search);
            this.groupBox1.Controls.Add(this.RegisterTo);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.RegisterFrom);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Txt_regno);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(729, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // Btn_Search
            // 
            this.Btn_Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Search.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Btn_Search.Location = new System.Drawing.Point(420, 60);
            this.Btn_Search.Name = "Btn_Search";
            this.Btn_Search.Size = new System.Drawing.Size(75, 23);
            this.Btn_Search.TabIndex = 4;
            this.Btn_Search.Text = "Search";
            this.Btn_Search.UseVisualStyleBackColor = true;
            this.Btn_Search.Click += new System.EventHandler(this.Btn_Search_Click);
            // 
            // RegisterTo
            // 
            this.RegisterTo.Location = new System.Drawing.Point(541, 24);
            this.RegisterTo.Name = "RegisterTo";
            this.RegisterTo.Size = new System.Drawing.Size(178, 20);
            this.RegisterTo.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(501, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "To";
            // 
            // RegisterFrom
            // 
            this.RegisterFrom.Location = new System.Drawing.Point(320, 24);
            this.RegisterFrom.Name = "RegisterFrom";
            this.RegisterFrom.Size = new System.Drawing.Size(175, 20);
            this.RegisterFrom.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(267, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "From";
            // 
            // Txt_regno
            // 
            this.Txt_regno.Location = new System.Drawing.Point(84, 24);
            this.Txt_regno.MaxLength = 15;
            this.Txt_regno.Name = "Txt_regno";
            this.Txt_regno.Size = new System.Drawing.Size(168, 20);
            this.Txt_regno.TabIndex = 1;
            this.Txt_regno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontactno_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(22, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Victim No";
            // 
            // reportViewer1
            // 
            this.reportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.Gremlates_RegistrationReport_SpBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Sample.RegReport.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(12, 131);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(729, 242);
            this.reportViewer1.TabIndex = 1;
            // 
            // Gremlates_RegistrationReport_SpTableAdapter
            // 
            this.Gremlates_RegistrationReport_SpTableAdapter.ClearBeforeFill = true;
            // 
            // HospitalRegisterReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 385);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "HospitalRegisterReport";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Victim Register Report";
            this.Load += new System.EventHandler(this.HospitalRegisterReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Gremlates_RegistrationReport_SpBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GremaltesRegisterDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btn_Search;
        private System.Windows.Forms.DateTimePicker RegisterTo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker RegisterFrom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Txt_regno;
        private System.Windows.Forms.Label label1;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource Gremlates_RegistrationReport_SpBindingSource;
        private GremaltesRegisterDataSet GremaltesRegisterDataSet;
        private GremaltesRegisterDataSetTableAdapters.Gremlates_RegistrationReport_SpTableAdapter Gremlates_RegistrationReport_SpTableAdapter;
    }
}