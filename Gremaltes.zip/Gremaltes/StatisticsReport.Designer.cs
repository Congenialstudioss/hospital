﻿using System.Windows.Forms;
namespace Sample
{
    partial class StatisticsReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.Gremaltes_StatisticsReports_SPBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Gremaltes_StaticisReport = new Sample.Gremaltes_StaticisReport();
            this.lblType = new System.Windows.Forms.Label();
            this.grpReport = new System.Windows.Forms.GroupBox();
            this.btnExport = new System.Windows.Forms.Button();
            this.dtTo = new System.Windows.Forms.DateTimePicker();
            this.lblRegDateTo = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblRegisterDatefrom = new System.Windows.Forms.Label();
            this.dtFrom = new System.Windows.Forms.DateTimePicker();
            this.btnSearch = new System.Windows.Forms.Button();
            this.ddlPatientType = new System.Windows.Forms.ComboBox();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.Gremaltes_StatisticsReports_SPTableAdapter = new Sample.Gremaltes_StaticisReportTableAdapters.Gremaltes_StatisticsReports_SPTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.Gremaltes_StatisticsReports_SPBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Gremaltes_StaticisReport)).BeginInit();
            this.grpReport.SuspendLayout();
            this.SuspendLayout();
            // 
            // Gremaltes_StatisticsReports_SPBindingSource
            // 
            this.Gremaltes_StatisticsReports_SPBindingSource.DataMember = "Gremaltes_StatisticsReports_SP";
            this.Gremaltes_StatisticsReports_SPBindingSource.DataSource = this.Gremaltes_StaticisReport;
            // 
            // Gremaltes_StaticisReport
            // 
            this.Gremaltes_StaticisReport.DataSetName = "Gremaltes_StaticisReport";
            this.Gremaltes_StaticisReport.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(16, 14);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(31, 13);
            this.lblType.TabIndex = 3;
            this.lblType.Text = "Type";
            // 
            // grpReport
            // 
            this.grpReport.Controls.Add(this.btnExport);
            this.grpReport.Controls.Add(this.dtTo);
            this.grpReport.Controls.Add(this.lblRegDateTo);
            this.grpReport.Controls.Add(this.btnClose);
            this.grpReport.Controls.Add(this.lblRegisterDatefrom);
            this.grpReport.Controls.Add(this.dtFrom);
            this.grpReport.Controls.Add(this.btnSearch);
            this.grpReport.Controls.Add(this.lblType);
            this.grpReport.Controls.Add(this.ddlPatientType);
            this.grpReport.Location = new System.Drawing.Point(12, 2);
            this.grpReport.Name = "grpReport";
            this.grpReport.Size = new System.Drawing.Size(758, 93);
            this.grpReport.TabIndex = 1;
            this.grpReport.TabStop = false;
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(475, 62);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 23);
            this.btnExport.TabIndex = 7;
            this.btnExport.Text = "Export";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // dtTo
            // 
            this.dtTo.Location = new System.Drawing.Point(568, 38);
            this.dtTo.Name = "dtTo";
            this.dtTo.Size = new System.Drawing.Size(184, 20);
            this.dtTo.TabIndex = 1;
            // 
            // lblRegDateTo
            // 
            this.lblRegDateTo.AutoSize = true;
            this.lblRegDateTo.Location = new System.Drawing.Point(514, 42);
            this.lblRegDateTo.Name = "lblRegDateTo";
            this.lblRegDateTo.Size = new System.Drawing.Size(20, 13);
            this.lblRegDateTo.TabIndex = 3;
            this.lblRegDateTo.Text = "To";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(393, 62);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblRegisterDatefrom
            // 
            this.lblRegisterDatefrom.AutoSize = true;
            this.lblRegisterDatefrom.Location = new System.Drawing.Point(17, 42);
            this.lblRegisterDatefrom.Name = "lblRegisterDatefrom";
            this.lblRegisterDatefrom.Size = new System.Drawing.Size(30, 13);
            this.lblRegisterDatefrom.TabIndex = 2;
            this.lblRegisterDatefrom.Text = "From";
            // 
            // dtFrom
            // 
            this.dtFrom.Location = new System.Drawing.Point(106, 38);
            this.dtFrom.Name = "dtFrom";
            this.dtFrom.Size = new System.Drawing.Size(192, 20);
            this.dtFrom.TabIndex = 0;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(312, 62);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // ddlPatientType
            // 
            this.ddlPatientType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPatientType.FormattingEnabled = true;
            this.ddlPatientType.Location = new System.Drawing.Point(106, 11);
            this.ddlPatientType.Name = "ddlPatientType";
            this.ddlPatientType.Size = new System.Drawing.Size(192, 21);
            this.ddlPatientType.TabIndex = 0;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "dsReports";
            reportDataSource1.Value = this.Gremaltes_StatisticsReports_SPBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Sample.StaticisReports.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(14, 101);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(757, 338);
            this.reportViewer1.TabIndex = 2;
            // 
            // Gremaltes_StatisticsReports_SPTableAdapter
            // 
            this.Gremaltes_StatisticsReports_SPTableAdapter.ClearBeforeFill = true;
            // 
            // StatisticsReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 448);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.grpReport);
            this.Name = "StatisticsReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Statistics Report";
            this.Load += new System.EventHandler(this.StatisticsReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Gremaltes_StatisticsReports_SPBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Gremaltes_StaticisReport)).EndInit();
            this.grpReport.ResumeLayout(false);
            this.grpReport.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.GroupBox grpReport;
        private System.Windows.Forms.DateTimePicker dtTo;
        private System.Windows.Forms.Label lblRegDateTo;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblRegisterDatefrom;
        private System.Windows.Forms.DateTimePicker dtFrom;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ComboBox ddlPatientType;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private Button btnExport;
        private BindingSource Gremaltes_StatisticsReports_SPBindingSource;
        private Gremaltes_StaticisReport Gremaltes_StaticisReport;
        private Gremaltes_StaticisReportTableAdapters.Gremaltes_StatisticsReports_SPTableAdapter Gremaltes_StatisticsReports_SPTableAdapter;
    }
}