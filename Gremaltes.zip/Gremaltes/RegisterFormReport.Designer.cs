﻿namespace Sample
{
    partial class RegisterFormReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.Gremlates_RegistrationReport_SpBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.GremaltesRegisterDataSet = new Sample.GremaltesRegisterDataSet();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.Gremlates_RegistrationReport_SpTableAdapter = new Sample.GremaltesRegisterDataSetTableAdapters.Gremlates_RegistrationReport_SpTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.Gremlates_RegistrationReport_SpBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GremaltesRegisterDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // Gremlates_RegistrationReport_SpBindingSource
            // 
            this.Gremlates_RegistrationReport_SpBindingSource.DataMember = "Gremlates_RegistrationReport_Sp";
            this.Gremlates_RegistrationReport_SpBindingSource.DataSource = this.GremaltesRegisterDataSet;
            // 
            // GremaltesRegisterDataSet
            // 
            this.GremaltesRegisterDataSet.DataSetName = "GremaltesRegisterDataSet";
            this.GremaltesRegisterDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "dsRegisterReport";
            reportDataSource1.Value = this.Gremlates_RegistrationReport_SpBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.DisplayName = "Registration Report";
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Sample.RegisterReports.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ShowDocumentMapButton = false;
            this.reportViewer1.ShowFindControls = false;
            this.reportViewer1.ShowPageNavigationControls = false;
            this.reportViewer1.ShowPromptAreaButton = false;
            this.reportViewer1.ShowStopButton = false;
            this.reportViewer1.ShowZoomControl = false;
            this.reportViewer1.Size = new System.Drawing.Size(794, 199);
            this.reportViewer1.TabIndex = 0;
            // 
            // Gremlates_RegistrationReport_SpTableAdapter
            // 
            this.Gremlates_RegistrationReport_SpTableAdapter.ClearBeforeFill = true;
            // 
            // RegisterFormReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 201);
            this.Controls.Add(this.reportViewer1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RegisterFormReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "RegisterFormReport";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.RegisterFormReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Gremlates_RegistrationReport_SpBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GremaltesRegisterDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource Gremlates_RegistrationReport_SpBindingSource;
        private GremaltesRegisterDataSet GremaltesRegisterDataSet;
        private GremaltesRegisterDataSetTableAdapters.Gremlates_RegistrationReport_SpTableAdapter Gremlates_RegistrationReport_SpTableAdapter;
    }
}