﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApplication3;

namespace Sample
{
    public partial class UserSearch : Form
    {
        public UserSearch()
        {
            InitializeComponent();
            btnsearch.Enabled = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtsearch.Text != String.Empty)
                {
                    DisplayRecord();
                    txtsearch.Text = String.Empty;
                }
                else
                {
                    MessageBox.Show("Please Enter VictimNo or ContactNo", "Victim Search - Error");
                    btnsearch.Enabled = false;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        protected void DisplayRecord()
        {
            try
            {
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@pi_RegisterID", txtsearch.Text.Trim());
                DataTable dtLoad = DataAccessLayer.GetDataTable("Hospital_User_Fetch_Sp", hstbl);
                if (dtLoad.Rows.Count > 0)
                {
                    string RegId = dtLoad.Rows[0].ItemArray[0].ToString();
                    this.Close();
                    TreatmentHistory t = new TreatmentHistory();
                    t.usersearchbind(RegId);
                    t.ShowDialog();
                }
                else
                {
                    RegisterForm r = new RegisterForm();
                    r.ShowDialog();
                    this.Visible = false;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void txtsearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            if (txtsearch.Text != String.Empty)
            {
                if (txtsearch.TextLength >= 10)
                {
                    btnsearch.Enabled = true;
                }
            }
            else
            {
                btnsearch.Enabled = false;
            }
        }

        private void txtsearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnsearch.PerformClick();
            }
        }
    }
}
