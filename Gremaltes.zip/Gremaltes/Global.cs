﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sample
{
    public static class Global
    {
        public static string UserID { get; set; }
        public static string UserName { get; set; }
        public static string RegID { get; set; }
        public static string UserSearchId { get; set; }
        public static string New { get; set; }
        public static string TreatmentHistoryID { get; set; }
        public static string TreatmentNo { get; set; }
        public static string TreatmentName { get; set; }
        public static string Discount { get; set; }
        public static string PrintTreatmentHistoryID { get; set; }
        public static string NotificationCount { get; set; }

    }
}
