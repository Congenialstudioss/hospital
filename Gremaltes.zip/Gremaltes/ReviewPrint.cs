﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class ReviewPrint : Form
    {
        public ReviewPrint()
        {
            InitializeComponent();
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern long BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);
        private Bitmap memoryImage;

        private void ReviewPrintScreen()
        {
            Graphics mygraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, mygraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            IntPtr dc1 = mygraphics.GetHdc();
            IntPtr dc2 = memoryGraphics.GetHdc();
            BitBlt(dc2, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height, dc1, 0, 0, 13369376);
            mygraphics.ReleaseHdc(dc1);
            memoryGraphics.ReleaseHdc(dc2);
        }

        private void ReviewPrintdoc_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }

        public void ReviewRecepitData(Int32 SequeneNo)
        {
            if (SequeneNo != 0)
            {
                DataTable dtResult = new DataTable();
                Hashtable hstbl = new Hashtable();
                hstbl.Add("@VictimID", SequeneNo.ToString());
                dtResult = DataAccessLayer.GetDataTable("Hospital_TreatmentReviewPrint_sp", hstbl);

                txtno.Text = dtResult.Rows[0]["VictimNo"].ToString();
                txtname.Text = dtResult.Rows[0]["Name"].ToString();
                txtdate.Text = dtResult.Rows[0]["ReviewDate"].ToString();
                lbltransaction.Text = dtResult.Rows[0]["Transaction No"].ToString();

                decimal TotalAmt = 0;
                for (int i = 0; i < dtResult.Rows.Count; i++)
                {
                    lblno.Text = dtResult.Rows[i]["Sno"].ToString();
                    lbltreatmentname.Text = dtResult.Rows[i]["Treatment Name"].ToString();
                    lblpaidamnt.Text = dtResult.Rows[i]["Paid Amount"].ToString();
                    TotalAmt += Convert.ToDecimal(dtResult.Rows[i]["Paid Amount"].ToString());
                    lbltotal.Text = TotalAmt.ToString();
                }
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            btnPrint.Visible = false;
            ReviewPrintScreen();
            this.Close();
            ReviewPreviewDialog.ShowDialog();
        }

    }
}
