﻿using System.Windows.Forms;
namespace WindowsFormsApplication3
{
    partial class ReviewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtptransdate = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.txtregid = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtchequedate = new System.Windows.Forms.DateTimePicker();
            this.txtchequeno = new System.Windows.Forms.TextBox();
            this.txtbankname = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblchqno = new System.Windows.Forms.Label();
            this.ddlpayment = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.lbltreatmentno = new System.Windows.Forms.Label();
            this.txtreatmentno = new System.Windows.Forms.TextBox();
            this.lbldiscount = new System.Windows.Forms.Label();
            this.lbldiscountamount = new System.Windows.Forms.Label();
            this.chkdiscount = new System.Windows.Forms.CheckBox();
            this.txtdiscount = new System.Windows.Forms.TextBox();
            this.txtpaidedamount = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Txt_TreatmentFee = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.ddltreatment = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbdoctor = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtpaidamount = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dtreviewdate = new System.Windows.Forms.DateTimePicker();
            this.txtremarks = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.combosex = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtguardian = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtpatient = new System.Windows.Forms.TextBox();
            this.cbosubtitle = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.PatientDetails = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PatientDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSave.Location = new System.Drawing.Point(319, 548);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 21;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtptransdate);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtregid);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(15, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(722, 57);
            this.groupBox1.TabIndex = 66;
            this.groupBox1.TabStop = false;
            // 
            // dtptransdate
            // 
            this.dtptransdate.Enabled = false;
            this.dtptransdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtptransdate.Location = new System.Drawing.Point(577, 18);
            this.dtptransdate.Name = "dtptransdate";
            this.dtptransdate.Size = new System.Drawing.Size(120, 20);
            this.dtptransdate.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(472, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "Review Date";
            // 
            // txtregid
            // 
            this.txtregid.Location = new System.Drawing.Point(105, 21);
            this.txtregid.Name = "txtregid";
            this.txtregid.ReadOnly = true;
            this.txtregid.Size = new System.Drawing.Size(218, 20);
            this.txtregid.TabIndex = 23;
            this.txtregid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtage_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(24, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "Victim No";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtchequedate);
            this.groupBox2.Controls.Add(this.txtchequeno);
            this.groupBox2.Controls.Add(this.txtbankname);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.lblchqno);
            this.groupBox2.Controls.Add(this.ddlpayment);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.lbltreatmentno);
            this.groupBox2.Controls.Add(this.txtreatmentno);
            this.groupBox2.Controls.Add(this.lbldiscount);
            this.groupBox2.Controls.Add(this.lbldiscountamount);
            this.groupBox2.Controls.Add(this.chkdiscount);
            this.groupBox2.Controls.Add(this.txtdiscount);
            this.groupBox2.Controls.Add(this.txtpaidedamount);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.Txt_TreatmentFee);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.ddltreatment);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.cmbdoctor);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtpaidamount);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.dtreviewdate);
            this.groupBox2.Controls.Add(this.txtremarks);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.combosex);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txtguardian);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtage);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtpatient);
            this.groupBox2.Controls.Add(this.cbosubtitle);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(15, 70);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(722, 288);
            this.groupBox2.TabIndex = 67;
            this.groupBox2.TabStop = false;
            // 
            // dtchequedate
            // 
            this.dtchequedate.Enabled = false;
            this.dtchequedate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtchequedate.Location = new System.Drawing.Point(162, 245);
            this.dtchequedate.Name = "dtchequedate";
            this.dtchequedate.Size = new System.Drawing.Size(120, 20);
            this.dtchequedate.TabIndex = 19;
            // 
            // txtchequeno
            // 
            this.txtchequeno.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtchequeno.Enabled = false;
            this.txtchequeno.Location = new System.Drawing.Point(415, 219);
            this.txtchequeno.MaxLength = 24;
            this.txtchequeno.Name = "txtchequeno";
            this.txtchequeno.Size = new System.Drawing.Size(282, 20);
            this.txtchequeno.TabIndex = 18;
            // 
            // txtbankname
            // 
            this.txtbankname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbankname.Enabled = false;
            this.txtbankname.Location = new System.Drawing.Point(415, 245);
            this.txtbankname.MaxLength = 30;
            this.txtbankname.Name = "txtbankname";
            this.txtbankname.Size = new System.Drawing.Size(282, 20);
            this.txtbankname.TabIndex = 20;
            this.txtbankname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpatient_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label17.Location = new System.Drawing.Point(301, 248);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 13);
            this.label17.TabIndex = 64;
            this.label17.Text = "Bank Name";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label16.Location = new System.Drawing.Point(12, 251);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(81, 13);
            this.label16.TabIndex = 63;
            this.label16.Text = "Cheque Date";
            // 
            // lblchqno
            // 
            this.lblchqno.AutoSize = true;
            this.lblchqno.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblchqno.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblchqno.Location = new System.Drawing.Point(301, 222);
            this.lblchqno.Name = "lblchqno";
            this.lblchqno.Size = new System.Drawing.Size(102, 13);
            this.lblchqno.TabIndex = 62;
            this.lblchqno.Text = "Cheque/Card No";
            // 
            // ddlpayment
            // 
            this.ddlpayment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlpayment.FormattingEnabled = true;
            this.ddlpayment.Items.AddRange(new object[] {
            "Cash",
            "Cheque",
            "Credit/Debit Card"});
            this.ddlpayment.Location = new System.Drawing.Point(162, 218);
            this.ddlpayment.Name = "ddlpayment";
            this.ddlpayment.Size = new System.Drawing.Size(121, 21);
            this.ddlpayment.TabIndex = 17;
            this.ddlpayment.SelectedIndexChanged += new System.EventHandler(this.ddlpayment_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label14.Location = new System.Drawing.Point(12, 222);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 24);
            this.label14.TabIndex = 0;
            this.label14.Text = "Payment Mode";
            // 
            // lbltreatmentno
            // 
            this.lbltreatmentno.AutoSize = true;
            this.lbltreatmentno.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltreatmentno.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbltreatmentno.Location = new System.Drawing.Point(458, 73);
            this.lbltreatmentno.Name = "lbltreatmentno";
            this.lbltreatmentno.Size = new System.Drawing.Size(84, 13);
            this.lbltreatmentno.TabIndex = 60;
            this.lbltreatmentno.Text = "Treatment No";
            // 
            // txtreatmentno
            // 
            this.txtreatmentno.Enabled = false;
            this.txtreatmentno.Location = new System.Drawing.Point(577, 70);
            this.txtreatmentno.Name = "txtreatmentno";
            this.txtreatmentno.ReadOnly = true;
            this.txtreatmentno.Size = new System.Drawing.Size(120, 20);
            this.txtreatmentno.TabIndex = 8;
            // 
            // lbldiscount
            // 
            this.lbldiscount.AutoSize = true;
            this.lbldiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscount.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbldiscount.Location = new System.Drawing.Point(379, 99);
            this.lbldiscount.Name = "lbldiscount";
            this.lbldiscount.Size = new System.Drawing.Size(57, 13);
            this.lbldiscount.TabIndex = 58;
            this.lbldiscount.Text = "Discount";
            // 
            // lbldiscountamount
            // 
            this.lbldiscountamount.AutoSize = true;
            this.lbldiscountamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscountamount.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbldiscountamount.Location = new System.Drawing.Point(458, 99);
            this.lbldiscountamount.Name = "lbldiscountamount";
            this.lbldiscountamount.Size = new System.Drawing.Size(96, 13);
            this.lbldiscountamount.TabIndex = 57;
            this.lbldiscountamount.Text = "Discount Amont";
            // 
            // chkdiscount
            // 
            this.chkdiscount.AutoSize = true;
            this.chkdiscount.Location = new System.Drawing.Point(437, 99);
            this.chkdiscount.Name = "chkdiscount";
            this.chkdiscount.Size = new System.Drawing.Size(15, 14);
            this.chkdiscount.TabIndex = 10;
            this.chkdiscount.UseVisualStyleBackColor = true;
            this.chkdiscount.CheckedChanged += new System.EventHandler(this.chkdiscount_CheckedChanged);
            // 
            // txtdiscount
            // 
            this.txtdiscount.Enabled = false;
            this.txtdiscount.Location = new System.Drawing.Point(577, 95);
            this.txtdiscount.Name = "txtdiscount";
            this.txtdiscount.Size = new System.Drawing.Size(120, 20);
            this.txtdiscount.TabIndex = 11;
            this.txtdiscount.TextChanged += new System.EventHandler(this.txtdiscount_TextChanged);
            this.txtdiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdiscount_KeyPress);
            // 
            // txtpaidedamount
            // 
            this.txtpaidedamount.Enabled = false;
            this.txtpaidedamount.Location = new System.Drawing.Point(577, 122);
            this.txtpaidedamount.Name = "txtpaidedamount";
            this.txtpaidedamount.ReadOnly = true;
            this.txtpaidedamount.Size = new System.Drawing.Size(120, 20);
            this.txtpaidedamount.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label13.Location = new System.Drawing.Point(458, 126);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(107, 13);
            this.label13.TabIndex = 53;
            this.label13.Text = "Received Amount";
            // 
            // Txt_TreatmentFee
            // 
            this.Txt_TreatmentFee.Location = new System.Drawing.Point(163, 97);
            this.Txt_TreatmentFee.Name = "Txt_TreatmentFee";
            this.Txt_TreatmentFee.Size = new System.Drawing.Size(210, 20);
            this.Txt_TreatmentFee.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label12.Location = new System.Drawing.Point(12, 98);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 13);
            this.label12.TabIndex = 51;
            this.label12.Text = "Treatment Fee";
            // 
            // ddltreatment
            // 
            this.ddltreatment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddltreatment.FormattingEnabled = true;
            this.ddltreatment.Location = new System.Drawing.Point(163, 70);
            this.ddltreatment.Name = "ddltreatment";
            this.ddltreatment.Size = new System.Drawing.Size(287, 21);
            this.ddltreatment.TabIndex = 7;
            this.ddltreatment.SelectedIndexChanged += new System.EventHandler(this.ddltreatment_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label11.Location = new System.Drawing.Point(12, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 13);
            this.label11.TabIndex = 49;
            this.label11.Text = "Treatment Type";
            // 
            // cmbdoctor
            // 
            this.cmbdoctor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbdoctor.FormattingEnabled = true;
            this.cmbdoctor.Location = new System.Drawing.Point(162, 123);
            this.cmbdoctor.Name = "cmbdoctor";
            this.cmbdoctor.Size = new System.Drawing.Size(287, 21);
            this.cmbdoctor.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label10.Location = new System.Drawing.Point(12, 124);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 13);
            this.label10.TabIndex = 47;
            this.label10.Text = "Review By";
            // 
            // txtpaidamount
            // 
            this.txtpaidamount.Location = new System.Drawing.Point(162, 148);
            this.txtpaidamount.Name = "txtpaidamount";
            this.txtpaidamount.Size = new System.Drawing.Size(288, 20);
            this.txtpaidamount.TabIndex = 14;
            this.txtpaidamount.TextChanged += new System.EventHandler(this.txtpaidamount_TextChanged);
            this.txtpaidamount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpaidamount_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label9.Location = new System.Drawing.Point(12, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 13);
            this.label9.TabIndex = 45;
            this.label9.Text = "Charge Amount *";
            // 
            // dtreviewdate
            // 
            this.dtreviewdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtreviewdate.Location = new System.Drawing.Point(577, 148);
            this.dtreviewdate.Name = "dtreviewdate";
            this.dtreviewdate.Size = new System.Drawing.Size(120, 20);
            this.dtreviewdate.TabIndex = 15;
            // 
            // txtremarks
            // 
            this.txtremarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtremarks.Location = new System.Drawing.Point(162, 174);
            this.txtremarks.Multiline = true;
            this.txtremarks.Name = "txtremarks";
            this.txtremarks.Size = new System.Drawing.Size(535, 35);
            this.txtremarks.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(458, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 13);
            this.label8.TabIndex = 42;
            this.label8.Text = "Next Visit Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(12, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 41;
            this.label7.Text = "Remarks *";
            // 
            // combosex
            // 
            this.combosex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combosex.FormattingEnabled = true;
            this.combosex.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.combosex.Location = new System.Drawing.Point(577, 43);
            this.combosex.Name = "combosex";
            this.combosex.Size = new System.Drawing.Size(120, 21);
            this.combosex.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(487, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 38;
            this.label1.Text = "Sex";
            // 
            // txtguardian
            // 
            this.txtguardian.Location = new System.Drawing.Point(162, 44);
            this.txtguardian.Name = "txtguardian";
            this.txtguardian.Size = new System.Drawing.Size(288, 20);
            this.txtguardian.TabIndex = 5;
            this.txtguardian.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtguardian_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(12, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 13);
            this.label2.TabIndex = 36;
            this.label2.Text = "Father / Guardian Name";
            // 
            // txtage
            // 
            this.txtage.Location = new System.Drawing.Point(577, 17);
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(120, 20);
            this.txtage.TabIndex = 4;
            this.txtage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtage_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(487, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 34;
            this.label4.Text = "Age";
            // 
            // txtpatient
            // 
            this.txtpatient.Location = new System.Drawing.Point(237, 18);
            this.txtpatient.Name = "txtpatient";
            this.txtpatient.Size = new System.Drawing.Size(215, 20);
            this.txtpatient.TabIndex = 3;
            this.txtpatient.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpatient_KeyPress);
            // 
            // cbosubtitle
            // 
            this.cbosubtitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbosubtitle.Enabled = false;
            this.cbosubtitle.FormattingEnabled = true;
            this.cbosubtitle.Items.AddRange(new object[] {
            "--Select--",
            "MR",
            "MRS",
            "MISS",
            "BABY",
            "DR"});
            this.cbosubtitle.Location = new System.Drawing.Point(163, 17);
            this.cbosubtitle.Name = "cbosubtitle";
            this.cbosubtitle.Size = new System.Drawing.Size(58, 21);
            this.cbosubtitle.TabIndex = 2;
            this.cbosubtitle.SelectedIndexChanged += new System.EventHandler(this.cbosubtitle_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(12, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 31;
            this.label3.Text = "Victim Name";
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnPrint.Location = new System.Drawing.Point(417, 548);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 22;
            this.btnPrint.Text = "&Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Visible = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // PatientDetails
            // 
            this.PatientDetails.AllowUserToAddRows = false;
            this.PatientDetails.AllowUserToDeleteRows = false;
            this.PatientDetails.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PatientDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PatientDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PatientDetails.Location = new System.Drawing.Point(18, 378);
            this.PatientDetails.Name = "PatientDetails";
            this.PatientDetails.ReadOnly = true;
            this.PatientDetails.Size = new System.Drawing.Size(719, 150);
            this.PatientDetails.TabIndex = 72;
            // 
            // ReviewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 593);
            this.Controls.Add(this.PatientDetails);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSave);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ReviewForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Victim Review Form";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ReviewForm_FormClosed);
            this.Load += new System.EventHandler(this.ReviewForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ReviewForm_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PatientDetails)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtregid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtguardian;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtpatient;
        private System.Windows.Forms.ComboBox cbosubtitle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtptransdate;
        private System.Windows.Forms.ComboBox combosex;
        private System.Windows.Forms.Button btnPrint;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private Label label8;
        private Label label7;
        private TextBox txtremarks;
        private DateTimePicker dtreviewdate;
        private TextBox txtpaidamount;
        private Label label9;
        private ComboBox cmbdoctor;
        private Label label10;
        private Label label11;
        private ComboBox ddltreatment;
        private TextBox Txt_TreatmentFee;
        private Label label12;
        private TextBox txtpaidedamount;
        private Label label13;
        private DataGridView PatientDetails;
        private CheckBox chkdiscount;
        private TextBox txtdiscount;
        private Label lbldiscountamount;
        private Label lbldiscount;
        private Label lbltreatmentno;
        private TextBox txtreatmentno;
        private DateTimePicker dtchequedate;
        private TextBox txtchequeno;
        private TextBox txtbankname;
        private Label label17;
        private Label label16;
        private Label lblchqno;
        private ComboBox ddlpayment;
        private Label label14;
    }
}