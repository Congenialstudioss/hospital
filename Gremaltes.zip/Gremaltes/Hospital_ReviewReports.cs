﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class Hospital_ReviewReports : Form
    {
        public Hospital_ReviewReports()
        {
            InitializeComponent();
            Txt_Patientno.MaxLength = 10;
        }

        private void Hospital_ReviewReports_Load(object sender, EventArgs e)
        {

            LoadDropDown();
        }
        public object getdata()
        {
            DataTable dt = new DataTable();
            string strcon = ConfigurationManager.ConnectionStrings["HospitalConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Hospital_ReviewReport_Sp";
            if (Txt_Patientno.Text != "")
            {
                cmd.Parameters.AddWithValue("@PatientNo", Txt_Patientno.Text);
            }
            cmd.Parameters.AddWithValue("@TreatMentType", ddl_Treatmenttype.SelectedValue);
            cmd.Parameters.AddWithValue("@RegFromDate", Reviewfrom.Value);
            cmd.Parameters.AddWithValue("@RegToDate", Reviewto.Value);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            // con.Close();
            return dt;
        }

        protected void showReport()
        {
            try
            {
                reportViewer1.Reset();
                DataTable dt = getdata() as DataTable;
                ReportDataSource rds = new ReportDataSource("DataSet1", dt);
                rds.Value = dt;
                if (dt.Rows.Count > 0)
                {
                    this.reportViewer1.ProcessingMode = ProcessingMode.Local;
                    reportViewer1.LocalReport.DataSources.Add(rds);
                    reportViewer1.LocalReport.ReportPath = @"../../Hospital_ReviewReport.rdlc";
                }
                else
                {
                    MessageBox.Show("No Record Found based on your search criteria !!!", "Review Report - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Btn_Search_Click(object sender, EventArgs e)
        {
            showReport();
            this.reportViewer1.RefreshReport();
        }

        private void Btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void LoadDropDown()
        {
            try
            {
                //Dropdown list values is selected  from database without using <asp:list items>////
                System.Data.DataTable dsLoad1 = DataAccessLayer.GetDataTable("Hospital_TreatmentMaster_sp");

                if (dsLoad1.Rows.Count > 0)
                {
                    ddl_Treatmenttype.DataSource = new BindingSource(dsLoad1, null);
                    ddl_Treatmenttype.DisplayMember = "TreatmentName";
                    ddl_Treatmenttype.ValueMember = "TreatmentId";
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void txtcontactno_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            //    e.Handled = true;

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '/'))
            {
                e.Handled = true;
            }

            if (e.KeyChar == '/' && Txt_Patientno.Text.IndexOf('/') > -1)
            {
                e.Handled = true;
            }
        }
    }
}
