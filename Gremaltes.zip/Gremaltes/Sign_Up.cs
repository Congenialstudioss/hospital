﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class Sign_Up : Form
    {
        public Sign_Up()
        {
            InitializeComponent();
        }

        private void registerbtn_Click(object sender, EventArgs e)
        {
            SaveMethod();
            Clear();
        }

        public void SaveMethod()
        {
            Hashtable hstbl1 = new Hashtable();
            hstbl1.Add("@UserName", txtusername.Text.Trim());
            hstbl1.Add("@Password", txtpassword.Text.Trim());

            Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_AddUser_Sp", hstbl1);

            if (intIdentity != null)
            {
                MessageBox.Show("User Created Sucessfully !!!");
                login l = new login();
                this.Visible = false;
                l.Show();
            }
            else
            {
                MessageBox.Show("User Created Failed !!!", "Hospital-Error");
            }
        }

        public void Clear()
        {
            txtusername.Text = String.Empty;
            txtpassword.Text = String.Empty;
        }
    }
}
