﻿namespace Sample
{
    partial class Treatment_Fees_Master
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Btn_TreatmentfeesSave = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.ddlTreatmentType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Grid_TreatmentFeesList = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Txt_Treatmentfees = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Grid_TreatmentFeesList)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_TreatmentfeesSave
            // 
            this.Btn_TreatmentfeesSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_TreatmentfeesSave.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Btn_TreatmentfeesSave.Location = new System.Drawing.Point(277, 106);
            this.Btn_TreatmentfeesSave.Name = "Btn_TreatmentfeesSave";
            this.Btn_TreatmentfeesSave.Size = new System.Drawing.Size(75, 23);
            this.Btn_TreatmentfeesSave.TabIndex = 3;
            this.Btn_TreatmentfeesSave.Text = "Save";
            this.Btn_TreatmentfeesSave.UseVisualStyleBackColor = true;
            this.Btn_TreatmentfeesSave.Click += new System.EventHandler(this.Btn_TreatmentfeesSave_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(113, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Treatment Fees";
            // 
            // ddlTreatmentType
            // 
            this.ddlTreatmentType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlTreatmentType.FormattingEnabled = true;
            this.ddlTreatmentType.Location = new System.Drawing.Point(234, 27);
            this.ddlTreatmentType.Name = "ddlTreatmentType";
            this.ddlTreatmentType.Size = new System.Drawing.Size(179, 21);
            this.ddlTreatmentType.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(113, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Treatment Type";
            // 
            // Grid_TreatmentFeesList
            // 
            this.Grid_TreatmentFeesList.AllowUserToAddRows = false;
            this.Grid_TreatmentFeesList.AllowUserToDeleteRows = false;
            this.Grid_TreatmentFeesList.BackgroundColor = System.Drawing.SystemColors.Window;
            this.Grid_TreatmentFeesList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Grid_TreatmentFeesList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Grid_TreatmentFeesList.Location = new System.Drawing.Point(12, 147);
            this.Grid_TreatmentFeesList.Name = "Grid_TreatmentFeesList";
            this.Grid_TreatmentFeesList.ReadOnly = true;
            this.Grid_TreatmentFeesList.Size = new System.Drawing.Size(529, 168);
            this.Grid_TreatmentFeesList.TabIndex = 1;
            this.Grid_TreatmentFeesList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Grid_TreatmentFeesList_CellDoubleClick);
            this.Grid_TreatmentFeesList.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Grid_TreatmentFeesList_CellMouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(134, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.deleteToolStripMenuItem.Text = "Delete Row";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // Txt_Treatmentfees
            // 
            this.Txt_Treatmentfees.Location = new System.Drawing.Point(234, 69);
            this.Txt_Treatmentfees.Name = "Txt_Treatmentfees";
            this.Txt_Treatmentfees.Size = new System.Drawing.Size(179, 20);
            this.Txt_Treatmentfees.TabIndex = 2;
            this.Txt_Treatmentfees.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_Treatmentfees_KeyPress);
            // 
            // Treatment_Fees_Master
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 325);
            this.Controls.Add(this.Btn_TreatmentfeesSave);
            this.Controls.Add(this.Grid_TreatmentFeesList);
            this.Controls.Add(this.Txt_Treatmentfees);
            this.Controls.Add(this.ddlTreatmentType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Treatment_Fees_Master";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Treatment Fees Master";
            this.Load += new System.EventHandler(this.Treatment_Fees_Master_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Grid_TreatmentFeesList)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_TreatmentfeesSave;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox ddlTreatmentType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView Grid_TreatmentFeesList;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.TextBox Txt_Treatmentfees;
    }
}