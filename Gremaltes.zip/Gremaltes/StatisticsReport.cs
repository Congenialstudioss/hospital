﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace Sample
{
    public partial class StatisticsReport : Form
    {
        public StatisticsReport()
        {
            InitializeComponent();
        }

        private void StatisticsReport_Load(object sender, EventArgs e)
        {
                       
            LoadDropDown();
            ddlPatientType.SelectedValue = 0;
            
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {           

            this.Gremaltes_StatisticsReports_SPTableAdapter.Fill(this.Gremaltes_StaticisReport.Gremaltes_StatisticsReports_SP
                , Convert.ToDateTime(dtFrom.Text).AddHours(00).AddMinutes(00).AddSeconds(00),
                Convert.ToDateTime(dtTo.Text).AddHours(23).AddMinutes(59).AddSeconds(59),
                0,
                Convert.ToByte(ddlPatientType.SelectedValue));

            this.reportViewer1.RefreshReport();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void LoadDropDown()
        {
            //Dropdown list values is selected  from database without using <asp:list items>////
            DataTable dsLoad = DataAccessLayer.GetDataTable("Hospital_PatientType_Sp");

            if (dsLoad != null)
            {
                if (dsLoad.Rows.Count > 0)
                {
                    DataRow dr = dsLoad.NewRow();
                    dr["PatientTypeId"] = 0;
                    dr["PatientType"] = "ALL";
                    dsLoad.Rows.Add(dr);
                    ddlPatientType.DataSource = new BindingSource(dsLoad, null);
                    ddlPatientType.DisplayMember = "PatientType";
                    ddlPatientType.ValueMember = "PatientTypeId";
                    //ddlPatientType.SelectedIndex = 0;
                    //ddlPatientType.Items.Add(new { Text = "ALL", Value = "0" });
                }
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            Hashtable htbl = new Hashtable();
            htbl.Add("@FromDate", Convert.ToDateTime(dtFrom.Text).AddHours(00).AddMinutes(00).AddSeconds(00));
            htbl.Add("@ToDate", Convert.ToDateTime(dtTo.Text).AddHours(23).AddMinutes(59).AddSeconds(59));
            htbl.Add("@DiseaseID", DBNull.Value);
            htbl.Add("@PatientType", Convert.ToInt16(ddlPatientType.SelectedValue));

            DataTable dtResult = DataAccessLayer.GetDataTable("Hospital_StatisticsReports_SP", htbl);

            DataAccessLayer objprin = new DataAccessLayer();
            objprin.DataToExcel(dtResult);
        }
    }
}
