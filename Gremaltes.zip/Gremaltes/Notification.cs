﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class Notification : Form
    {
        public Notification()
        {
            InitializeComponent();
        }

        public void GetMethod()
        {
            try
            {
                System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("Hospital_NotificationData_sp");
                GvNotificationData.DataSource = null;
                if (dsLoad != null)
                {
                    if (dsLoad.Rows.Count > 0)
                    {
                        Global.NotificationCount = dsLoad.Rows.Count.ToString();
                        GvNotificationData.DataSource = dsLoad;

                        GvNotificationData.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                        DataGridViewCellStyle style = GvNotificationData.ColumnHeadersDefaultCellStyle;
                        style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        style.Font = new Font(GvNotificationData.Font, FontStyle.Bold);
                        GvNotificationData.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
                        GvNotificationData.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                        GvNotificationData.EnableHeadersVisualStyles = false;
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Notification_Load(object sender, EventArgs e)
        {
            GetMethod();
        }

    }
}
