﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class PatientFormSearch : Form
    {
        int indexRow;
        public PatientFormSearch()
        {
            InitializeComponent();
            txtregid.MaxLength = 10;

            DataGridViewCellStyle style = dgResult.ColumnHeadersDefaultCellStyle;
            style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            style.Font = new Font(dgResult.Font, FontStyle.Bold);
            dgResult.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
            dgResult.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgResult.EnableHeadersVisualStyles = false;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtPatientName.Text != String.Empty || txtGuardianName.Text != String.Empty || txtregid.Text != String.Empty || txtcontactno.Text != String.Empty)
                {
                    Hashtable hstbl = new Hashtable();
                    hstbl.Add("@RegId", txtregid.Text != string.Empty ? txtregid.Text : (object)DBNull.Value);
                    hstbl.Add("@PatientName", txtPatientName.Text != string.Empty ? txtPatientName.Text : (object)DBNull.Value);
                    hstbl.Add("@GuardianName", txtGuardianName.Text != string.Empty ? txtGuardianName.Text : (object)DBNull.Value);
                    hstbl.Add("@ContactNo", txtcontactno.Text != string.Empty ? txtcontactno.Text : (object)DBNull.Value);
                    DataTable dt = new DataTable();
                    dt = DataAccessLayer.GetDataTable("Hospital_VictimSearch_Sp", hstbl);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        dgResult.DataSource = dt;
                        DataGridViewCellStyle style = dgResult.ColumnHeadersDefaultCellStyle;
                        style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        style.Font = new Font(dgResult.Font, FontStyle.Bold);
                        dgResult.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
                        dgResult.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                        dgResult.EnableHeadersVisualStyles = false;
                    }
                    else
                    {
                        MessageBox.Show("No Record Found based on your search criteria !!!", "Victim Search - Error");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter Patient name or Guardian name or VictimNo or ContactNo", "Victim Search - Error");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void dgResult_SelectionChanged(object sender, EventArgs e)
        {
            //if (dgResult.SelectedCells.Count > 0)
            //{
            //    int selectedrowindex = dgResult.SelectedCells[0].RowIndex;

            //    DataGridViewRow selectedRow = dgResult.Rows[selectedrowindex];

            //    string a = Convert.ToString(selectedRow.Cells["RegNo"].Value);

            //    ReviewForm parent = (ReviewForm)this.Owner;
            //    //call the updatetext method
            //    parent.updatetext(a);
            //    //closing the form is optional.
            //    this.Close();
            //    //ReviewForm objReview = new ReviewForm();
            //    //objReview._valueVictimID = a.ToString();
            //    //objReview.Show();
            //    //this.Hide();
            //}
        }

        //private void dgResult_DoubleClick(object sender, EventArgs e)
        //{
        //    DataGridViewSelectedRowCollection rows = dgResult.SelectedRows;
        //    if (rows.Count > 0)
        //    {
        //        string val = Convert.ToString(rows[0].Cells["RegNo"].Value);
        //        TreatmentHistory parent = (TreatmentHistory)this.Owner;
        //        parent.updatetext(val);
        //        this.Close();
        //    }
        //}

        void Alphabets_Only(object sender, KeyPressEventArgs e)
        {
            if (char.IsUpper(e.KeyChar) || char.IsLower(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar.ToString() == ".")
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void txtfather_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsUpper(e.KeyChar) || char.IsLower(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar.ToString() == "." || e.KeyChar.ToString() == "/")
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        private void dgResult_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                indexRow = e.RowIndex;
                DataGridViewRow row = dgResult.Rows[indexRow];
                string val = row.Cells[0].Value.ToString();
                PatientForm parent = (PatientForm)this.Owner;
                parent.updatetext(val);
                this.Close();
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void txtcontactno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '/'))
            {
                e.Handled = true;
            }

            if (e.KeyChar == '/' && txtregid.Text.IndexOf('/') > -1)
            {
                e.Handled = true;
            }
        }
    }
}
