﻿namespace Sample
{
    partial class DoctorMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnsave = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtdoctor = new System.Windows.Forms.TextBox();
            this.GvDoctor = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ddlSurName = new System.Windows.Forms.ComboBox();
            this.txtcontactno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.GvDoctor)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnsave
            // 
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnsave.Location = new System.Drawing.Point(295, 96);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 4;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(33, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Doctor Name";
            // 
            // txtdoctor
            // 
            this.txtdoctor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdoctor.Location = new System.Drawing.Point(226, 24);
            this.txtdoctor.Name = "txtdoctor";
            this.txtdoctor.Size = new System.Drawing.Size(225, 20);
            this.txtdoctor.TabIndex = 2;
            // 
            // GvDoctor
            // 
            this.GvDoctor.AllowUserToAddRows = false;
            this.GvDoctor.AllowUserToDeleteRows = false;
            this.GvDoctor.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.GvDoctor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.GvDoctor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvDoctor.Location = new System.Drawing.Point(36, 134);
            this.GvDoctor.Name = "GvDoctor";
            this.GvDoctor.ReadOnly = true;
            this.GvDoctor.Size = new System.Drawing.Size(439, 150);
            this.GvDoctor.TabIndex = 4;
            this.GvDoctor.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gvtreatment_CellDoubleClick);
            this.GvDoctor.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Gvtreatment_CellMouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(134, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.deleteRowToolStripMenuItem.Text = "Delete Row";
            // 
            // ddlSurName
            // 
            this.ddlSurName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlSurName.FormattingEnabled = true;
            this.ddlSurName.Items.AddRange(new object[] {
            "--Select--",
            "MR",
            "MRS",
            "MISS",
            "BABY",
            "DR"});
            this.ddlSurName.Location = new System.Drawing.Point(139, 24);
            this.ddlSurName.Name = "ddlSurName";
            this.ddlSurName.Size = new System.Drawing.Size(60, 21);
            this.ddlSurName.TabIndex = 1;
            // 
            // txtcontactno
            // 
            this.txtcontactno.Location = new System.Drawing.Point(226, 61);
            this.txtcontactno.Name = "txtcontactno";
            this.txtcontactno.Size = new System.Drawing.Size(225, 20);
            this.txtcontactno.TabIndex = 3;
            this.txtcontactno.TextChanged += new System.EventHandler(this.txtcontactno_TextChanged);
            this.txtcontactno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontactno_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(33, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Contact No";
            // 
            // DoctorMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 301);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtcontactno);
            this.Controls.Add(this.ddlSurName);
            this.Controls.Add(this.GvDoctor);
            this.Controls.Add(this.txtdoctor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnsave);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DoctorMaster";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Doctor Master";
            ((System.ComponentModel.ISupportInitialize)(this.GvDoctor)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtdoctor;
        private System.Windows.Forms.DataGridView GvDoctor;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
        private System.Windows.Forms.ComboBox ddlSurName;
        private System.Windows.Forms.TextBox txtcontactno;
        private System.Windows.Forms.Label label2;
    }
}