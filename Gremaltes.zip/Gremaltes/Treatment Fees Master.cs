﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sample
{
    public partial class Treatment_Fees_Master : Form
    {
        DataAccessLayer objDataLayer = new DataAccessLayer();
        DataTable table;
        static int indexRow;
        int ID = 0;
        public Treatment_Fees_Master()
        {
            InitializeComponent();
            Txt_Treatmentfees.MaxLength = 10;
        }

        private void Btn_TreatmentfeesSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Txt_Treatmentfees.Text != String.Empty)
                {
                    Hashtable hstbl = new Hashtable();
                    hstbl.Add("@TreatmentID", ddlTreatmentType.SelectedValue);
                    hstbl.Add("@TreatmentFees", Txt_Treatmentfees.Text);
                    //hstbl.Add("@ConsultingFees", Txt_Consultingfee.Text);
                    hstbl.Add("@CreatedBy", Global.UserID);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_TreatmentFeesInsertUpdate_SP", hstbl);
                    if (Btn_TreatmentfeesSave.Text == "Save")
                    {
                        MessageBox.Show("Treatment Fees Saved Successfully.", "Treatment Fees Alert");
                    }
                    else
                    {
                        MessageBox.Show("Treatment Fees Update Successfully.", "Treatment Fees Alert");
                    }

                    Clear();
                    BindGrid();
                    Btn_TreatmentfeesSave.Text = "Save";
                    ddlTreatmentType.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Please Enter the treatment Fess", "Treatment Fees Alert");
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
        protected void BindGrid()
        {
            try
            {
                Hashtable hst = new Hashtable();
                DataSet ds = DataAccessLayer.GetDataset("Hospital_TreatmentFeesList_SP", hst);
                Grid_TreatmentFeesList.DataSource = null;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Grid_TreatmentFeesList.DataSource = ds.Tables[0];
                    Grid_TreatmentFeesList.Columns[1].Visible = false;
                    Grid_TreatmentFeesList.Columns[3].Visible = false;
                    Grid_TreatmentFeesList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    DataGridViewCellStyle style = Grid_TreatmentFeesList.ColumnHeadersDefaultCellStyle;
                    style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    style.Font = new Font(Grid_TreatmentFeesList.Font, FontStyle.Bold);
                    Grid_TreatmentFeesList.ColumnHeadersDefaultCellStyle.BackColor = Color.DeepSkyBlue;
                    Grid_TreatmentFeesList.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    Grid_TreatmentFeesList.EnableHeadersVisualStyles = false;

                    this.Grid_TreatmentFeesList.Columns["TreatmentFee"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }


        public void LoadTreatmentDropDown()
        {
            try
            {
                //Dropdown list values is selected  from database without using <asp:list items>////
                System.Data.DataTable dsLoad = DataAccessLayer.GetDataTable("Hospital_TreatmentMaster_sp");

                if (dsLoad != null)
                {
                    if (dsLoad.Rows.Count > 0)
                    {
                        ddlTreatmentType.DataSource = new BindingSource(dsLoad, null);
                        ddlTreatmentType.DisplayMember = "TreatmentName";
                        ddlTreatmentType.ValueMember = "TreatmentId";
                        ddlTreatmentType.SelectedValue = 1;
                    }
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Treatment_Fees_Master_Load(object sender, EventArgs e)
        {
            LoadTreatmentDropDown();
            BindGrid();
            ddlTreatmentType.SelectedValue = 1;
        }

        private void Grid_TreatmentFeesList_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //ID = Convert.ToInt32(Grid_TreatmentFeesList.Rows[e.RowIndex].Cells[0].Value.ToString()); 
                ddlTreatmentType.SelectedValue = Grid_TreatmentFeesList.Rows[e.RowIndex].Cells[3].Value.ToString();
                Txt_Treatmentfees.Text = Grid_TreatmentFeesList.Rows[e.RowIndex].Cells[4].Value.ToString();
                //Txt_Consultingfee.Text = Grid_TreatmentFeesList.Rows[e.RowIndex].Cells[5].Value.ToString();
                Btn_TreatmentfeesSave.Text = "Update";
                ddlTreatmentType.Enabled = false;
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Clear()
        {
            ddlTreatmentType.SelectedValue = 1;
            ddlTreatmentType.Enabled = true;
            //Txt_Consultingfee.Text = String.Empty;
            Txt_Treatmentfees.Text = String.Empty;
        }

        private void Grid_TreatmentFeesList_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Right)
                {
                    this.Grid_TreatmentFeesList.Rows[e.RowIndex].Selected = true;
                    indexRow = e.RowIndex;
                    ID = Convert.ToInt32(Grid_TreatmentFeesList.Rows[e.RowIndex].Cells[1].Value.ToString());
                    //this.Grid_TreatmentFeesList.CurrentCell = this.Grid_TreatmentFeesList.Rows[e.RowIndex].Cells[3];
                    this.contextMenuStrip1.Show(this.Grid_TreatmentFeesList, e.Location);
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                contextMenuStrip1.Hide();
                if (MessageBox.Show("Do you want to Delete ?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Hashtable hstbl = new Hashtable();
                    hstbl.Add("@ID", ID);
                    Int64 intIdentity = DataAccessLayer.ExecuteCommand_RowsAffected("Hospital_TreatmentFeesDelete_SP", hstbl);
                    if (intIdentity > 0)
                    {
                        MessageBox.Show("Treatment Fees Details Deleted Successfully.", "Treatment Fees Alert");
                        Clear();
                        BindGrid();
                        Btn_TreatmentfeesSave.Text = "Save";
                    }

                }
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void Txt_Treatmentfees_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }


    }
}
